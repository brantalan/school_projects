# My Contributions
This was the group project I worked on as a team for my COMP-294 Practicum class. I specically worked on the following:
API backend code for: Login / Logout
                      Creating Replies/Submissions/Users
                      Editing Replies/Submission/Users
UI Frontend code for: Profile views/Other users profiles
                      Read/Unread Notfication list
                      
# Project Summary

A student feedback portal providing an avenue through which students may direct their issues and recommendations to their school's administrative body. Students can register with the portal, log in, and provide feedback. Administrators can log in, review feedback, and provide responses where necessary.

# Technologies

### Main Components
- React JS (TypeScript)
- Microsoft Fluent UI
- ASP.NET Core (C#)
- Microsoft SQL Server

### Other Components
- NSwag — generates DTOs and client for back-end API
- AutoMapper — handles Entity-to-DTO mapping
- Swagger UI — intuitive UI for testing back-end APIs

### Learning Resources
- [React JS + TypeScript Tutorial](https://www.youtube.com/playlist?list=PLiKs97d-BatHEeclprFtCaw8RcNOYXUqN)
- [Fluent UI Docs](https://developer.microsoft.com/en-us/fluentui#/controls/web)
- [ASP.NET Core Docs](https://docs.microsoft.com/en-us/aspnet/core/)
- [EF Core 1](https://stackify.com/entity-framework-core-tutorial/)
- [EF Core 2](https://docs.microsoft.com/en-us/aspnet/core/data/ef-mvc/intro?view=aspnetcore-5.0#create-the-database-context)
- [AutoMapper](https://code-maze.com/automapper-net-core/)

# Development Tools

These tools are required and/or recommended:

1. [**.NET Core SDK 5**](https://dotnet.microsoft.com/download). This version of the SDK is recommended by Microsoft.

2. [**Node.js LTS**](https://nodejs.org/en). Node JS is required for front end development.

3. [**Git**](https://git-scm.com/) / [**GitExtensions**](http://gitextensions.github.io/). Source control management of the web application is done via Git. The application's code is also hosted at GitHub. You will need Git installed to clone the repository and push updates as you develop. GitExtensions is a GUI tool that makes working with Git easier.

4. [**Visual Studio Code**](https://code.visualstudio.com/) / [**Visual Studio 2019**](https://visualstudio.microsoft.com/downloads). I recommend VS for working on the back end of the application, and VS Code for working with the front end. Feel free to use whatever editor best suits you. If using VS Code, I recommend installing the GitLens extension.

3. [**SQL Server 2019**](https://www.microsoft.com/en-us/sql-server/sql-server-downloads). Either the Developer or the Express editions are fine so long as you have `LocalDb` installed. The application's database won't work without this. LocalDb should be accessible from the feature selection page of the installation wizard. Alternatively, if you already have SQL Server installed, run the installer again and choose **Download Media**. From there you should be able to download just the LocalDb setup file.

4. [**SQL Server Management Studio**](https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver15). Use SSMS to access the tables, fields, properties, and data of the database.

# Test Connection

To verify that you are able to run and access the application correctly, follow the steps below:

1. Open your preferred terminal and navigate to the `service` folder
2. Run the following `dotnet` commands to start up the back end:
```sh
dotnet build
dotnet run --project SFP.API
```
3. Open your browser to: `https://localhost:44345/swagger`. You should see the Swagger UI interface showing various APIs.
4. In another terminal, navigate to the `client` folder and run the following `npm` commands to fire up the front end:
```sh
npm install
npm start
```
5. The webpack dev server hosts the front end and your browser will open to: `http://localhost:3000`

# Entity Framework (EF) Core

EF Core is cross-platform data access technology. It functions on the basis of **migrations** which enables synchronization of the database structure across multiple developers.
### Adding an Entity Framework Core migration

1. Open your preferred terminal and navigate to the `SFP.Data` folder.
2. Run the following `dotnet` commands:
```sh
dotnet tool install --global dotnet-ef
dotnet ef migrations add <NAME OF MIGRATION>
```

### Removing the latest Entity Framework Core migration

1. Open your preferred terminal and navigate to the `SFP.Data` folder.
2. Run the following `dotnet` command: `dotnet ef migrations remove`.
