﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.Reply;
using SFP.Data.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for Reply APIs.
    /// </summary>
    public class RepliesController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RepliesController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public RepliesController(IMediator mediator) : base(mediator) { }

        /// <summary>
        /// Create a new Reply.
        /// </summary>
        /// <param name="dto">A Reply DTO.</param>
        [HttpPost]
        public async Task<ActionResult<ReplyDto>> CreateReply([FromBody] ReplyDto dto)
        {
            return Created("", await Mediator.Send(new CreateReplyCommand() { Reply = dto }));
        }

        /// <summary>
        /// Get a all replies for submission.
        /// </summary>
        /// <param name="id">SubmissionID of the Replies to get.</param>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReplyDto>>> GetAllRepliesForSubmission(int id)
        {
            return Ok(await Mediator.Send(new GetAllForSubmissionQuery() { SubmissionId = id }));
        }

        /// <summary>
        /// Get a Reply by its Id.
        /// </summary>
        /// <param name="id">ID of the Reply to get.</param>
        [HttpGet("{id}")]
        public async Task<ActionResult<ReplyDto>> GetReply(int id)
        {
            return Ok(await Mediator.Send(new GetReplyByIdQuery() { ReplyId = id }));
        }

        /// <summary>
        /// Update an existing reply.
        /// </summary>
        /// <param name="dto">Updated Reply DTO.</param>
        [HttpPut]
        public async Task<ActionResult<ReplyDto>> UpdateReply([FromBody] ReplyDto dto)
        {
            return Ok(await Mediator.Send(new UpdateReplyCommand() { Reply = dto }));
        }
    }
}
