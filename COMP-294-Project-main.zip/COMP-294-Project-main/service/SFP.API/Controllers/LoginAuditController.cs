﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.LoginAudit;
using SFP.Data.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for LoginAudit APIs.
    /// </summary>
    public class LoginAuditController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoginAuditController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public LoginAuditController(IMediator mediator) : base(mediator) { }

        /// <summary>
        /// Get all Login Audits.
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LoginAuditDto>>> GetAllLogins()
        {
            return Ok(await Mediator.Send(new GetAllAuditsQuery()));
        }

        /// <summary>
        /// Get single audit.
        /// </summary>
        [HttpGet("{userid}")]
        public async Task<ActionResult<LoginAuditDto>> GetAuditById(int userid)
        {
            return Ok(await Mediator.Send(new GetAuditByIdQuery() { UserId = userid }));
        }

        /// <summary>
        /// Create a new Login Audit
        /// </summary>
        /// <param name="dto">A Login Audit DTO.</param>
        [HttpPost]
        public async Task<ActionResult<LoginAuditDto>> CreateLoginAudit([FromBody] LoginAuditDto dto)
        {
            return Created("", await Mediator.Send(new CreateLoginAuditCommand() { LoginAudit = dto }));
        }

        /// <summary>
        /// Update an existing Login Audit log in date.
        /// </summary>
        /// <param name="dto">Updated LoginAudit DTO.</param>
        [HttpPut]
        public async Task<ActionResult<LoginAuditDto>> UpdateLogOutTime([FromBody] LoginAuditDto dto)
        {
            return Ok(await Mediator.Send(new UpdateLoginAuditCommand() { LoginAudit = dto }));
        }
    }
}
