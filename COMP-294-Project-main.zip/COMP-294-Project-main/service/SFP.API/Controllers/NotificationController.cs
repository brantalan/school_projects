using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.Notification;
using SFP.Data.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for Notification APIs.
    /// </summary>
    public class NotificationController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public NotificationController(IMediator mediator) : base(mediator) { }

        /// <summary>
        /// Create a new Notification
        /// </summary>
        /// <param name="dto">A Notification DTO.</param>
        [HttpPost]
        public async Task<ActionResult<NotificationDto>> CreateNotification([FromBody] NotificationDto dto)
        {
            return Created("", await Mediator.Send(new CreateNotificationCommand() { Notification = dto }));
        }
        
        /// <summary>
        /// Update an existing notification.
        /// </summary>
        /// <param name="id">Notification id.</param>
        /// <param name="isRead"> boolean for what to set read status.</param>
        [HttpPut]
        public async Task<ActionResult<UserDto>> UpdateNotification( int id, bool isRead)
        {
            var result = (await Mediator.Send(new UpdateNotificationCommand() { Id = id, IsRead = isRead }));
            if (result != null)
            {
                return NoContent();
            }
            else
            {
                return BadRequest("Notification update failed.");
            }
        }

        /// <summary>
        /// Get single Notification
        /// </summary>
        /// <param name="notificationId">id for Notification.</param>
        [HttpGet]
        public async Task<ActionResult<NotificationDto>> GetNotification(int notificationId)
        {
            return Ok(await Mediator.Send(new GetNotificationQuery() { Id = notificationId }));
        }

        /// <summary>
        /// Get all notifications per userid
        /// </summary>
        /// <param name="userId">id of User for Notification.</param>
        /// <param name="isNew">whether to return new or previous notifications</param>
        [HttpGet("{userId}")]
        public async Task<ActionResult<IEnumerable<NotificationDto>>> GetAllNotifications(int userId, bool? isNew)
        {
            return Ok(await Mediator.Send(new GetAllNotificationsQuery() { UserId = userId, IsNew = isNew }));
        }
        
    }

}
