﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.Submission;
using SFP.Data.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for Submission APIs.
    /// </summary>
    public class SubmissionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SubmissionsController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public SubmissionsController(IMediator mediator) : base(mediator) { }

       /* /// <summary>
        /// Create a new Submission.
        /// </summary>
        /// <param name="dto">A Submission DTO.</param>
        [HttpPost]
        public async Task<ActionResult<SubmissionDto>> CreateSubmission([FromBody] SubmissionDto dto)
        {
            return Ok( await Mediator.Send(new CreateSubmissionCommand() { Submission = dto }) , );
        }*/

        /// <summary>
        /// Create a new Submission.
        /// </summary>
        /// <param name="dto">A Submission DTO.</param>
        [HttpPost]
        public async Task<ActionResult<SubmissionDto>> CreateSubmission([FromBody] SubmissionDto dto)
        {
            var entity = await Mediator.Send(new CreateSubmissionCommand() { Submission = dto });
            return CreatedAtAction(nameof(GetSubmission), new { SubmissionId = entity.Id }, entity);
        }


        /// <summary>
        /// Get all Submissions.
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SubmissionDto>>> GetAllSubmissions()
        {
            return Ok(await Mediator.Send(new GetAllSubmissionsQuery()));
        }

        /// <summary>
        /// Get all Submissions by a user
        /// </summary>
        /// <param name="userId"> to get submissions for.</param>
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<SubmissionDto>>> GetAllSubmissionsByUser(int userId)
        {
            return Ok(await Mediator.Send(new GetAllSubmissionsQuery() { UserId = userId }));
        }



        /// <summary>
        /// Get a Submission by its Id.
        /// </summary>
        /// <param name="submissionId"> submission to get</param>
        /// <param name="userId"> the currently logged in user (only necessary when user is a student)</param>
        [HttpGet("{submissionId}")]
        public async Task<ActionResult<SubmissionDto>> GetSubmission( int submissionId, int userId)
        {
            return Ok(await Mediator.Send(new GetSubmissionByIdQuery() { SubmissionId = submissionId, UserId = userId }));
        }

        /// <summary>
        /// Update an existing Submission.
        /// </summary>
        /// <param name="dto">Updated Submission DTO.</param>
        [HttpPut]
        public async Task<ActionResult<SubmissionDto>> UpdateSubmission([FromBody] SubmissionDto dto)
        {
            return Ok(await Mediator.Send(new UpdateSubmissionCommand() { Submission = dto }));
        }

       

    }

}
