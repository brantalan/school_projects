﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.User;
using SFP.Data.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for User APIs.
    /// </summary>
    public class UsersController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UsersController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public UsersController(IMediator mediator) : base(mediator) { }

        /// <summary>
        /// Create a new User.
        /// </summary>
        /// <param name="dto">A User DTO.</param>
        [HttpPost]
        public async Task<ActionResult<UserDto>> CreateUser([FromBody] UserDto dto)
        {
            return Created("", await Mediator.Send(new CreateUserCommand(){User = dto}));
        }

        /// <summary>
        /// Get all Users.
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDto>>> GetAllUsers()
        {
            return Ok(await Mediator.Send(new GetAllUsersQuery()));
        }

        /// <summary>
        /// Get a User by its Id.
        /// </summary>
        /// <param name="id">ID of the User to get.</param>
        [HttpGet("{id}")]
        public async Task<ActionResult<UserDto>> GetUser(int id)
        {
            return Ok(await Mediator.Send(new GetUserByIdQuery() { UserId = id }));
        }

        /// <summary>
        /// Update an existing user.
        /// </summary>
        /// <param name="dto">Updated User DTO.</param>
        [HttpPut]
        public async Task<ActionResult<UserDto>> UpdateUser([FromBody] UserDto dto)
        {
            return Ok(await Mediator.Send(new UpdateUserCommand() { User = dto }));
        }

        /// <summary>
        /// Upload users profile picture
        /// </summary>
        /// <param name="userid">user id to update.</param>
        /// <param name="file">picture to upload.</param>
        [HttpPut("uploaded")]
        public async Task<IActionResult> UploadPicture(int userid, [FromBody]byte[] file)
        {
            return Ok(await Mediator.Send(new UploadPictureCommand() { UserId = userid, Filename = file }));
        }

        /// <summary>
        /// Update user's password
        /// </summary>
        /// <param name="id">id of user to update.</param>
        /// <param name="password">new password.</param>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePassword([FromRoute] int id, string password)
        {
            var result = (await Mediator.Send(new UpdatePasswordCommand() { UserId = id, Password = password }));
            if(result)
            {
            return NoContent();
            }
            else
            {
                return BadRequest("Password update failed.");
            }
        }

        /// <summary>
        /// Handles user login
        /// </summary>
        /// <param name="username">Username of User.</param>
        /// <param name="password">Password of User.</param>
        [HttpPost("login")]
        public async Task<ActionResult<UserDto>> LogInUser(string username, string password)
        {
            // login
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                return Ok(await Mediator.Send(new UserLogInCommand() { Username = username, Password = password }));
            }
            else
            {
                return BadRequest("Provide at least a username.");
            }
        }
    }
}
