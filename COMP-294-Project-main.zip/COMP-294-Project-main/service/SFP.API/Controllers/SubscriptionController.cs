﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.Subscription;
using SFP.Data.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for Subscription APIs.
    /// </summary>
    public class SubscriptionController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SubscriptionController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public SubscriptionController(IMediator mediator) : base(mediator) { }

        /// <summary>
        /// Create a new Subscription
        /// </summary>
        /// <param name="dto">A Subscription DTO.</param>
        [HttpPost]
        public async Task<ActionResult<SubscriptionDto>> CreateSubscription([FromBody] SubscriptionDto dto)
        {
            return Created("", await Mediator.Send(new CreateSubscriptionCommand() { Subscription = dto }));
        }

        /// <summary>
        /// Get single subscription
        /// </summary>
        /// <param name="submissionId">SubmissionId of Submission for Subscription.</param>
        /// <param name="userId">UserId of User for Subscription.</param>
        [HttpGet]
        public async Task<ActionResult<SubscriptionDto>> GetSubscription(int submissionId, int userId)
        {
            return Ok(await Mediator.Send(new GetSubscriptionQuery() { SubmissionId = submissionId, UserId = userId }));
        }

        /// <summary>
        /// Get all subscribers per submission
        /// </summary>
        /// <param name="submissionId">SubmissionId of Submission for Subscription.</param>
        [HttpGet("{submissionId}")]
        public async Task<ActionResult<IEnumerable<SubscriptionDto>>> GetAllSubscribers(int submissionId)
        {
            return Ok(await Mediator.Send(new GetAllSubscribersQuery() { SubmissionId = submissionId }));
        }

        /// <summary>
        /// Delete an existing subscription.
        /// </summary>
        /// <param name="submissionId">SubmissionId of Submission for Subscription.</param>
        /// <param name="userId">UserId of User for Subscription.</param>
        [HttpDelete]
        public async Task<ActionResult<bool>> DeleteSubscription(int submissionId, int userId)
        {
            return Ok(await Mediator.Send(new DeleteSubscriptionCommand() { SubmissionId = submissionId, UserId = userId }));
        }
    }
}
