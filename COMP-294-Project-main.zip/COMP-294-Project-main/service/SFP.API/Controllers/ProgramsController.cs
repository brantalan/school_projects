﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SFP.Command.Program;
using SFP.Data.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SFP.API.Controllers
{
    /// <summary>
    /// Controller for Program APIs.
    /// </summary>
    public class ProgramsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProgramsController"/> class.
        /// </summary>
        /// <param name="mediator">Mediator instance from dependency injection.</param>
        public ProgramsController(IMediator mediator) : base(mediator) { }

        /// <summary>
        /// Get all Programs.
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProgramDto>>> GetAllPrograms()
        {
            return Ok(await Mediator.Send(new GetAllProgramsQuery()));
        }

        /// <summary>
        /// Get a Program by its Id.
        /// </summary>
        /// <param name="id">ID of the Program to get.</param>
        [HttpGet("{id}")]
        public async Task<ActionResult<ProgramDto>> GetProgram(int id)
        {
            return Ok(await Mediator.Send(new GetProgramByIdQuery() { ProgramId = id }));
        }
    }
}
