﻿using AutoMapper;
using SFP.Data.DTOs;
using SFP.Data.Models;

namespace SFP.Data
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Group, GroupDto>();
            CreateMap<User, UserDto>();
        
            CreateMap<Submission, SubmissionDto>();
            CreateMap<LoginAudit, LoginAuditDto>();
            CreateMap<Reply, ReplyDto>();
            CreateMap<Subscription, SubscriptionDto>();
            CreateMap<Program, ProgramDto>();
            CreateMap<Notification, NotificationDto>();
        }
    }
}
