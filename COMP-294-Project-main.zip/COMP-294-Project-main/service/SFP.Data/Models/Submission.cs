﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.ComponentModel.DataAnnotations.Schema;

namespace SFP.Data.Models
{
    public class Submission : AuditModel<int>
    {
        [Required]
        public int UserId { get; set; }

        [Required]
        public string Reference { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        [Column(TypeName = "varchar(MAX)")]
        public string Message { get; set; }

        // low, normal, or high
        [Required]
        public Constants.PriorityLevel PriorityLevel { get; set; }
    }
}
