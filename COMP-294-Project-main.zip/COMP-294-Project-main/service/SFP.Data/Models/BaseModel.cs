﻿using System.ComponentModel.DataAnnotations;

namespace SFP.Data.Models
{
    public abstract class BaseModel<TType>
    {
        [Key]
        public TType Id { get; set; }
    }
}
