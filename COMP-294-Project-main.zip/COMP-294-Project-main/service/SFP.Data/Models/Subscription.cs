﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.Models
{
    public class Subscription : AuditModel<int>
    {
        [Required]
        public int SubmissionId { get; set; }

        [Required]
        public int UserId { get; set; }

        /* Automatic has been excluded from final database implementation since it isn't totally necessary

        /* CreatedDate field from AuditModel being used in place of DateCreated from the ERD */
    }
}
