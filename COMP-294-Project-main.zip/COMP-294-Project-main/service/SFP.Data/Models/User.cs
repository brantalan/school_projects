﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.Models
{
    public class User : AuditModel<int>
    {
        public int ProgramId { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public byte[] Filename { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public byte[] Password { get; set; }

        [Required]
        public byte[] Salt{get; set;}

        // default to true
        [Required]
        public bool IsActive { get; set; }

        [Required]
        public bool IsAdmin { get; set; }
    }
}
