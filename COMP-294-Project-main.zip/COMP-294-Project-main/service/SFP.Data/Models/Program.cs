﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.Models
{
    public class Program : BaseModel<int>
    {
        [Required]
        public string Name { get; set; }
    }
}
