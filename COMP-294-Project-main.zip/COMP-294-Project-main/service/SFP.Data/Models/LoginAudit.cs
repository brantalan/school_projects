﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.Models
{
    public class LoginAudit : BaseModel<int>
    {
        [Required]
        public int UserId { get; set; }

        [Required]
        public System.DateTime DateLoggedIn { get; set; }

        public System.DateTime DateLoggedOut { get; set; }
    }
}
