﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.Models
{
    public class Notification : AuditModel<int>
    {
        // registration (0), submission (1), reply (2)
        [Required]
        public Constants.NotificationType Type { get; set; }

        // the user whose action triggered the notification
        [Required]
        public int TriggerId { get; set; }

        // the user who is notified
        [Required]
        public int ReceiverId { get; set; }

        [Required]
        public int SubmissionId { get; set; }

        [Required]
        public int ReplyId { get; set; }

        [Required]
        public bool IsRead { get; set; }

        /* CreatedDate field from AuditModel being used in place of DateCreated from the ERD */

        public System.DateTime DateRead { get; set; }
    }
}
