﻿using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class ReplyCreatedDomainEvent : INotification
    {
        public Reply Reply { get; }

        public ReplyCreatedDomainEvent(Reply reply)
        {
            Reply = reply;
        }
    }
}
