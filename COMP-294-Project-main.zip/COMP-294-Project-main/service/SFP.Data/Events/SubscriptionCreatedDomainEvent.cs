﻿using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class SubscriptionCreatedDomainEvent : INotification
    {
        public Subscription Subscription { get; }

        public SubscriptionCreatedDomainEvent(Subscription subscription)
        {
            Subscription = subscription;
        }
    }
}
