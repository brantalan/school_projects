﻿using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class SubmissionCreatedDomainEvent : INotification
    {
        public Submission Submission { get; }


        public SubmissionCreatedDomainEvent(Submission submission)
        {
            Submission = submission;
        }
    }
}
