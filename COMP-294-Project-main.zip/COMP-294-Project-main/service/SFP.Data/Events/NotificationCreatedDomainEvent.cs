using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class NotificationCreatedDomainEvent : INotification
    {
        public Notification Notification { get; }


        public NotificationCreatedDomainEvent(Notification notification)
        {
            Notification = notification;
        }
    }
}
