﻿using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class LoginAuditCreatedDomainEvent : INotification
    {
        public LoginAudit LoginAudit { get; }

        public LoginAuditCreatedDomainEvent(LoginAudit loginAudit)
        {
            LoginAudit = loginAudit;
        }
    }
}
