﻿using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class UserCreatedDomainEvent : INotification
    {
        public User User { get; }

        public UserCreatedDomainEvent(User user)
        {
            User = user;
        }
    }
}
