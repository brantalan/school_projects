﻿using MediatR;
using SFP.Data.Models;

namespace SFP.Data.Events
{
    public class GroupCreatedDomainEvent : INotification
    {
        public Group Group { get; }

        public GroupCreatedDomainEvent(Group group)
        {
            Group = group;
        }
    }
}
