﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.DTOs
{
    public class SubmissionDto : AuditDto<int>
    {
        public int UserId { get; set; }

        public string Reference { get; set; }

        public string Title { get; set; }

        public string Message { get; set; }

        public Constants.PriorityLevel PriorityLevel { get; set; }



        public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (!string.IsNullOrWhiteSpace(Title))
            {
                if (Title.Length > Constants.MaximumLengths.StringColumn)
                {
                    yield return new ValidationResult($"{nameof(Title)} must be less than {Constants.MaximumLengths.StringColumn} characters.", new[] { nameof(Title) });
                }
            }
            else
            {
                yield return new ValidationResult($"{nameof(Title)} cannot be null or empty.", new[] { nameof(Title) });
            }

            if (!string.IsNullOrWhiteSpace(Message))
            {
                if (Message.Length > Constants.MaximumLengths.StringColumn)
                {
                    yield return new ValidationResult($"{nameof(Message)} must be less than {Constants.MaximumLengths.StringColumn} characters.", new[] { nameof(Message) });
                }
            }
            else
            {
                yield return new ValidationResult($"{nameof(Message)} cannot be null or empty.", new[] { nameof(Message) });
            }
        }
    }
}
