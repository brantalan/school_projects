﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.DTOs
{
    public class UserDto : AuditDto<int>
    {
        public int ProgramId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }
        
        public byte[] Filename { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public bool IsActive { get; set; }

        public bool IsAdmin { get; set; }

        public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (!string.IsNullOrWhiteSpace(FirstName))
            {
                if (FirstName.Length > Constants.MaximumLengths.StringColumn)
                {
                    yield return new ValidationResult($"{nameof(FirstName)} must be less than {Constants.MaximumLengths.StringColumn} characters.", new[] { nameof(FirstName) });
                }
            }
            else
            {
                yield return new ValidationResult($"{nameof(FirstName)} cannot be null or empty.", new[] { nameof(FirstName) });
            }
        }
    }
}
