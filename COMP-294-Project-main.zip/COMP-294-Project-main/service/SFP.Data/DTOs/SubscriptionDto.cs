﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.DTOs
{
    public class SubscriptionDto : AuditDto<int>
    {
        public int SubmissionId { get; set; }

        public int UserId { get; set; }

        public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (SubmissionId < 1)
            {
                yield return new ValidationResult($"{nameof(SubmissionId)} must be greater than zero.", new[] { nameof(SubmissionId) });
            }

            if (UserId < 1)
            {
                yield return new ValidationResult($"{nameof(UserId)} must be greater than zero.", new[] { nameof(UserId) });
            }
        }
    }
}
