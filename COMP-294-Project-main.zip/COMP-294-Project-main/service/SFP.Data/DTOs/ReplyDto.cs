﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFP.Data.DTOs
{
    public class ReplyDto : AuditDto<int>
    {
        public int SubmissionId { get; set; }

        public int UserId { get; set; }

        public string Message { get; set; }

        public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (SubmissionId < 0)
            {
                yield return new ValidationResult($"{nameof(SubmissionId)} must be greater than zero.", new[] { nameof(SubmissionId) });
            }
        }
    }
}
