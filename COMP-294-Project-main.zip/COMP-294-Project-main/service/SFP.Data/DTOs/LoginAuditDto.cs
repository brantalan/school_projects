﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.DTOs
{
    public class LoginAuditDto : AuditDto<int>
    {
        public int UserId { get; set; }

        public System.DateTime DateLoggedIn { get; set; }

        public System.DateTime DateLoggedOut { get; set; }

        public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (UserId < 0)
            {
                yield return new ValidationResult($"{nameof(UserId)} must be greater than zero.", new[] { nameof(UserId) });
            }
        }
    }
}
