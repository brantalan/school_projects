using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SFP.Data.DTOs
{
    public class NotificationDto : AuditDto<int>
    {
        public Constants.NotificationType Type { get; set; }

        // the user whose action triggered the notification
        public int TriggerId { get; set; }

        // the user who is notified
        public int ReceiverId { get; set; }

        public int SubmissionId { get; set; }

        public int ReplyId { get; set; }

        public bool IsRead { get; set; }

        /* CreatedDate field from AuditModel being used in place of DateCreated from the ERD */

        public System.DateTime DateRead { get; set; }

        public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (TriggerId < 1)
            {
                yield return new ValidationResult($"{nameof(TriggerId)} must be greater than zero.", new[] { nameof(TriggerId) });
            }

            if (ReceiverId < 1)
            {
                yield return new ValidationResult($"{nameof(ReceiverId)} must be greater than zero.", new[] { nameof(ReceiverId) });
            }
        }
    }
}