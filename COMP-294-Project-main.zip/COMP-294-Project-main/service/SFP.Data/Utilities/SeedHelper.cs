﻿using AutoMapper;
using SFP.Data.DTOs;
using SFP.Data.Models;
using System;
using System.Linq;

namespace SFP.Data.Utilities
{
    public static class SeedHelper
    {
        public static Group GetRandomGroup(SFPDbContext database)
        {
            return database.Groups.OrderBy(_ => Guid.NewGuid()).First();
        }

        public static Group CreateValidNewGroup(SFPDbContext database, string name = "")
        {
            return new Group()
            {
                Name = name.Length == 0 ? RandomFactory.GetAlphanumericString(8) : name,
                IsActive = RandomFactory.GetBoolean()
            };
        }

        public static GroupDto CreateValidNewGroupDto(SFPDbContext database, IMapper mapper, string name = "")
        {
            var group = CreateValidNewGroup(database, name);

            return mapper.Map<GroupDto>(group);
        }

        public static Project CreateValidNewProject(SFPDbContext database, Group group = null)
        {
            return new Project()
            {
                Name = RandomFactory.GetCodeName(),
                Group = group ?? GetRandomGroup(database)
            };
        }
    }
}
