﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace SFP.Data
{
    public class SFPDbContextFactory : IDesignTimeDbContextFactory<SFPDbContext>
    {
        public SFPDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<SFPDbContext>();
            optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDb;Database=SFP;Trusted_Connection=True;MultipleActiveResultSets=True;");
            return new SFPDbContext(optionsBuilder.Options);
        }
    }
}
