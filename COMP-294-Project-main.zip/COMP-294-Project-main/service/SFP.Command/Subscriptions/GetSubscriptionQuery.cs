﻿using System;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace SFP.Command.Subscription
{
    public class GetSubscriptionQuery : IRequest<SubscriptionDto>
    {
        public int SubmissionId { get; set; }
        public int UserId { get; set; }

    }
    public class GetAllSubscribersQuery : IRequest<IEnumerable<SubscriptionDto>>
    {
        public int SubmissionId { get; set; }
    }

    public class SubscriptionCommandHandler : CommandHandlerBase,
        IRequestHandler<GetSubscriptionQuery, SubscriptionDto>,
        IRequestHandler<GetAllSubscribersQuery, IEnumerable<SubscriptionDto>>
    {
        public SubscriptionCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<SubscriptionDto> Handle(GetSubscriptionQuery request, CancellationToken cancellationToken)
        {
            var submissionId = request.SubmissionId;
            var userId = request.UserId;

            // Search Database for subscription
            var model = await Database.Subscriptions
                .Where(x => x.SubmissionId == submissionId && x.UserId == userId)
                .FirstOrDefaultAsync(cancellationToken);

            // If subscription doesn't exist return bad request.
            if (model == null)
            {
                throw new BadRequestException("You aren't subscribed to this submission.");
            }

            return Mapper.Map<SubscriptionDto>(model);
        }

        public async Task<IEnumerable<SubscriptionDto>> Handle(GetAllSubscribersQuery request, CancellationToken cancellationToken)
        {
            var subId = request.SubmissionId;
            if (subId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.Submission)} id must be provided.");
            }

            var innerResult = await Database.Subscriptions
                .Where(x => x.SubmissionId == subId)
                .Select(x => Mapper.Map<SubscriptionDto>(x))
                .ToListAsync(cancellationToken);

            if (innerResult == null)
            {
                throw new EntityNotFoundException($"No subscribers found for submission with id {request.SubmissionId}.");
            }

            return innerResult;
        }
    }
}
