﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Events;
using SFP.Data.Exceptions;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Subscription
{
    public class CreateSubscriptionCommand : IRequest<SubscriptionDto>
    {
        public SubscriptionDto Subscription { get; set; }
    }

    public class CreateSubscriptionCommandHandler : CommandHandlerBase,
        IRequestHandler<CreateSubscriptionCommand, SubscriptionDto>
    {
        public CreateSubscriptionCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<SubscriptionDto> Handle(CreateSubscriptionCommand request, CancellationToken cancellationToken)
        {
            var dto = request.Subscription;

            bool subscriptionExists = await Database.Subscriptions.AnyAsync(e => e.SubmissionId == dto.SubmissionId && e.UserId == dto.UserId, cancellationToken);
            if (subscriptionExists)
            {
                throw new BadRequestException($"You are already subscribed to this submission.");
            }

            var model = new Data.Models.Subscription()
            {
                SubmissionId = dto.SubmissionId,
                UserId = dto.UserId
            };

            Database.Subscriptions.Add(model);

            await Database.SaveChangesAsync(cancellationToken);

            await Mediator.Publish(new SubscriptionCreatedDomainEvent(model), cancellationToken);

            return Mapper.Map<SubscriptionDto>(model);
        }
    }
}
