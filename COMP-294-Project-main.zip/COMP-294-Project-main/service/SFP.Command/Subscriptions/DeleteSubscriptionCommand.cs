﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Subscription
{
    public class DeleteSubscriptionCommand : IRequest<bool>
    {
        public int SubmissionId { get; set; }
        public int UserId { get; set; }
    }

    public class DeleteSubscriptionCommandHandler : CommandHandlerBase,
        IRequestHandler<DeleteSubscriptionCommand, bool>
    {
        public DeleteSubscriptionCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<bool> Handle(DeleteSubscriptionCommand request, CancellationToken cancellationToken)
        {
            var submissionId = request.SubmissionId;
            var userId = request.UserId;

            // Search Database for subscription
            var model = await Database.Subscriptions
                .Where(x => x.SubmissionId == submissionId && x.UserId == userId)
                .FirstOrDefaultAsync(cancellationToken);


            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Subscription)} not found.");
            }

            Database.Subscriptions.Remove(model);

            await Database.SaveChangesAsync(cancellationToken);

            Debug.Assert(Database.Subscriptions.Find(model.Id) == null);

            return true;
        }
    }
}
