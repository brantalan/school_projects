﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;

namespace SFP.Command
{
    /// <summary>
	/// Base class of all command handlers.
	/// </summary>
    public abstract class CommandHandlerBase : HandlerBase
    {
        protected CommandHandlerBase(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }
    }
}
