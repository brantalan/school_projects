﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Events;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Reply
{
    public class CreateReplyCommand : IRequest<ReplyDto>
    {
        public ReplyDto Reply { get; set; }
    }

    public class CreateReplyCommandHandler : CommandHandlerBase,
        IRequestHandler<CreateReplyCommand, ReplyDto>
    {
        public CreateReplyCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<ReplyDto> Handle(CreateReplyCommand request, CancellationToken cancellationToken)
        {
            var dto = request.Reply;

            var model = new Data.Models.Reply()
            {
                SubmissionId = dto.SubmissionId,
                UserId = dto.UserId,
                Message = dto.Message,

            };

            Database.Replies.Add(model);

            await Database.SaveChangesAsync(cancellationToken);

            await Mediator.Publish(new ReplyCreatedDomainEvent(model), cancellationToken);

            return Mapper.Map<ReplyDto>(model);
        }
    }
}
