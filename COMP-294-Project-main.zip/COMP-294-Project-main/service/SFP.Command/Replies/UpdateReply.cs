﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Reply
{
    public class UpdateReplyCommand : IRequest<ReplyDto>
    {
        public ReplyDto Reply { get; set; }
    }


    public class UpdateReplyCommandHandler : CommandHandlerBase,
        IRequestHandler<UpdateReplyCommand, ReplyDto>
    {
        public UpdateReplyCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<ReplyDto> Handle(UpdateReplyCommand request, CancellationToken cancellationToken)
        {
            var dto = request.Reply;

            var model = await Database.Replies
                .Where(x => x.Id == dto.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Reply)} with Id {dto.Id} not found.");
            }

            model.Message = dto.Message;

            Database.Replies.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return Mapper.Map<ReplyDto>(model);
        }
    }
}
