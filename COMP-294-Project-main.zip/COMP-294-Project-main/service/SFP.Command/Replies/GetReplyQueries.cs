﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Reply
{
    public class GetAllForSubmissionQuery : IRequest<IEnumerable<ReplyDto>>
    {
        public int SubmissionId { get; set; }
    }

    public class GetReplyByIdQuery : IRequest<ReplyDto>
    {
        public int ReplyId { get; set; }
    }

    public class ReplyQueryHandler : QueryHandlerBase,
        IRequestHandler<GetAllForSubmissionQuery, IEnumerable<ReplyDto>>,
        IRequestHandler<GetReplyByIdQuery, ReplyDto>
    {
        public ReplyQueryHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        // GET BY SUBMISSION ID
        public async Task<IEnumerable<ReplyDto>> Handle(GetAllForSubmissionQuery request, CancellationToken cancellationToken)
        {
            var subId = request.SubmissionId;
            if (subId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.Submission)} id must be provided.");
            }

            var innerResult = await Database.Replies
                .Where(x => x.SubmissionId == subId)
                .OrderByDescending(x => x.CreatedDate)
                .Select(x => Mapper.Map<ReplyDto>(x))
                .ToListAsync(cancellationToken);    
                
            if (innerResult == null)
            {
                throw new EntityNotFoundException($"No replies found for submission with id {request.SubmissionId}.");
            }

            return innerResult;
        }

        // GET BY REPLY ID
        public async Task<ReplyDto> Handle(GetReplyByIdQuery request, CancellationToken cancellationToken)
        {
            if (request.ReplyId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.Reply)} id must be provided.");
            }

            var innerResult = await Database.Replies.FindAsync(new object[] { request.ReplyId }, cancellationToken);
            if (innerResult == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Reply)} with id {request.ReplyId} cannot be found.");
            }

            return Mapper.Map<ReplyDto>(innerResult);
        }
    }
}
