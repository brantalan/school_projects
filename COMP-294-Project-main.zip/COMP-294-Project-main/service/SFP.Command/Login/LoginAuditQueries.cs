﻿using System;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace SFP.Command.LoginAudit
{

    public class GetAllAuditsQuery : IRequest<IEnumerable<LoginAuditDto>> { }

    public class GetAuditByIdQuery : IRequest<LoginAuditDto>
    {
        public int UserId { get; set; }
    }

    public class LoginAuditQueryHandler : QueryHandlerBase,
    IRequestHandler<GetAllAuditsQuery, IEnumerable<LoginAuditDto>>,
    IRequestHandler<GetAuditByIdQuery, LoginAuditDto>
    {
        public LoginAuditQueryHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        // GET ALL
        public async Task<IEnumerable<LoginAuditDto>> Handle(GetAllAuditsQuery request, CancellationToken cancellationToken)
        {
            return await Database.LoginAudit
                .Select(x => Mapper.Map<LoginAuditDto>(x))
                .ToListAsync(cancellationToken);
        }

        public async Task<LoginAuditDto> Handle(GetAuditByIdQuery request, CancellationToken cancellationToken)
        {
            var userId = request.UserId;
            if (request.UserId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.User)} Id must be provided.");
            }

            var innerResult = await Database.LoginAudit
                .Where(x => x.UserId == userId)
                .OrderByDescending(x => x.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (innerResult == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.LoginAudit)} with Id {request.UserId} cannot be found.");
            }

            return Mapper.Map<LoginAuditDto>(innerResult);
        }
    }
}