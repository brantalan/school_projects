﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Events;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.LoginAudit
{
    public class CreateLoginAuditCommand : IRequest<LoginAuditDto>
    {
        public LoginAuditDto LoginAudit { get; set; }
    }

    public class CreateLoginAuditCommandHandler : CommandHandlerBase,
        IRequestHandler<CreateLoginAuditCommand, LoginAuditDto>
    {
        public CreateLoginAuditCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<LoginAuditDto> Handle(CreateLoginAuditCommand request, CancellationToken cancellationToken)
        {
            var dto = request.LoginAudit;

            var model = new Data.Models.LoginAudit()
            {
                UserId = dto.UserId,
                DateLoggedIn = dto.DateLoggedIn,
                DateLoggedOut = dto.DateLoggedOut
            };

            Database.LoginAudit.Add(model);

            await Database.SaveChangesAsync(cancellationToken);

            await Mediator.Publish(new LoginAuditCreatedDomainEvent(model), cancellationToken);

            return Mapper.Map<LoginAuditDto>(model);
        }
    }
}
