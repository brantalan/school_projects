﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.LoginAudit
{
    public class UpdateLoginAuditCommand : IRequest<LoginAuditDto>
    {
        public LoginAuditDto LoginAudit { get; set; }
    }


    public class UpdateLoginAuditCommandHandler : CommandHandlerBase,
        IRequestHandler<UpdateLoginAuditCommand, LoginAuditDto>
    {
        public UpdateLoginAuditCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<LoginAuditDto> Handle(UpdateLoginAuditCommand request, CancellationToken cancellationToken)
        {
            var dto = request.LoginAudit;

            if (dto.Id < 0)
            {
                throw new BadRequestException($"{nameof(Data.Models.LoginAudit)} Id must be greater than zero.");
            }

            var model = await Database.LoginAudit
                .Where(x => x.Id == dto.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.LoginAudit)} with Id {dto.Id} not found.");
            }

            model.DateLoggedOut = System.DateTime.Now;

            Database.LoginAudit.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return Mapper.Map<LoginAuditDto>(model);
        }
    }
}
