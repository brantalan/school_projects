﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Events;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Submission
{
    public class CreateSubmissionCommand : IRequest<SubmissionDto>
    {
        public SubmissionDto Submission { get; set; }
    }

    public class CreateSubmissionCommandHandler : CommandHandlerBase,
        IRequestHandler<CreateSubmissionCommand, SubmissionDto>
    {
        public CreateSubmissionCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<SubmissionDto> Handle(CreateSubmissionCommand request, CancellationToken cancellationToken)
        {
            var dto = request.Submission;

            bool TitleMissing = await Database.Submissions.AnyAsync(e => e.Title.Length <1, cancellationToken);
            if (TitleMissing)
            {
                throw new BadRequestException($"{nameof(dto.Title)} '{dto.Title}' missing");
            }
            var chars = "abcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[5];
            var random = new System.Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            var finalString = new System.String(stringChars);
            var model = new Data.Models.Submission()
            {
                UserId = dto.UserId,
                Reference = finalString,
                Title = dto.Title,
                Message = dto.Message,
                PriorityLevel = dto.PriorityLevel

            };

            

        Database.Submissions.Add(model);

            await Database.SaveChangesAsync(cancellationToken);

            await Mediator.Publish(new SubmissionCreatedDomainEvent(model), cancellationToken);

            return Mapper.Map<SubmissionDto>(model);
        }
    }
}
