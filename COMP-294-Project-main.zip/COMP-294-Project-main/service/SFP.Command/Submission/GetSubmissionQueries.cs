﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Submission
{
    public class GetAllSubmissionsQuery : IRequest<IEnumerable<SubmissionDto>> {
        public int UserId { get; set; }
    }


    public class GetSubmissionByIdQuery : IRequest<SubmissionDto>
    {
        public int SubmissionId { get; set; }
        public int UserId { get; set; }

        public bool IsAdmin { get; set; }
    }



    public class SubmissionQueryHandler : QueryHandlerBase,
        IRequestHandler<GetAllSubmissionsQuery, IEnumerable<SubmissionDto>>,
        IRequestHandler<GetSubmissionByIdQuery, SubmissionDto>
    {
        public SubmissionQueryHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        // get all submissions
        public async Task<IEnumerable<SubmissionDto>> Handle(GetAllSubmissionsQuery request, CancellationToken cancellationToken)
        {
            if (request.UserId >=1 )
                {

                    var innerResult = await Database.Submissions.Where(x => x.UserId == request.UserId).ToListAsync(cancellationToken);
                    if (innerResult == null)
                    {
                        throw new EntityNotFoundException($"{nameof(Data.Models.Submission)} with Id {request.UserId} cannot be found.");
                    }

                    return Mapper.Map<IEnumerable<SubmissionDto>>(innerResult);
                }
            else
            {
                return await Database.Submissions
                    .Select(x => Mapper.Map<SubmissionDto>(x))
                    .ToListAsync(cancellationToken);
            }
        }

        //get by id
        public async Task<SubmissionDto> Handle(GetSubmissionByIdQuery request, CancellationToken cancellationToken)
        {
            var submissionId = request.SubmissionId;
            var userId = request.UserId;

            if (submissionId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.Submission)} Id must be provided.");
            }

            // constrain submissions to the specified user
            var innerResult = userId > 0 ? 
                await Database.Submissions.Where(x => x.Id == request.SubmissionId && x.UserId == request.UserId).FirstOrDefaultAsync(cancellationToken)
                :
                await Database.Submissions.Where(x => x.Id == request.SubmissionId).FirstOrDefaultAsync(cancellationToken);

            if (innerResult == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Submission)} with Id {request.UserId} cannot be found.");
            }

            return Mapper.Map<SubmissionDto>(innerResult);
        }
    }
}
