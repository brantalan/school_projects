﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Submission
{
    public class UpdateSubmissionCommand : IRequest<SubmissionDto>
    {
        public SubmissionDto Submission { get; set; }
    }

    public class UpdateSubmissionCommandHandler : CommandHandlerBase,
        IRequestHandler<UpdateSubmissionCommand, SubmissionDto>
    {
        public UpdateSubmissionCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<SubmissionDto> Handle(UpdateSubmissionCommand request, CancellationToken cancellationToken)
        {
            var dto = request.Submission;

            if (dto.Id <= 0)
            {
                throw new BadRequestException($"{nameof(Data.Models.Submission)} Id must be greater than zero.");
            }

            var model = await Database.Submissions
                .Where(x => x.Id == dto.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Submission)} with Id {dto.Id} not found.");
            }
            model.Title = dto.Title;
            model.Message = dto.Message;
            model.PriorityLevel = dto.PriorityLevel;




            Database.Submissions.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return Mapper.Map<SubmissionDto>(model);
        }
    }
}