﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Program
{
    public class GetAllProgramsQuery : IRequest<IEnumerable<ProgramDto>> { }

    public class GetProgramByIdQuery : IRequest<ProgramDto>
    {
        public int ProgramId { get; set; }
    }

    public class ProgramQueryHandler : QueryHandlerBase,
        IRequestHandler<GetAllProgramsQuery, IEnumerable<ProgramDto>>,
        IRequestHandler<GetProgramByIdQuery, ProgramDto>
    {
        public ProgramQueryHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        // GET ALL
        public async Task<IEnumerable<ProgramDto>> Handle(GetAllProgramsQuery request, CancellationToken cancellationToken)
        {
            return await Database.Programs
                .Select(x => Mapper.Map<ProgramDto>(x))
                .ToListAsync(cancellationToken);
        }

        // GET BY ID
        public async Task<ProgramDto> Handle(GetProgramByIdQuery request, CancellationToken cancellationToken)
        {
            if (request.ProgramId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.Program)} Id must be provided.");
            }

            var innerResult = await Database.Programs.FindAsync(new object[] { request.ProgramId }, cancellationToken);
            if (innerResult == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Program)} with Id {request.ProgramId} cannot be found.");
            }

            return Mapper.Map<ProgramDto>(innerResult);
        }
    }
}
