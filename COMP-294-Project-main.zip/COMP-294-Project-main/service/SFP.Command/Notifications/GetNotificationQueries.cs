using System;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace SFP.Command.Notification
{
    public class GetNotificationQuery : IRequest<NotificationDto>
    {
        public int Id { get; set; }

    }
    public class GetAllNotificationsQuery : IRequest<IEnumerable<NotificationDto>>
    {
        public int UserId { get; set; }
        public bool? IsNew { get; set; }
    }

    public class NotificationCommandHandler : CommandHandlerBase,
        IRequestHandler<GetNotificationQuery, NotificationDto>,
        IRequestHandler<GetAllNotificationsQuery, IEnumerable<NotificationDto>>

    {
        public NotificationCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<NotificationDto> Handle(GetNotificationQuery request, CancellationToken cancellationToken)
        {
            var id = request.Id;

            // Search Database for Notification
            var model = await Database.Notifications
                .Where(x => x.Id == id)
                .FirstOrDefaultAsync(cancellationToken);

            // If Notification doesn't exist return bad request.
            if (model == null)
            {
                throw new BadRequestException("No notification exists");
            }

            return Mapper.Map<NotificationDto>(model);
        }

        public async Task<IEnumerable<NotificationDto>> Handle(GetAllNotificationsQuery request, CancellationToken cancellationToken)
        {
            var userId = request.UserId;
            var isNew = request.IsNew;
            
            if (userId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.Notification)} id must be provided.");
            }
            if (isNew != null)
            {
                //new notifications will have their isRead flag set to false, so we'll just use the opposite of what was provided in the request
                var innerResult = await Database.Notifications
               .Where(x => x.ReceiverId == userId && x.IsRead == !isNew)
               .OrderByDescending(x => x.CreatedDate)
               .Select(x => Mapper.Map<NotificationDto>(x))
               .ToListAsync(cancellationToken);
                if (innerResult == null)
                {
                    throw new EntityNotFoundException($"No notifications found for notification with user id {request.UserId}.");
                }

                return innerResult;
            }
            else
            {
                var innerResult = await Database.Notifications
                    .Where(x => x.ReceiverId == userId)
                    .OrderBy(x => x.IsRead)
                    .ThenByDescending(x => x.CreatedDate)
                    .Select(x => Mapper.Map<NotificationDto>(x))
                    .ToListAsync(cancellationToken);
                if (innerResult == null)
                {
                    throw new EntityNotFoundException($"No notifications found for notification with user id {request.UserId}.");
                }

                return innerResult;   
            }

   
        }
    }
}
