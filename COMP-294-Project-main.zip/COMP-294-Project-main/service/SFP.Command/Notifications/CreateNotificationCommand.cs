using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Events;
using SFP.Data.Exceptions;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Notification
{
    public class CreateNotificationCommand : IRequest<NotificationDto>
    {
        public NotificationDto Notification { get; set; }
    }

    public class CreateNotificationCommandHandler : CommandHandlerBase,                   
        IRequestHandler<CreateNotificationCommand, NotificationDto>
    {
        public CreateNotificationCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<NotificationDto> Handle(CreateNotificationCommand request, CancellationToken cancellationToken)
        {
            var dto = request.Notification;

            var model = new Data.Models.Notification()
            {
                Type = dto.Type,
                TriggerId = dto.TriggerId,
                ReceiverId = dto.ReceiverId,
                SubmissionId = dto.SubmissionId,
                ReplyId = dto.ReplyId,
                IsRead = false,// by default, any new notification entry will be unread
                DateRead = dto.DateRead
            };

            Database.Notifications.Add(model);

            await Database.SaveChangesAsync(cancellationToken);

            await Mediator.Publish(new NotificationCreatedDomainEvent(model), cancellationToken);

            return Mapper.Map<NotificationDto>(model);
        }
    }
}
