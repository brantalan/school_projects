using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.Notification
{
    public class UpdateNotificationCommand : IRequest<NotificationDto>
    {
        public int Id { get; set; }
        public bool IsRead { get; set; }
    }


    public class UpdateNotificationCommandHandler : CommandHandlerBase,
        IRequestHandler<UpdateNotificationCommand, NotificationDto>
    {
        public UpdateNotificationCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<NotificationDto> Handle(UpdateNotificationCommand request, CancellationToken cancellationToken)
        {
            var id = request.Id;
            var isRead = request.IsRead;
            var dateRead = (isRead) ? System.DateTime.Now : default;

            var model = await Database.Notifications
                .Where(x => x.Id == id)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.Notification)} with Id {id} not found.");
            }

            model.IsRead = isRead;
            model.DateRead = dateRead;

            Database.Notifications.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return Mapper.Map<NotificationDto>(model);
        }
    }
}
