
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

public static class Authenticator 
{

        /**
        * Hashes password using sha-512 algo given a string pwd and salt in the form of a byte array. 
        */
        public static byte[] HashPass(string pwd, byte[] salt) => 
            KeyDerivation.Pbkdf2(
                password: pwd, 
                salt: salt, 
                prf: KeyDerivationPrf.HMACSHA512,
                iterationCount: 10000,
                numBytesRequested: 32
            );
            /**
            * Creates a salt byte array from a random number. 
            */
            public static byte[] GetSalt ()
            {
            var rng = RandomNumberGenerator.Create();
            var salt = new byte[16];
            rng.GetBytes(salt);
            return salt;
            } 
}