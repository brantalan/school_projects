using AutoMapper;
using MediatR;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace SFP.Command.User
{
    public class UploadPictureCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public byte[] Filename { get; set; }
    }

    public class UploadPictureCommandHandler : CommandHandlerBase,
        IRequestHandler<UploadPictureCommand, bool>
    {
        public UploadPictureCommandHandler(
        IMediator mediator,
        SFPDbContext database,
        IMapper mapper,
        IAuthorizationService authorizationService)
        : base(mediator, database, mapper, authorizationService)
        {
        }

        // UPLOAD PICTURE
        public async Task<bool> Handle(UploadPictureCommand request, CancellationToken cancellationToken)
        {
            var file = request.Filename;
            var userId = request.UserId;
            var model = await Database.Users
                .Where(x => x.Id == userId)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.User)} with Id {userId} not found.");
            }
            
            model.Filename = file;

            Database.Users.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return true;
        }
    }
}
