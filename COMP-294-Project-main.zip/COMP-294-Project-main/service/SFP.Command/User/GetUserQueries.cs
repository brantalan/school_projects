﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.User
{
    public class GetAllUsersQuery : IRequest<IEnumerable<UserDto>> { }

    public class GetUserByIdQuery : IRequest<UserDto>
    {
        public int UserId { get; set; }
    }

    public class UserQueryHandler : QueryHandlerBase,
        IRequestHandler<GetAllUsersQuery, IEnumerable<UserDto>>,
        IRequestHandler<GetUserByIdQuery, UserDto>
    {
        public UserQueryHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        // GET ALL
        public async Task<IEnumerable<UserDto>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
        {
            return await Database.Users
                .Select(x => Mapper.Map<UserDto>(x))
                .ToListAsync(cancellationToken);
        }

        // GET BY ID
        public async Task<UserDto> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
        {
            if (request.UserId <= 0)
            {
                throw new BadRequestException($"A valid {nameof(Data.Models.User)} Id must be provided.");
            }

            var innerResult = await Database.Users.FindAsync(new object[] { request.UserId }, cancellationToken);
            if (innerResult == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.User)} with Id {request.UserId} cannot be found.");
            }

            return Mapper.Map<UserDto>(innerResult);
        }
    }
}
