using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.User
{
    public class UpdateUserCommand : IRequest<UserDto>
    {
        public UserDto User { get; set; }
    }

    public class UpdatePasswordCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public string Password { get; set; }
    }

    public class UpdateUserCommandHandler : CommandHandlerBase,
        IRequestHandler<UpdateUserCommand, UserDto>,
        IRequestHandler<UpdatePasswordCommand, bool>
    {
            public UpdateUserCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        // UPDATE ALL DETAILS OF USER
        public async Task<UserDto> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var dto = request.User;
            var model = await Database.Users
                .Where(x => x.Id == dto.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.User)} with Id {dto.Id} not found.");
            }

            model.FirstName = dto.FirstName;
            model.LastName = dto.LastName;
            model.ProgramId = dto.ProgramId;
            model.Phone = dto.Phone;
            model.Email = dto.Email;
            model.IsActive = dto.IsActive;
            model.IsAdmin = dto.IsAdmin;

            Database.Users.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return Mapper.Map<UserDto>(model);
        }
        
        // UPDATE USER PASSWORD ONLY
        public async Task<bool> Handle(UpdatePasswordCommand request, CancellationToken cancellationToken)
        {
            var userId = request.UserId;
            var password = request.Password;

            var model = await Database.Users
                .Where(x => x.Id == userId)
                .FirstOrDefaultAsync(cancellationToken);

            if (model == null)
            {
                throw new EntityNotFoundException($"{nameof(Data.Models.User)} with Id {userId} not found.");
            }
            /** Create new salt and hash password */
            var salt = Authenticator.GetSalt();
            var hash = Authenticator.HashPass(password, salt);
            model.Password = hash;
            model.Salt = salt;
            
            Database.Users.Update(model);

            await Database.SaveChangesAsync(cancellationToken);

            return true;
        }
    }
}
