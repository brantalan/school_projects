﻿using System;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SFP.Command.User
{
    public class UserLogInCommand : IRequest<UserDto>
    {
        public string Username { get; set; }
        public string Password { get; set; }

    }

    public class UserLogInCommandHandler : CommandHandlerBase,
        IRequestHandler<UserLogInCommand, UserDto>
    {
        public UserLogInCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }

        public async Task<UserDto> Handle(UserLogInCommand request, CancellationToken cancellationToken)
        {
            var username = request.Username;
            var password = request.Password;

            // Search Database for user
            var model = await Database.Users
                .Where(x => x.Username == username && x.IsActive == true)
                .FirstOrDefaultAsync(cancellationToken);
            var dbHash = model.Password;
            
            //Get hash from Authenticator class use SequenceEqual below to compare the byte arrays. 
            var salt = model.Salt;
            var inputHash = Authenticator.HashPass(password, salt);

            // If User doesn't exist return bad request.
            if (model == null || !inputHash.SequenceEqual(dbHash))
            {
                throw new BadRequestException("Invalid username and password.");
            }

            return Mapper.Map<UserDto>(model);
        }
    }
}
