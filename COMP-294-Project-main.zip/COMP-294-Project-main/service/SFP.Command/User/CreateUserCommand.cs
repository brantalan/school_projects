﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using SFP.Data;
using SFP.Data.DTOs;
using SFP.Data.Events;
using SFP.Data.Exceptions;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using System;

using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace SFP.Command.User
{
    public class CreateUserCommand : IRequest<UserDto>
    {
        public UserDto User { get; set; }
    }

    public class CreateUserCommandHandler : CommandHandlerBase,
        IRequestHandler<CreateUserCommand, UserDto>
    {
        public CreateUserCommandHandler(
            IMediator mediator,
            SFPDbContext database,
            IMapper mapper,
            IAuthorizationService authorizationService)
            : base(mediator, database, mapper, authorizationService)
        {
        }


        
        public async Task<UserDto> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            var dto = request.User;

            bool userNameAlreadyUsed = await Database.Users.AnyAsync(e => e.Username.Trim() == dto.Username.Trim(), cancellationToken);
            if (userNameAlreadyUsed)
            {
                throw new BadRequestException($"{nameof(dto.Username)} '{dto.Username}' already used.");
            }
            /** Create salt and hash password */ 
            var salt = Authenticator.GetSalt();
            var hash = Authenticator.HashPass(dto.Password, salt);


            var model = new Data.Models.User()
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Username = dto.Username,
                Password = hash,
                ProgramId = dto.ProgramId,
                Phone = dto.Phone,
                Email = dto.Email,
                IsActive = dto.IsActive,
                IsAdmin = dto.IsAdmin,
                Salt = salt
            };

            Database.Users.Add(model);

            await Database.SaveChangesAsync(cancellationToken);

            await Mediator.Publish(new UserCreatedDomainEvent(model), cancellationToken);

            return Mapper.Map<UserDto>(model);
        }
    }
}
