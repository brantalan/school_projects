﻿using SFP.Data.DTOs;
using SFP.Data.Utilities;

namespace SFP.Test.Tests.Integration.Group
{
    public abstract class BaseGroupTest : BaseIntegrationTest
    {
        protected static GroupDto GetGroupDto()
        {
            return new GroupDto()
            {
                Name = RandomFactory.GetCompanyName(),
                IsActive = RandomFactory.GetBoolean()
            };
        }
    }
}
