/**
 * Returns the first value associated to the given search parameter.
 */
export function getUrlParamValue(param: string): string {
    const url = document.location.search || document.location.href;
    let urlParams = new URLSearchParams(url.substring(1));
    return urlParams.get(param) || '';
}
export function getDateString(date: string) {
    let arr = date.split(' ');
    let time = arr[4].trim();
    let hours = time.split(':')[0];
    let hoursNum = parseInt(hours);
    let amPm = '';
    if (hoursNum >= 12) {
        amPm = 'PM';
    } else {
        amPm = 'AM';
    }
    hoursNum = ((hoursNum + 11) % 12) + 1;
    time = hoursNum.toString() + ':' + time.split(':')[1] + ' ' + amPm;
    let timeArr = [];
    timeArr[0] = arr[0];
    timeArr[1] = arr[1];
    timeArr[2] = arr[2];
    timeArr[3] = time;
    return timeArr.join(' ');
}
