import 'office-ui-fabric-react/dist/css/fabric.css';
import { initializeIcons, Nav, Text, Callout, INavLink, mergeStyleSets } from '@fluentui/react';
import React from 'react';
import Submissions from 'app/pages/submissions/Submissions';
import EditReply from 'app/pages/submissions/EditReply';
import SubmissionView from 'app/pages/submissions/SubmissionView';
import Notifications from 'app/pages/notifications/Notifications';
import Users from 'app/pages/users/Users';
import Profile from 'app/pages/users/Profile';
import UsersView from 'app/pages/users/UsersView';
import Login from 'app/Login';
import sfpCookies from 'app/components/SFPCookies';
import sfpAuth from 'app/components/SFPAuth';
import { BrowserRouter, Route } from 'react-router-dom';
import * as serviceWorker from '../serviceWorker';
import styles from './App.module.scss';
import { ApiClient, LoginAuditDto } from './generated/backend';
import CreateUser from 'app/pages/users/CreateUser';
import CreateSubmission from './pages/submissions/CreateSubmission';
import EditSubmission from './pages/submissions/EditSubmission';
import UserAccountEdit from './pages/users/UserAccountEdit';
import { useEffect, useState } from 'react';

initializeIcons();

const App: React.FC = () => {
    const [notificationTitle, setNotificationTitle] = useState('Notifications');
    const [showNotification, setShowNotification] = useState(false);

    /**
     * Runs the notifications alert process.
     */
    useEffect(() => {
        //Don't show notification alerts if on the notifiactions page.
        if (window.location.href === 'http://localhost:3000/notifications') {
            setShowNotification(false);
        }

        let id = sfpCookies.get('userId');
        if (id !== undefined) {
            //If user just logged in run once
            if (new Date().getTime() - new Date(sfpCookies.get('lastCheck')).getTime() > 500) {
                checkNotifications(id);
            }
            //Check continously every 5 seconds
            setInterval(async () => {
                console.log('check');
                checkNotifications(id);
            }, 5000);
        }
    }, []);

    if (!sfpAuth.isLoggedIn()) {
        return <Login />;
    }

    /**
     * Checks for unread notifications.
     * If unread notifications are found newer than the last check, it shows
     * an alert on the page. If this occurs while the user is on the notifications
     * page, it refreshes to page to show the new notifications.
     * @param userId
     */
    async function checkNotifications(userId: number, force = false) {
        try {
            let notifications = await new ApiClient(process.env.REACT_APP_API_BASE).notification_GetAllNotifications(
                userId,
                true
            );

            //This process controls the notification alert
            if (sfpCookies.get('lastCheck') !== undefined) {
                notifications.forEach((notification) => {
                    if (new Date(notification.createdDate) > new Date(sfpCookies.get('lastCheck'))) {
                        if (window.location.href === 'http://localhost:3000/notifications') {
                            window.location.href = 'http://localhost:3000/notifications';
                        } else {
                            setShowNotification(true);
                        }
                    }
                });
            }

            //This process controls the notification count on the side bar
            sfpCookies.set('lastCheck', new Date());
            if (notifications.length > 0) {
                setNotificationTitle('Notifications (' + notifications.length.toString() + ')');
            } else {
                setNotificationTitle('Notifications');
            }
        } catch (e) {
            console.log(e);
        }
    }

    // anywhere past this point means the user is logged in

    async function logOut(e: any) {
        e.preventDefault();

        try {
            let dto = new LoginAuditDto();
            dto.init({
                id: sfpCookies.get('userLoginId')
            });

            await new ApiClient(process.env.REACT_APP_API_BASE).loginAudit_UpdateLogOutTime(dto);

            sfpCookies.remove('userName');
            sfpCookies.remove('userLoginId');
            sfpCookies.remove('isAdmin');
            sfpCookies.remove('userId');
            sfpCookies.remove('lastCheck');
            window.location.href = '/';
        } catch (e) {
            // logout procedure failed
            console.log(JSON.parse(e.response));
        }
    }

    const renderDefaultRoute = () => {
        window.location.href = '/submissions';
        return '';
    };

    // nav links common to all types of users
    const navLinks: INavLink[] = [
        {
            name: 'Submissions',
            url: '/submissions',
            key: 'submissions'
        },
        {
            name: notificationTitle,
            url: '/notifications',
            key: 'notifications'
        },
        {
            name: 'Logout',
            key: 'logout',
            url: '',
            onClick: logOut,
            forceAnchor: true
        }
    ];

    // only admin users have the Users nav link
    if (sfpAuth.isAdmin()) {
        navLinks.splice(2, 0, {
            name: 'Users',
            url: '/users',
            key: 'users'
        });
    } else {
        navLinks.splice(2, 0, {
            name: 'Profile',
            url: '/profile',
            key: 'profile'
        });
    }

    function goToNotifications() {
        window.location.href = '/notifications';
    }
    const calloutStyles = mergeStyleSets({
        callout: {
            width: 320,
            padding: '5px 2px',
            paddingTop: 0,
            background: '#50e2fa'
        },
        title: {
            marginBottom: 12
        },
        actions: {
            marginTop: 20
        }
    });
    const buttonId = 'id';
    return (
        <BrowserRouter>
            <React.Fragment>
                <div className="ms-Grid" dir="ltr">
                    <div className="ms-Grid-row">
                        <div className={styles.header}>
                            <Text className={styles.headerTitle} title="Student Feedback Portal">
                                SFP
                            </Text>
                            <div
                                id={'id'}
                                style={{
                                    marginLeft: 750,
                                    display: 'grid',
                                    gridAutoFlow: 'column',
                                    paddingTop: 40
                                }}></div>
                            {showNotification ? (
                                <Callout
                                    className={calloutStyles.callout}
                                    isBeakVisible={false}
                                    coverTarget
                                    target={`#${buttonId}`}>
                                    <div style={{ display: 'grid', gridAutoFlow: 'column', background: '#50e2fa' }}>
                                        <div
                                            style={{
                                                textAlign: 'center',
                                                display: 'grid',
                                                paddingTop: 20,
                                                marginLeft: 60
                                            }}>
                                            <span style={{ paddingBottom: 5 }}> You have new notifications!</span>
                                            <button
                                                style={{
                                                    backgroundColor: '#a2dee8',
                                                    cursor: 'pointer',
                                                    border: 'none',
                                                    fontSize: 10
                                                }}
                                                onClick={() => goToNotifications()}>
                                                See Notifications
                                            </button>
                                        </div>
                                        <div className={calloutStyles.title}>
                                            <span
                                                onClick={(e) => setShowNotification(false)}
                                                className={styles.closeButton}
                                                style={{ right: 0, marginTop: 0, marginLeft: 40, top: 0 }}>
                                                &times;
                                            </span>
                                        </div>
                                    </div>
                                </Callout>
                            ) : (
                                <div></div>
                            )}
                            <Text></Text>
                            <Text className={styles.loggedInDisplay}>
                                Logged in as <a href="/profile">{sfpCookies.get('userName')}</a>
                            </Text>
                        </div>
                        <div className={'ms-Grid-col ms-sm12 ms-lg4 ms-xl2'}>
                            <Nav
                                groups={[
                                    {
                                        collapseAriaLabel: 'Collapse',
                                        expandAriaLabel: 'Expand',
                                        links: navLinks
                                    }
                                ]}
                            />
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-lg8 msxl-10">
                            <Route path="/" exact={true} render={() => renderDefaultRoute()} />
                            <Route path="/submissions" exact={true} component={Submissions} />
                            {/** Pass check notification function to notificatoins comp to sync when marking read/unread */}
                            <Route
                                path="/notifications"
                                render={() => <Notifications notificationCheck={checkNotifications}></Notifications>}
                            />
                            <Route path="/users" exact={true} component={Users} />
                            <Route path="/users/create" exact={true} component={CreateUser} />
                            <Route path="/users/view" component={UsersView} />
                            <Route path="/profile" exact={true} component={Profile} />
                            <Route path="/submissions/view" component={SubmissionView} />
                            <Route path="/submissions/create" component={CreateSubmission} />
                            <Route path="/submissions/edit" component={EditSubmission} />
                            <Route path="/replies/edit" component={EditReply} />
                            {/** By passing the component through render, we can pass props to it like location. */}
                            <Route path="/users/edit/" render={() => <UserAccountEdit location="users"></UserAccountEdit>} />
                            <Route
                                path="/profile/edit/"
                                exact={true}
                                render={() => <UserAccountEdit location="profile"></UserAccountEdit>}
                            />
                        </div>
                    </div>
                </div>
            </React.Fragment>
        </BrowserRouter>
    );
};

export default App;

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
