import React, { useState } from 'react';
import { IIconProps, Text, TextField, Modal, PrimaryButton, Link } from '@fluentui/react';
import styles from './App.module.scss';
import SignUp from 'app/signup';
import sfpCookies from 'app/components/SFPCookies';
import { ApiClient, LoginAuditDto } from './generated/backend';

/**
 * Hanldes Login component and login functionality with the backend.
 * @param props
 * @returns
 */
const Login: React.FC = (props) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loginErr, setErr] = useState(false);
    const [signUp, showSignUp] = useState(false);
    const [signedUpMsg, setSignUpMsg] = useState('');
    const [childData, setChildData] = useState(true);
    const sendIcon: IIconProps = { iconName: 'Send' };
    const msg = <Text style={{ color: '#FF0000' }}>Your username or password was incorrect. Please try again.</Text>;

    const handleSubmit = async (e: any) => {
        //Handle backend login confirmation and cookie logic
        e.preventDefault();
        if (username !== '' && password !== '') {
            try {
                /**Make API Call to login, create audit dto, and call api to create new login audit.  */
                const result = await new ApiClient(process.env.REACT_APP_API_BASE).users_LogInUser(username, password);
                let dto = new LoginAuditDto();
                let date = new Date();
                date.setHours(date.getHours() - 4); // Make time zone agree with our DB timezone.
                dto.init({
                    userId: result.id,
                    dateLoggedIn: date
                });

                const auditResult = await new ApiClient(process.env.REACT_APP_API_BASE).loginAudit_CreateLoginAudit(dto);

                sfpCookies.set('userLoginId', auditResult.id);
                sfpCookies.set('isAdmin', result.isAdmin);
                sfpCookies.set('userId', result.id);
                sfpCookies.set('userName', `${result.firstName} ${result.lastName}`);

                window.location.href = '/submissions';
            } catch (e) {
                setErr(true);
            }
        } else {
            setErr(!loginErr);
        }
    };
    function updateSignedUp(e: any) {
        setChildData(e);
        setErr(false);
        setSignUpMsg('Account created! Sign in with your new username and password.');
    }
    function handleClickOnLink(ev: React.MouseEvent<unknown>) {
        ev.preventDefault();
        showSignUp(true);
        setChildData(false);
    }

    if (signUp && childData === false) {
        return <SignUp signedUp={updateSignedUp} />;
    } else {
        return (
            <Modal isOpen={true}>
                <div className={styles.loginDiv}>
                    <Text className={styles.headerTitleLogin} title="Student Feedback Portal">
                        SFP
                    </Text>
                    <br></br>
                    <h2 style={{ fontWeight: 400 }}>Sign into your account</h2>
                    <div>{signedUpMsg}</div>
                    {loginErr ? msg : <div></div>}
                    <form onSubmit={(e) => handleSubmit(e)}>
                        <div className={styles.loginInnerDiv}>
                            <TextField
                                style={{ width: 400 }}
                                borderless
                                underlined
                                required
                                value={username}
                                placeholder="Username"
                                onChange={(_e, text) => setUsername(text.trim())}
                            />
                            <Text>
                                {' '}
                                <br></br>
                            </Text>
                            <TextField
                                underlined
                                required
                                borderless
                                placeholder="Password"
                                type="password"
                                canRevealPassword
                                onChange={(_e, text) => setPassword(text)}
                            />
                            <br></br>
                        </div>
                        <PrimaryButton
                            styles={{
                                flexContainer: {
                                    flexDirection: 'row-reverse'
                                }
                            }}
                            type="submit"
                            style={{
                                float: 'left',
                                marginLeft: 50
                            }}
                            iconProps={sendIcon}
                            text={'SIGN IN'}
                        />
                    </form>
                    <div style={{ float: 'left', alignSelf: 'flex-start', marginLeft: 50 }}>
                        <Text>
                            <br></br>Don't have an account?{' '}
                        </Text>
                        <Link onClick={(e) => handleClickOnLink(e)}>Sign up!</Link>
                    </div>
                </div>
            </Modal>
        );
    }
};

export default Login;
