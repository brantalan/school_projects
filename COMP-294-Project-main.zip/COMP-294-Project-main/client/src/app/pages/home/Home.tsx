import React from 'react';

const Home: React.FC = () => {
    return <h2>Home</h2>;
};

export default Home;
