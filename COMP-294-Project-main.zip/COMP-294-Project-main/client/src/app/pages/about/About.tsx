import React from 'react';

const About: React.FC = () => {
    return <h2>About</h2>;
};

export default About;
