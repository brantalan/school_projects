import React from 'react';
import { PrimaryButton } from '@fluentui/react';
import { Reply } from './ReplyBox';
import Replies from './Replies';
import { ApiClient, SubmissionDto, SubscriptionDto } from 'app/generated/backend';
import SFPCookies from 'app/components/SFPCookies';
import SFPAuth from 'app/components/SFPAuth';
import { getDateString } from 'app/utils/utilities';

interface StyleSheet {
    [key: string]: React.CSSProperties;
}
interface IState {
    example: {
        title: string;
        userId: number;
        message: string;
        priorityLevel: any;
        reference: string;
        createdDate: string;
        updatedDate: string;
    };
    repliesLoaded: boolean;
    submissionUserId: number;
    submissionId: number;
    loaded: boolean;
    updated: boolean;
    seeDetails: boolean;
    dto: SubmissionDto;
    priorityStr: string;
    userId: number;
    updateReplies: boolean;
    numReplies: number;
    subscribed: boolean;
}
const styles: StyleSheet = {
    editButton: {
        float: 'right',
        fontSize: 12,
        font: 'Segoe UI',
        fontWeight: 400,
        backgroundColor: '#b8b8b7',
        color: 'white',
        height: 20,
        padding: 10,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        border: 'none'
    },
    detailsButton: {
        backgroundColor: '#00cc99',
        border: 'none',
        height: 30,
        padding: 0,
        width: 110
    }
};
export const HR = <hr style={{ border: '0', borderTop: '1px solid #eee' }}></hr>;
class SubmissionView extends React.Component<{}, IState> {
    constructor(props: any) {
        super(props);
        this.updateReplies = this.updateReplies.bind(this);
        this.reRender = this.reRender.bind(this);
        this.setNumReplies = this.setNumReplies.bind(this);
        this.state = {
            priorityStr: '',
            example: null,
            loaded: false,
            updated: true,
            seeDetails: true,
            dto: null,
            submissionId: 0,
            submissionUserId: 0,
            repliesLoaded: false,
            userId: SFPCookies.get('userId'),
            updateReplies: false,
            numReplies: 0,
            subscribed: false
        };
    }

    /**
     * Redirects to submission edit page.
     */
    handleEdit() {
        window.location.href = '/submissions/edit/' + this.state.submissionId;
    }

    /**
     * Creates new subscription via api call.
     */
    async subscribeUser() {
        let dto = new SubscriptionDto();
        dto.init({
            submissionId: this.state.submissionId,
            userId: this.state.userId
        });
        try {
            await new ApiClient(process.env.REACT_APP_API_BASE).subscription_CreateSubscription(dto);
        } catch (e) {
            console.log(e);
        }
    }

    /**
     * Deletes subscription via api call.
     */
    async unsubscribeUser() {
        let dto = new SubscriptionDto();
        dto.init({
            submissionId: this.state.submissionId,
            userId: this.state.userId
        });
        try {
            await new ApiClient(process.env.REACT_APP_API_BASE).subscription_DeleteSubscription(
                this.state.submissionId,
                this.state.userId
            );
        } catch (e) {
            console.log(e);
        }
    }

    /**
     * Sets state of subscribed and calls relevant API whether unsub or sub.
     */
    handleSubscribe() {
        if (this.state.subscribed) {
            this.unsubscribeUser();
            this.setState({
                subscribed: false
            });
        } else {
            this.subscribeUser();
            this.setState({
                subscribed: true
            });
        }
    }

    /**
     * Renders submission, replies, and reply box. Replies and reply box are there own components.
     * Includes a bunch of if statements to determine which buttons to display.
     * @returns
     */
    renderSubmission() {
        return (
            <div>
                <div>
                    <h2>{this.state.example.title}</h2>
                    <div>
                        {this.state.numReplies === 0 && this.state.userId === this.state.submissionUserId ? (
                            <div>
                                <PrimaryButton style={styles.editButton} onClick={(e) => this.handleEdit()}>
                                    EDIT
                                </PrimaryButton>
                            </div>
                        ) : (
                            <div></div>
                        )}
                        <div>
                            {SFPAuth.isAdmin() ? (
                                !this.state.subscribed ? (
                                    <PrimaryButton style={styles.editButton} onClick={(e) => this.handleSubscribe()}>
                                        SUBSCRIBE
                                    </PrimaryButton>
                                ) : (
                                    <PrimaryButton style={styles.editButton} onClick={(e) => this.handleSubscribe()}>
                                        UNSUBSCRIBE
                                    </PrimaryButton>
                                )
                            ) : (
                                <div />
                            )}
                        </div>
                    </div>
                    <div>
                        {/* {this.state.updated ? <span style={{ fontSize: 10 }}>Updated:</span> : <span></span>} */}
                        <span style={{ fontSize: 10 }}>
                            {this.state.updated ? (
                                <span title={'Date posted: ' + this.state.example.createdDate.toString()}>
                                    {'Updated: ' + this.state.example.updatedDate.toString()}
                                </span>
                            ) : (
                                <span>{this.state.example.createdDate.toString()}</span>
                            )}{' '}
                            &bull; <span style={{ fontWeight: 'bold' }}>{this.state.example.priorityLevel}</span> &bull;{' '}
                            {this.state.example.reference}
                        </span>
                    </div>
                    <br></br>
                    {this.state.seeDetails ? (
                        <PrimaryButton onClick={() => this.showHideDetails()} style={styles.detailsButton}>
                            HIDE DETAILS
                        </PrimaryButton>
                    ) : (
                        <PrimaryButton style={styles.detailsButton} onClick={() => this.showHideDetails()}>
                            SEE DETAILS
                        </PrimaryButton>
                    )}
                </div>
                {this.state.seeDetails ? <p>{this.state.example.message}</p> : <p></p>}
                {HR}
                <div>
                    <Replies
                        submissionId={this.state.submissionId}
                        updateReplies={this.state.updateReplies}
                        reRender={this.updateReplies}
                        setNumReplies={this.setNumReplies}></Replies>
                </div>
                {HR}
                {this.state.numReplies > 0 ? <h3>Add to the Conversation</h3> : <h3>Begin the Conversation</h3>}
                <div>
                    <Reply
                        updateReplies={this.reRender}
                        submissionId={this.state.submissionId}
                        userId={this.state.userId}></Reply>
                </div>
            </div>
        );
    }

    /**
     * This function is passed to the Replies component. Whenever the function is called
     * from within that component via a new reply being submitted,
     *  it calls this function which triggers a re-render to update the replies list with
     * the new reply.
     * @param loaded
     */
    updateReplies(loaded: boolean) {
        this.setState({
            repliesLoaded: loaded,
            updateReplies: loaded
        });
    }

    /**
     * This function is passed to the Reply component. Whenever a user submits a reply
     * this function is called. It sets updateReplies to true, which gets sent to the
     * Replies object which triggers a replies re-render to show the new reply.
     * @param update
     */
    reRender() {
        this.setState({
            updateReplies: true
        });
    }

    /**
     * Sets number of replies.
     * @param num
     */
    setNumReplies(num: number) {
        this.setState({
            numReplies: num
        });
    }

    /**
     * Shows or hides the details of the submission.
     */
    showHideDetails() {
        this.setState({
            seeDetails: !this.state.seeDetails
        });
    }

    /**
     * API call to get the submission.
     * @param id
     */
    async loadSubmissionDto(id: number) {
        let result = null;
        try {
            if (SFPAuth.isAdmin()) {
                result = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetSubmission(id, undefined);
            } else {
                try {
                    result = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetSubmission(id, this.state.userId);
                } catch (e) {
                    // student tried accessing another student's submission
                    window.location.href = '/submissions';
                }
            }

            this.setState({
                example: {
                    userId: result.userId,
                    reference: result.reference,
                    createdDate: getDateString(result.createdDate.toString()), //TODO: Format date
                    updatedDate: getDateString(result.updatedDate.toString()), //TODO: Format date
                    title: result.title,
                    message: result.message,
                    priorityLevel: <span style={this.determinePriorityStyle(result.priorityLevel)}>{this.state.priorityStr}</span>
                },
                // oddly, result.updatedDate === result.createdDate returns false even when they are the same in the database
                updated: getDateString(result.updatedDate.toString()) !== getDateString(result.createdDate.toString()),
                loaded: true,
                submissionUserId: result.userId
            });
        } catch (e) {
            console.log('api call error');
            window.location.href = '/submissions';
        }
        //If the API call errors, that means a subscription is not found.
        try {
            result = await new ApiClient(process.env.REACT_APP_API_BASE).subscription_GetSubscription(id, this.state.userId);
            this.setState({
                subscribed: true
            });
        } catch (e) {
            this.setState({
                subscribed: false
            });
        }
    }

    /**
     * Returns a style object with font color
     * based on the submission priority. Also sets the
     * priority string for the submission view.
     * @param number
     * @returns
     */
    determinePriorityStyle(number: any) {
        let style = {
            color: ''
        };
        if (number === 0) {
            this.setState({
                priorityStr: 'LOW '
            });
            style = {
                color: '#9e9e9e'
            };
        } else if (number === 1) {
            this.setState({
                priorityStr: 'NORMAL '
            });
            style = {
                color: '#4caf50'
            };
        } else {
            this.setState({
                priorityStr: 'HIGH '
            });
            style = {
                color: '#f44336'
            };
        }
        return style;
    }

    /**
     * Called when page is loaded. Calls loadSubmissionDto which gets the
     * ball rolling.
     */
    componentDidMount() {
        let path = window.location.pathname.split('/');
        let id = parseInt(path[path.length - 1]);
        this.setState({
            submissionId: id
        });
        if (!this.state.loaded) {
            this.loadSubmissionDto(id);
        }
    }

    render() {
        if (this.state.loaded) {
            return <div>{this.renderSubmission()}</div>;
        } else {
            return <div>Loading Submission</div>;
        }
    }
}

export default SubmissionView;
