import sfpAuth from '../../components/SFPAuth';
import { Redirect } from 'react-router-dom';
import { ApiClient, ISubmissionDto } from 'app/generated/backend';
import {
    Dropdown,
    IDropdownOption,
    IDropdownStyles,
    CheckboxVisibility,
    DetailsList,
    DetailsListLayoutMode,
    hiddenContentStyle,
    IColumn,
    Selection,
    Spinner,
    SpinnerSize,
    initializeComponentRef
} from '@fluentui/react';
import sfpCookies from '../../components/SFPCookies';
import React, { useEffect, useState } from 'react';
import { IContextualMenuProps, IIconProps, Stack, IStackStyles } from '@fluentui/react';
import { TextField, ITextFieldStyles } from '@fluentui/react/lib/TextField';
import { MarqueeSelection } from '@fluentui/react/lib/MarqueeSelection';
import { mergeStyles } from '@fluentui/react/lib/Styling';
import { Text } from '@fluentui/react/lib/Text';
import { DefaultButton, PrimaryButton } from '@fluentui/react/lib/Button';

export interface ISubmissionListDto extends ISubmissionDto {
    replies: number | undefined;
    studentName: string | undefined;
}

function Submissions() {
    const addIcon: IIconProps = { iconName: 'Add' };
    const [data, setData] = useState({
        allSubmissions: [] as ISubmissionListDto[],
        filteredSubmissions: [] as ISubmissionListDto[],
        isFetching: false
    });
    const [filters, setfilterSize] = useState({
        columnName: 'ms-Grid-col 3',
        percentage: '33%'
    });
    const initialSubmissionList: ISubmissionListDto[] = [];
    const checkboxVisibility: CheckboxVisibility = 2;
    const dropdownStyles: Partial<IDropdownStyles> = { dropdown: { width: 300 } };
    const dropdownOptions = [
        { key: 0, text: 'Low' },
        { key: 1, text: 'Normal' },
        { key: 2, text: 'High' },
        { key: 3, text: 'All' }
    ];
    const [isAdmin, setAdmin] = useState({
        isAdmin: false
    });
    const [emptySubmissionResult, setSubmissionResult] = useState({
        empty: false
    });

    //controls whether button to add
    var hideAddSubButton = false;

    var columns = [
        { key: 'column0', name: 'Ref #', fieldName: 'reference', minWidth: 40, maxWidth: 60, isResizable: true },
        { key: 'column1', name: 'Title', fieldName: 'title', minWidth: 250, maxWidth: 400, isResizable: true },
        { key: 'column2', name: 'Date Submitted', fieldName: 'createdDate', minWidth: 40, maxWidth: 200, isResizable: true }
    ];

    if (sfpAuth.isAdmin()) {
        columns.push({
            key: 'column3',
            name: 'Student',
            fieldName: 'studentName',
            minWidth: 40,
            maxWidth: 200,
            isResizable: true
        });
        columns.push(
            { key: 'column4', name: 'Priority', fieldName: 'priorityLevel', minWidth: 40, maxWidth: 200, isResizable: true },
            { key: 'column5', name: 'Replies', fieldName: 'replies', minWidth: 40, maxWidth: 200, isResizable: true }
        );
        hideAddSubButton = true;
    } else {
        columns.push(
            { key: 'column3', name: 'Priority', fieldName: 'priorityLevel', minWidth: 40, maxWidth: 200, isResizable: true },
            { key: 'column4', name: 'Replies', fieldName: 'replies', minWidth: 40, maxWidth: 200, isResizable: true }
        );
    }

    const _onFilterByRef = (ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, text: string): void => {
        setData({
            allSubmissions: data.allSubmissions,
            filteredSubmissions: text
                ? data.allSubmissions.filter((i) => i.reference.toLowerCase().indexOf(text) > -1)
                : data.allSubmissions,
            isFetching: false
        });
    };

    const _onFilterByTitle = (ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, text: string): void => {
        setData({
            allSubmissions: data.allSubmissions,
            filteredSubmissions: text
                ? data.allSubmissions.filter((i) => i.title.toLowerCase().indexOf(text) > -1)
                : data.allSubmissions,
            isFetching: false
        });
    };

    const _onFilterByStudent = (ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, text: string): void => {
        setData({
            allSubmissions: data.allSubmissions,
            filteredSubmissions: text
                ? data.allSubmissions.filter((i) => i.studentName.toLowerCase().indexOf(text) > -1)
                : data.allSubmissions,
            isFetching: false
        });
    };

    const _onFilterByPrio = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption) => {
        if (item.key < 3) {
            setData({
                allSubmissions: data.allSubmissions,
                filteredSubmissions: item
                    ? data.allSubmissions.filter((i) => i.priorityLevel.valueOf() == item.key)
                    : data.allSubmissions,
                isFetching: false
            });
        } else {
            setData({ allSubmissions: data.allSubmissions, filteredSubmissions: data.allSubmissions, isFetching: false });
        }
    };

    const _renderItemColumn = (item: ISubmissionListDto, index: number, column: IColumn) => {
        var fieldContent = item[column.fieldName as keyof ISubmissionListDto] as string;
        const link = '/submissions/view/' + item.id.toString();

        switch (column.name) {
            case 'Title':
                return <a href={link}>{fieldContent}</a>;
            case 'Priority': {
                if (fieldContent == '0') {
                    fieldContent = 'Low';
                } else if (fieldContent == '1') {
                    fieldContent = 'Normal';
                } else if (fieldContent == '2') {
                    fieldContent = 'High';
                }
                return <span>{fieldContent}</span>;
            }
            default:
                return <span>{fieldContent}</span>;
        }
    };

    const _addClicked = (): void => {
        window.location.href = 'submissions/create';
    };

    //this entire area is for getting the data we need to build out table
    useEffect(() => {
        //gets an array of submissions all submissions if user is admin or just the ones that belong to the user
        const fetchData = async (): Promise<ISubmissionDto[]> => {
            if (!sfpAuth.isLoggedIn()) {
                window.location.href = '/notifications';
                return;
            }
            if (sfpAuth.isAdmin()) {
                try {
                    setData({
                        allSubmissions: data.allSubmissions,
                        filteredSubmissions: data.filteredSubmissions,
                        isFetching: true
                    });
                    setAdmin({ isAdmin: true });
                    setfilterSize({ columnName: 'ms-Grid-col 4', percentage: '25%' }); //changing the style and class names when admins are logged in to scale the filters options and have it with four columns
                    const result = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetAllSubmissions();
                    return result;
                } catch (e) {
                    console.log(e);
                    setData({
                        allSubmissions: data.allSubmissions,
                        filteredSubmissions: data.filteredSubmissions,
                        isFetching: false
                    });
                }
            } else {
                try {
                    setData({
                        allSubmissions: data.allSubmissions,
                        filteredSubmissions: data.filteredSubmissions,
                        isFetching: true
                    });
                    const result = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetAllSubmissionsByUser(
                        sfpCookies.get('userId')
                    );
                    return result;
                } catch (e) {
                    console.log(e);
                    setData({
                        allSubmissions: data.allSubmissions,
                        filteredSubmissions: data.filteredSubmissions,
                        isFetching: false
                    });
                }
            }
        };
        //gets replies and just returns the length since we just need to know how many
        const fetchRepliesData = async (submissionId: number): Promise<number> => {
            try {
                setData({ allSubmissions: data.allSubmissions, filteredSubmissions: data.filteredSubmissions, isFetching: true });

                const result = await new ApiClient(process.env.REACT_APP_API_BASE).replies_GetAllRepliesForSubmission(
                    submissionId
                );
                return result.length;
            } catch (e) {
                console.log(e);
                setData({
                    allSubmissions: data.allSubmissions,
                    filteredSubmissions: data.filteredSubmissions,
                    isFetching: false
                });
            }
        };
        //gets names of who made each submission, only shown in admin mode
        const fetchNameData = async (userId: number): Promise<string> => {
            try {
                setData({ allSubmissions: data.allSubmissions, filteredSubmissions: data.filteredSubmissions, isFetching: true });

                const result = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetUser(userId);

                return result.firstName + ' ' + result.lastName;
            } catch (e) {
                console.log(e);
                setData({
                    allSubmissions: data.allSubmissions,
                    filteredSubmissions: data.filteredSubmissions,
                    isFetching: false
                });
            }
        };

        //runs through the async stack and builds out the initialSubmissionList
        fetchData().then((result) => {
            if (result !== undefined && result.length > 0) {
                result.forEach((submission) => {
                    fetchRepliesData(submission.id).then((numReplies) => {
                        fetchNameData(submission.userId).then((name) => {
                            var newSubmission: ISubmissionListDto = {
                                id: submission.id,
                                userId: submission.userId,
                                reference: submission.reference,
                                title: submission.title,
                                message: submission.message,
                                createdDate: submission.createdDate,
                                updatedDate: submission.updatedDate,
                                priorityLevel: submission.priorityLevel,
                                studentName: name,
                                replies: numReplies
                            };
                            initialSubmissionList.push(newSubmission);
                            setData({
                                allSubmissions: initialSubmissionList,
                                filteredSubmissions: initialSubmissionList,
                                isFetching: false
                            });
                        });
                    });
                });
                setSubmissionResult({ empty: false });
                console.log(emptySubmissionResult.empty);
            } else {
                setData({
                    allSubmissions: data.allSubmissions,
                    filteredSubmissions: data.filteredSubmissions,
                    isFetching: false
                });
                setSubmissionResult({ empty: true });
            }
        });
        //eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div>
            <h1>Submissions</h1>

            <div hidden={hideAddSubButton}>
                <PrimaryButton
                    styles={{
                        flexContainer: {
                            flexDirection: 'row-reverse'
                        }
                    }}
                    type="submit"
                    style={{
                        float: 'right'
                    }}
                    iconProps={addIcon}
                    text={'New Submission'}
                    onClick={_addClicked}
                />
                <br />
                <br />
                <br />
            </div>

            <div
                hidden={emptySubmissionResult.empty}
                className="ms-Grid-row"
                style={{
                    width: '100%'
                }}>
                <div className={filters.columnName} style={{ width: filters.percentage }}>
                    <TextField label="Filter by Ref #:" onChange={_onFilterByRef} />
                </div>
                <div className={filters.columnName} style={{ width: filters.percentage }}>
                    <TextField label="Filter by Title:" onChange={_onFilterByTitle} />
                </div>
                <div hidden={!isAdmin.isAdmin} className={filters.columnName} style={{ width: filters.percentage }}>
                    <TextField label="Filter by Student:" onChange={_onFilterByStudent} />
                </div>
                <div
                    className={filters.columnName}
                    style={{
                        width: filters.percentage
                    }}>
                    <Dropdown
                        label="Filter by Priority"
                        onChange={_onFilterByPrio}
                        options={dropdownOptions}
                        styles={dropdownStyles}
                    />
                </div>
            </div>
            <div hidden={!emptySubmissionResult.empty}>
                <h3>No Submissions Found </h3>
            </div>
            <div hidden={emptySubmissionResult.empty} className="ms-Grid-row">
                <DetailsList
                    className="submissionsList"
                    items={data.filteredSubmissions.map((submission) => {
                        return {
                            ...submission,
                            createdDate: submission.createdDate.toLocaleString(),
                            updatedDate: submission.updatedDate.toLocaleString()
                        };
                    })}
                    checkboxVisibility={checkboxVisibility}
                    columns={columns}
                    onRenderItemColumn={_renderItemColumn}
                    layoutMode={DetailsListLayoutMode.justified}
                />
                {data.isFetching && <Spinner size={SpinnerSize.large} />}
            </div>
        </div>
    );
}

export default Submissions;
