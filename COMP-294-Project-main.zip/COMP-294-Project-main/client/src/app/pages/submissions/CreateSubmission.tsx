import React, { useState } from 'react';
import {
    IIconProps,
    Text,
    TextField,
    Modal,
    PrimaryButton,
    Link,
    Dropdown,
    IDropdownOption,
    IDropdownStyles
} from '@fluentui/react';
import sfpAuth from 'app/components/SFPAuth';
import sfpCookies from 'app/components/SFPCookies';
import Login from 'app/Login';
import Submissions from 'app/pages/submissions/Submissions';
//import styles from './App.module.scss';
import { ApiClient, SubmissionDto, SubscriptionDto, NotificationType } from 'app/generated/backend';
import globalStyles from 'app/App.module.scss';
import SFPNotifications from 'app/components/SFPNotifications';
interface Props {
    submissionCreated: any;
}

const CreateSubmission: React.FC<Props> = (props) => {
    const [title, setTitle] = useState('');
    const [message, setMessage] = useState('');
    const [path] = useState('/submissions/view/');
    const [priority, setPriority] = useState(1);
    const [submissionErr, setErr] = useState(false);
    const [errMsg, setErrMsg] = useState('');

    const handleSubmit = async (e: any) => {
        e.preventDefault();
        const api = new ApiClient(process.env.REACT_APP_API_BASE);
        if (title !== '' && message !== '') {
            try {
                let dto = new SubmissionDto();
                dto.init({
                    userId: sfpCookies.get('userId'),
                    title: title,
                    message: message,
                    priorityLevel: priority
                });

                let result = await api.submissions_CreateSubmission(dto);
                let subDto = new SubscriptionDto();
                subDto.init({
                    submissionId: result.id,
                    userId: sfpCookies.get('userId')
                });
                const subscriptionCreated = await api.subscription_CreateSubscription(subDto);
                if (subscriptionCreated) {
                    //Redirecting to Submissions until Submission View is complete
                    await SFPNotifications.notify(NotificationType.Submission, result.id, Number(sfpCookies.get('userId')));
                    window.location.href = path + result.id;
                }
            } catch (e) {
                setErr(true);
                setErrMsg('There was an error with your request');
            }
        }
    };

    const sendIcon: IIconProps = { iconName: 'Send' };

    const msg = <Text style={{ color: '#FF0000' }}>{errMsg}</Text>;

    const dropdownStyles: Partial<IDropdownStyles> = {
        dropdown: { width: 450 }
    };

    const options: IDropdownOption[] = [
        { key: '0', text: 'Low' },
        { key: '1', text: 'Normal' },
        { key: '2', text: 'High' }
    ];
    if (sfpAuth.isAdmin()) {
        window.location.href = '/submissions';
        return <></>;
    } else {
        return (
            <div style={{ width: 800 }}>
                <div>
                    <h2>Create Submission</h2>
                    {submissionErr ? msg : <div></div>}
                </div>
                <form onSubmit={(e) => handleSubmit(e)} style={{ height: 250, marginBottom: 0 }}>
                    <div>
                        <div>
                            <TextField
                                label="Title"
                                // borderless
                                // underlined
                                required
                                onChange={(_e, text) => setTitle(text)}
                            />
                        </div>
                        <br></br>
                        <div>
                            <Dropdown
                                required
                                label="Priority Level"
                                placeHolder="Normal"
                                options={options}
                                styles={dropdownStyles}
                                onChanged={(selectedOption) => setPriority(Number(selectedOption.key))}
                            />
                        </div>
                    </div>
                    <br></br>
                    <div>
                        <div>
                            <TextField
                                required
                                label="Share your thoughts..."
                                multiline
                                autoAdjustHeight
                                placeholder="Type here"
                                onChange={(_e, text) => setMessage(text)}
                            />
                        </div>
                    </div>
                    <br></br>
                    <div>
                        <PrimaryButton
                            styles={{
                                flexContainer: {
                                    flexDirection: 'row-reverse'
                                }
                            }}
                            type="submit"
                            style={{
                                float: 'left'
                            }}
                            iconProps={sendIcon}
                            text={'SUBMIT'}
                        />
                    </div>
                    <div>
                        <Link href="/submissions" className={globalStyles.cancelLink}>
                            Cancel
                        </Link>
                    </div>
                    <br></br>
                    <br></br>
                </form>
            </div>
        );
    }
};

export default CreateSubmission;
