import React, { useEffect, useState } from 'react';
import { IIconProps, Text, TextField, PrimaryButton, Link, Dropdown, IDropdownOption, IDropdownStyles } from '@fluentui/react';
import sfpCookies from 'app/components/SFPCookies';
import { ApiClient, SubmissionDto } from 'app/generated/backend';
import SFPCookies from 'app/components/SFPCookies';
import globalStyles from 'app/App.module.scss';

interface StyleSheet {
    [key: string]: React.CSSProperties;
}

const styles: StyleSheet = {
    viewButton: {
        float: 'right',
        fontSize: 12,
        font: 'Segoe UI',
        fontWeight: 400,
        backgroundColor: '#00cc99',
        color: 'white',
        height: 20,
        padding: 10,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        border: 'none'
    }
};

const EditSubmission: React.FC = () => {
    const [loaded, setLoaded] = useState(false);
    const [subId, setSubId] = useState(0);
    const [userId] = useState(SFPCookies.get('userId'));
    const [title, setTitle] = useState('');
    const [reference, setReference] = useState('');
    const [message, setMessage] = useState('');
    const [priority, setPriority] = useState(1);
    const [placeHolder, setPlaceHolder] = useState('');
    const [submissionErr, setErr] = useState(false);
    const [errMsg, setErrMsg] = useState('');
    const [path] = useState('/submissions/view/');
    const api = new ApiClient(process.env.REACT_APP_API_BASE);
    let result = new SubmissionDto();

    function getSubmissionId() {
        let path = window.location.pathname.split('/');
        let id = parseInt(path[path.length - 1]);
        if (id !== undefined && id !== null && !isNaN(id)) {
            setSubId(id);
            return id;
        } else {
            window.location.href = '/submissions';
        }
    }

    async function loadSubmission() {
        try {
            result = await api.submissions_GetSubmission(getSubmissionId(), sfpCookies.get('userId'));
            let replies = await api.replies_GetAllRepliesForSubmission(result.id);
            if (replies.length > 0) {
                window.location.href = '/submissions/view/' + result.id;
            } else {
                setReference(result.reference);
                setSubId(result.id);
                setTitle(result.title);
                setMessage(result.message);
                setPriority(result.priorityLevel);
                if (result.priorityLevel === 0) setPlaceHolder('Low');
                if (result.priorityLevel === 1) setPlaceHolder('Normal');
                if (result.priorityLevel === 2) setPlaceHolder('High');
                setLoaded(true);
            }
        } catch {
            if (subId > 0) {
                window.location.href = '/submissions/view/' + subId;
            } else {
                window.location.href = '/submissions';
            }
        }
    }

    useEffect(() => {
        if (!loaded) {
            loadSubmission();
        }
    });

    window.onchange = function () {
        updateDropdown();
    };
    function updateDropdown() {
        if (priority === 0) setPlaceHolder('Low');
        if (priority === 1) setPlaceHolder('Normal');
        if (priority === 2) setPlaceHolder('High');
    }
    const sendIcon: IIconProps = { iconName: 'Send' };

    const msg = <Text style={{ color: '#FF0000' }}>{errMsg}</Text>;

    const dropdownStyles: Partial<IDropdownStyles> = {
        dropdown: { width: 450 }
    };

    const options: IDropdownOption[] = [
        { key: '0', text: 'Low' },
        { key: '1', text: 'Normal' },
        { key: '2', text: 'High' }
    ];

    const handleSubmit = async (e: any) => {
        e.preventDefault();
        const api = new ApiClient(process.env.REACT_APP_API_BASE);
        if (title !== '' && message !== '') {
            try {
                result = await api.submissions_GetSubmission(getSubmissionId(), sfpCookies.get('userId'));
                result.message = message;
                result.title = title;
                result.priorityLevel = priority;
                await api.submissions_UpdateSubmission(result);
                window.location.href = path + result.id;
            } catch (e) {
                setErr(true);
                setErrMsg('There was an error with your request');
            }
        }
    };

    if (loaded) {
        return (
            <div style={{ width: 800 }}>
                <div>
                    <h2>Edit Submission</h2>
                    <div>
                        <PrimaryButton
                            style={styles.viewButton}
                            onClick={(e) => (window.location.href = '/submissions/view/' + subId)}>
                            VIEW
                        </PrimaryButton>
                    </div>
                    <p>Reference: {reference}</p>
                    {submissionErr ? msg : <div></div>}
                </div>
                <form onSubmit={(e) => handleSubmit(e)} style={{ height: 250, marginBottom: 0 }}>
                    <div>
                        <div>
                            <TextField
                                // borderless
                                // underlined
                                required
                                label="Title"
                                value={title}
                                onChange={(_e, title) => setTitle(title)}
                            />
                        </div>
                        <br></br>
                        <div>
                            <Dropdown
                                required
                                label="Priority Level"
                                placeholder={placeHolder}
                                options={options}
                                styles={dropdownStyles}
                                onChanged={(selectedOption) => setPriority(Number(selectedOption.key))}
                            />
                        </div>
                    </div>
                    <br></br>
                    <div>
                        <div>
                            <TextField
                                required
                                label="Share your thoughts..."
                                multiline
                                autoAdjustHeight
                                value={message}
                                placeholder="Type here"
                                onChange={(_e, message) => setMessage(message)}
                            />
                        </div>
                    </div>
                    <br></br>
                    <div>
                        <PrimaryButton
                            styles={{
                                flexContainer: {
                                    flexDirection: 'row-reverse'
                                }
                            }}
                            type="submit"
                            style={{
                                float: 'left'
                            }}
                            iconProps={sendIcon}
                            text={'EDIT'}
                        />
                    </div>
                    <div>
                        <Link href={path + subId} className={globalStyles.cancelLink}>
                            Cancel
                        </Link>
                    </div>
                    <br></br>
                    <br></br>
                </form>
            </div>
        );
    } else {
        return <div></div>;
    }
};

export default EditSubmission;
