import React, { useState, useEffect } from 'react';
import { ApiClient } from 'app/generated/backend';
import SFPCookies from 'app/components/SFPCookies';
import { PrimaryButton } from '@fluentui/react';
import { getDateString } from 'app/utils/utilities';
interface Props {
    submissionId: any;
    updateReplies: any;
    reRender: any;
    setNumReplies: any;
}
interface StyleSheet {
    [key: string]: React.CSSProperties;
}

const Replies: React.FC<Props> = (props) => {
    const [loaded, setLoaded] = useState(false);
    const [replyArr, setReplyArr] = useState([]);
    const [userMap, setMap] = useState(new Map());
    const [numReplies, setReplies] = useState(0);
    const users = new Map();

    /**
     * Calls api to get all replies for given submission. Also calls user API to get user first and last names then
     * creates a map to map the names to each reply.
     * @returns
     */
    async function loadReplies() {
        if (!loaded) {
            let result = await new ApiClient(process.env.REACT_APP_API_BASE).replies_GetAllRepliesForSubmission(
                props.submissionId
            );
            let length = result.length;
            setReplies(length);
            let arr = [];
            for (let i = 0; i < length; i++) {
                try {
                    let userResult = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetUser(result[i].userId);
                    users.set(result[i].userId, userResult.firstName + ' ' + userResult.lastName);
                } catch (e) {
                    console.log('user not found');
                }
                arr.push(result[i]);
            }
            setReplyArr(arr);
            setMap(users);
            return length;
        }
    }
    /**
     * Loads replies if they aren't loaded yet. Calls reRender new replies are found.
     */
    useEffect(() => {
        function checkReplies() {
            if (!loaded) {
                loadReplies().then((num) => props.setNumReplies(num));
                setLoaded(true);
            }
            if (props.updateReplies) {
                setLoaded(false);
                props.reRender(false);
            }
        }
        checkReplies();
    });

    /**
     * Redirects to the replies edit page.
     * @param id
     */
    function handleEdit(id: any) {
        window.location.href = '/replies/edit/' + id;
    }

    if (loaded) {
        return (
            <div>
                <h3>Replies ({numReplies})</h3>
                {numReplies > 0 ? (
                    <div>
                        <div style={{ paddingLeft: 10 }}>
                            {replyArr.map((reply) => (
                                <div key={reply.id}>
                                    <div>
                                        <div>
                                            <h4>
                                                {userMap.get(reply.userId)}
                                                {'  '}
                                                <span style={{ color: '#ccc', fontSize: 12, fontWeight: 'normal' }}>
                                                    {getDateString(reply.createdDate.toString())}
                                                </span>
                                                {reply.updatedDate.toString() !== reply.createdDate.toString() ? (
                                                    <span
                                                        style={{ color: 'blue', fontWeight: 'normal', fontSize: 12 }}
                                                        title={getDateString(reply.updatedDate.toString())}>
                                                        {' '}
                                                        (edited)
                                                    </span>
                                                ) : (
                                                    <div />
                                                )}
                                                {reply.userId === SFPCookies.get('userId') ? (
                                                    <PrimaryButton
                                                        style={styles.editButton}
                                                        onClick={(e) => handleEdit(reply.id)}>
                                                        EDIT
                                                    </PrimaryButton>
                                                ) : (
                                                    <div></div>
                                                )}
                                            </h4>
                                        </div>
                                    </div>
                                    <p>{reply.message}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <h4>This submission has no replies.</h4>
                )}
            </div>
        );
    } else {
        return <div>Loading Replies</div>;
    }
};
const styles: StyleSheet = {
    editButton: {
        float: 'right',
        fontSize: 12,
        font: 'Segoe UI',
        fontWeight: 400,
        backgroundColor: '#b8b8b7',
        color: 'white',
        height: 20,
        padding: 10,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        border: 'none',
        boxShadow: '10 10'
    }
};

export default Replies;
