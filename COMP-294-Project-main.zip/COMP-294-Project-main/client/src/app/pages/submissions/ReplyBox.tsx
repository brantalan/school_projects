import React, { useEffect, useState } from 'react';
import { IIconProps, TextField, PrimaryButton } from '@fluentui/react';
import { ApiClient, ReplyDto, NotificationType } from 'app/generated/backend';
import SFPNotifications from 'app/components/SFPNotifications';
import SFPCookies from 'app/components/SFPCookies';

interface Props {
    submissionId: any;
    userId: any;
    updateReplies: any;
}
export const Reply: React.FC<Props> = (props) => {
    const replyIcon: IIconProps = { iconName: 'Reply' };
    const [value, setValue] = useState('');
    const [err, setErr] = useState('');

    /**
     * Validates reply submission, creates reply dto, and calls submitReply.
     */
    function submit() {
        if (value.trim() === '') {
            setErr('Your reply cannot be blank.');
        } else {
            let dto = new ReplyDto();
            let date = new Date();
            dto.init({
                submissionId: props.submissionId,
                userId: props.userId,
                message: value,
                createdDate: date,
                updatedDate: date
            });
            submitReply(dto);
        }
    }

    /**
     * Sends ReplyDto to the API. Calls updateReplies() prop function to trigger parent rerender.
     * @param dto
     */
    async function submitReply(dto: ReplyDto) {
        try {
            let result = await new ApiClient(process.env.REACT_APP_API_BASE).replies_CreateReply(dto);
            props.updateReplies();
            await SFPNotifications.notify(NotificationType.Reply, result.id, SFPCookies.get('userId'));
            setValue('');
        } catch (e) {
            console.log(e);
            console.log('API REPLY ERR');
        }
    }

    /**
     * Clears error on re-render.
     */
    useEffect(() => {
        function clearErr() {
            if (err !== '' && value.trim() !== '') {
                setErr('');
            }
        }
        clearErr();
    });

    return (
        <div>
            <span style={{ fontSize: 10, color: 'red' }}>{err}</span>
            <TextField multiline rows={7} value={value} onChange={(e, value) => setValue(value)} />
            <div style={{ paddingTop: 10 }}>
                <PrimaryButton
                    styles={{
                        flexContainer: {
                            flexDirection: 'row-reverse'
                        }
                    }}
                    iconProps={replyIcon}
                    onClick={(e) => submit()}>
                    SUBMIT REPLY
                </PrimaryButton>
            </div>
        </div>
    );
};
