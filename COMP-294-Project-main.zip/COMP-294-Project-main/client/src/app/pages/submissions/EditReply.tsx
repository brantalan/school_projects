import SFPCookies from 'app/components/SFPCookies';
import React, { useState, useEffect } from 'react';
import { ApiClient, ReplyDto } from 'app/generated/backend';
import { HR } from 'app/pages/submissions/SubmissionView';
import { IIconProps, TextField, PrimaryButton } from '@fluentui/react';

const EditReply: React.FC = () => {
    const [loaded, setLoaded] = useState(false);
    const [msg, setMsg] = useState('');
    const [refId, setRefId] = useState('');
    const userId = SFPCookies.get('userId');
    const replyId = getReplyId();
    const [subId, setSubId] = useState(null);
    const [hrefStr, setHrefStr] = useState('');
    const [err, setErr] = useState('');
    const sendIcon: IIconProps = { iconName: 'Send' };

    function getReplyId() {
        let path = window.location.pathname.split('/');
        let id = parseInt(path[path.length - 1]);
        if (id !== undefined && id !== null && !isNaN(id)) {
            return id;
        } else {
            window.location.href = '/submissions';
        }
    }
    async function loadReply() {
        let result = await new ApiClient(process.env.REACT_APP_API_BASE).replies_GetReply(replyId);
        let submissionResult = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetSubmission(
            result.submissionId,
            undefined
        );
        if (result.userId !== userId) {
            window.location.href = '/submissions/view/' + result.submissionId;
        } else {
            setMsg(result.message);
            setRefId(submissionResult.reference);
            setSubId(submissionResult.id);
            setLoaded(true);
            setHrefStr('/submissions/view/' + submissionResult.id);
        }
    }
    useEffect(() => {
        if (!loaded) {
            loadReply();
        }
    });

    async function submitReply() {
        let dto = new ReplyDto();
        dto.init({
            id: replyId,
            submissionId: subId,
            userId: userId,
            message: msg
        });
        try {
            await new ApiClient(process.env.REACT_APP_API_BASE).replies_UpdateReply(dto);
        } catch (e) {
            console.log(e);
        }
    }

    function submit() {
        if (msg.trim() === '') {
            setErr('Your reply cannot be blank.');
        } else {
            submitReply();
            window.location.href = hrefStr;
        }
    }

    if (loaded) {
        return (
            <div>
                <h1>Edit Reply</h1>
                <span style={{ fontSize: 14 }}>
                    Associated Submission:{' '}
                    <a style={{ textDecoration: 'none' }} href={hrefStr}>
                        {refId}
                    </a>
                </span>
                <br />
                <br />
                {HR}
                <span style={{ color: 'red' }}>* </span>
                <span style={{ fontSize: 14, color: '#c4c4c4' }}>Your Message</span>
                <br />
                <span style={{ color: 'red', fontSize: 12 }}>{err}</span>
                <div style={{ paddingTop: 10 }}>
                    <TextField multiline rows={10} value={msg} onChange={(e, value) => setMsg(value)}></TextField>
                </div>
                <div style={{ paddingTop: 10 }}>
                    <PrimaryButton
                        styles={{
                            flexContainer: {
                                flexDirection: 'row-reverse'
                            }
                        }}
                        iconProps={sendIcon}
                        onClick={(e) => submit()}>
                        UPDATE REPLY
                    </PrimaryButton>
                </div>
            </div>
        );
    } else {
        return <div>Loading Reply</div>;
    }
};
export default EditReply;
