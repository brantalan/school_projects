import React, { useState, useEffect } from 'react';
import { ApiClient, NotificationDto, NotificationType } from 'app/generated/backend';
import SFPCookies from 'app/components/SFPCookies';
import { PrimaryButton } from '@fluentui/react';
import { getDateString } from 'app/utils/utilities';
import styles from './Notifications.module.scss';
interface StyleSheet {
    [key: string]: React.CSSProperties;
}
interface Iprops {
    notificationCheck: any;
}
const Notifications: React.FC<Iprops> = (props) => {
    const [loaded, setLoaded] = useState(false);
    const [unreadArr, setUnreadArr] = useState([]);
    const [readArr, setReadArr] = useState([]);
    const [userMap, setUserMap] = useState(new Map());
    const [titleMap, setTitleMap] = useState(new Map());
    const [numUnread, setUnread] = useState(0);
    const [numRead, setRead] = useState(0);
    const users = new Map();
    const titles = new Map();

    /**
     * Calls api to get all unread notifications for the user. Using said notifications it maps the users name and the title of a submission if appropriate.
     * @returns
     */
    async function loadUnread() {
        if (!loaded) {
            let yourId = SFPCookies.get('userId');
            let result = await new ApiClient(process.env.REACT_APP_API_BASE).notification_GetAllNotifications(yourId, true);
            let length = result.length;
            setUnread(length);
            let arr = [];
            for (let i = 0; i < length; i++) {
                try {
                    let userResult = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetUser(result[i].triggerId);
                    users.set(result[i].triggerId, userResult.firstName + ' ' + userResult.lastName);
                } catch (e) {
                    console.log('user not found');
                }
                try {
                    let subResult = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetSubmission(
                        result[i].submissionId,
                        0
                    );
                    titles.set(result[i].submissionId, subResult.title);
                } catch (e) {
                    console.log('submission not found');
                }
                arr.push(result[i]);
            }
            setUnreadArr(arr);
            setUserMap(users);
            setTitleMap(titles);
            return length;
        }
    }

    /**
     * Calls api to get all read notifications for the user. Using said notifications it maps the users name and the title of a submission if appropriate.
     * @returns
     */
    async function loadRead() {
        if (!loaded) {
            let yourId = SFPCookies.get('userId');
            let result = await new ApiClient(process.env.REACT_APP_API_BASE).notification_GetAllNotifications(yourId, false);
            let length = result.length;
            setRead(length);
            let arr = [];
            for (let i = 0; i < length; i++) {
                try {
                    let userResult = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetUser(result[i].triggerId);
                    users.set(result[i].triggerId, userResult.firstName + ' ' + userResult.lastName);
                } catch (e) {
                    console.log('user not found');
                }
                try {
                    //Prevents empty api requests causing 400 errors for non submission notifications
                    if (result[i].submissionId !== 0) {
                        let subResult = await new ApiClient(process.env.REACT_APP_API_BASE).submissions_GetSubmission(
                            result[i].submissionId,
                            undefined
                        );
                        titles.set(result[i].submissionId, subResult.title);
                    }
                } catch (e) {
                    console.log('submission not found');
                }
                arr.push(result[i]);
            }
            setReadArr(arr);
            setUserMap(users);
            setTitleMap(titles);
            return length;
        }
    }
    /**
     * Mark notification as read
     * @param id
     */
    async function markRead(id: any, refresh: boolean) {
        try {
            await new ApiClient(process.env.REACT_APP_API_BASE).notification_UpdateNotification(id, true);
            props.notificationCheck(SFPCookies.get('userId'), true); //Syncs notification title with actual unread number.
        } catch (e) {
            console.log(e);
        }
        if (refresh) {
            setLoaded(false);
        }
    }
    /**
     * Mark notification as unread
     * @param id
     */
    async function markUnread(id: any) {
        try {
            await new ApiClient(process.env.REACT_APP_API_BASE).notification_UpdateNotification(id, false);
            props.notificationCheck(SFPCookies.get('userId'), true); //Syncs notification title with actual unread number.
        } catch (e) {
            console.log(e);
        }
        setLoaded(false);
    }
    /**
     * Loads notification if they aren't loaded yet
     */
    useEffect(() => {
        function checkNotifications() {
            if (!loaded) {
                loadUnread();
                loadRead();
                setLoaded(true);
            }
        }
        checkNotifications();
    });

    //unused but may be needed again later.
    function refreshPage() {
        window.location.reload(false);
    }

    /**
     * Renders unread notifications
     * */
    function renderUnread() {
        return (
            <div>
                <h3 style={{ color: 'red' }}>New Notifications ({numUnread})</h3>
                <hr
                    style={{
                        border: '0',
                        height: '0',
                        borderTop: '1px solid rgba(0, 0, 0, 0.1)',
                        borderBottom: '1px solid rgba(255, 255, 255, 0.3)'
                    }}></hr>
                <div style={{ paddingLeft: 10 }}>
                    {unreadArr.map((notification) => (
                        <div key={notification.id} className={styles.card}>
                            <PrimaryButton className={styles.editButton} onClick={(e) => markRead(notification.id, true)}>
                                Mark Read
                            </PrimaryButton>
                            <div onClick={(e) => handleClick(notification)}>
                                <h4 className={styles.title}>
                                    {notification.type === NotificationType.Registration
                                        ? `REG: ${userMap.get(notification.triggerId)} created an SFP account.`
                                        : notification.type === NotificationType.Submission
                                        ? `SUB: ${titleMap.get(notification.submissionId)}`
                                        : `RE: ${titleMap.get(notification.submissionId)}`}
                                </h4>
                                <span style={{ color: '#ccc', fontSize: 12, fontWeight: 'normal' }}>
                                    {userMap.get(notification.triggerId)} &bull;{' '}
                                    {getDateString(notification.createdDate.toString())}
                                </span>
                                {/* {notification.updatedDate.toString() !== notification.createdDate.toString() ? (
                                    <span
                                        style={{ color: 'blue', fontWeight: 'normal', fontSize: 12 }}
                                        title={getDateString(notification.updatedDate.toString())}>
                                        {' '}
                                    </span>
                                ) : (
                                    <div />
                                )} */}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    /**
     * Renders previously read notifications
     * */
    function renderRead() {
        return (
            <div>
                <h3>Previous Notifications ({numRead})</h3>
                <hr
                    style={{
                        border: '0',
                        height: '0',
                        borderTop: '1px solid rgba(0, 0, 0, 0.1)',
                        borderBottom: '1px solid rgba(255, 255, 255, 0.3)'
                    }}></hr>
                <div style={{ paddingLeft: 10 }}>
                    {readArr.map((notification) => (
                        <div key={notification.id} className={styles.card}>
                            <PrimaryButton className={styles.editButton} onClick={(e) => markUnread(notification.id)}>
                                Mark Unread
                            </PrimaryButton>
                            <div onClick={(e) => handleClick(notification)}>
                                <h4 className={styles.title}>
                                    {notification.type === NotificationType.Registration
                                        ? `REG: ${userMap.get(notification.triggerId)} created an SFP account.`
                                        : notification.type === NotificationType.Submission
                                        ? `SUB: ${titleMap.get(notification.submissionId)}`
                                        : `RE: ${titleMap.get(notification.submissionId)}`}
                                </h4>
                                <span style={{ color: '#ccc', fontSize: 12, fontWeight: 'normal' }}>
                                    {userMap.get(notification.triggerId)} &bull;{' '}
                                    {getDateString(notification.createdDate.toString())}
                                </span>
                                {/* {notification.updatedDate.toString() !== notification.createdDate.toString() ? (
                                    <span
                                        style={{ color: 'blue', fontWeight: 'normal', fontSize: 12 }}
                                        title={getDateString(notification.updatedDate.toString())}>
                                        {' '}
                                    </span>
                                ) : (
                                    <div />
                                )} */}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    }
    /**
     * Handles clicking on a notification, and which page to send to
     * @param notification
     */
    function handleClick(notification: NotificationDto) {
        if (!notification.isRead) {
            markRead(notification.id, false);
        }
        if (notification.type == NotificationType.Registration) {
            window.location.href = '/users/view/' + notification.triggerId;
        }
        if (notification.type == NotificationType.Submission) {
            window.location.href = '/submissions/view/' + notification.submissionId;
        }
        if (notification.type == NotificationType.Reply) {
            window.location.href = '/submissions/view/' + notification.submissionId;
        }
    }

    //Renders read and unread notifications based on whether any exist.
    function renderNotifications() {
        return (
            <div>
                {numUnread > 0 ? <div>{renderUnread()}</div> : <div></div>}
                {numRead > 0 ? <div>{renderRead()}</div> : <div></div>}
            </div>
        );
    }

    if (loaded) {
        return renderNotifications();
    } else {
        return <div></div>;
    }
};

export default Notifications;
