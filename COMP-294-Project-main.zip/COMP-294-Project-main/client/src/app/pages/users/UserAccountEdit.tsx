import React from 'react';
import SFPAuth from 'app/components/SFPAuth';
import { HR } from 'app/pages/submissions/SubmissionView';
import { IIconProps, PrimaryButton, TextField, Toggle, Label, Modal } from '@fluentui/react';
import { ApiClient, UserDto } from 'app/generated/backend';
import styles from 'app/App.module.scss';
import SFPCookies from 'app/components/SFPCookies';

interface textFieldProps {
    onChange: any;
    placeHolder: string;
    required: boolean;
    name: string;
    redStar: any;
    type: string;
}

interface labelProps {
    required: boolean;
    name: string;
    fontSize: number;
}

/** Red star to be used with the req forms */
export const RedStar: React.FC = () => {
    return <span style={{ color: 'red' }}>* </span>;
};

/** Various icons for buttons */
export const sendIcon: IIconProps = { iconName: 'Send' };
export const shield: IIconProps = { iconName: 'Shield' };
export const zoomIcon: IIconProps = { iconName: 'Zoom' };

/**
 * Gray labels used throughout rener.
 * @param props
 * @returns
 */
export const GrayLabel: React.FC<labelProps> = (props) => {
    let label;
    if (props.required) {
        label = (
            <Label htmlFor={props.name} style={{ fontSize: props.fontSize }} className={styles.grayText}>
                <RedStar></RedStar>
                {props.name}
            </Label>
        );
    } else {
        label = (
            <Label htmlFor={props.name} style={{ fontSize: props.fontSize }} className={styles.grayText}>
                {props.name}
            </Label>
        );
    }
    return label;
};

/**
 * Input field to use throughout render function.
 * @param props
 * @returns
 */
export const InputField: React.FC<textFieldProps> = (props) => {
    return (
        <div>
            <GrayLabel fontSize={12} required={props.required} name={props.name} />
            <TextField
                type={props.type}
                borderless
                underlined
                style={{ fontSize: 18 }}
                size={15}
                id={props.name}
                value={props.placeHolder}
                onChange={(e, str) => props.onChange(str)}></TextField>
        </div>
    );
};
interface programObj {
    name: string;
    id: number;
}
interface IState {
    loaded: boolean;
    fName: string;
    lName: string;
    email: string;
    phoneNumber: string;
    userRole: number;
    degreeProgramId: number;
    currUserIsAdmin: boolean;
    shownUserId: number;
    userId: number;
    degreeList: Array<programObj>;
    msg: string;
    username: string;
    password: string;
    isActive: boolean;
    changePwd: boolean;
    newPwd: string;
    newPwdConfirm: string;
    pwdErrMsg: string;
    location: string;
    notFoundErr: boolean;
    shownUserIsAdmin: boolean;
}
interface IProps {
    location: string;
}
class UserAccountEdit extends React.Component<IProps, IState> {
    constructor(props: any) {
        super(props);
        // Bind all the handlers to this. Doing this allows them to be used in the children like InputField.
        this.handleFirstName = this.handleFirstName.bind(this);
        this.handleEmail = this.handleEmail.bind(this);
        this.handleLastName = this.handleLastName.bind(this);
        this.handlePhoneNumber = this.handlePhoneNumber.bind(this);
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handlePasswordConfirmChange = this.handlePasswordConfirmChange.bind(this);
        this.handleUserRole = this.handleUserRole.bind(this);
        this.handleDegree = this.handleDegree.bind(this);
        this.handleActive = this.handleActive.bind(this);

        /**
         * Redirect if the incoming location is users and user is not admin.
         * Grab user id from URL if user is admin and incoming location is users.
         * Grab userId from cookies if incoming location is profile.
         */
        let userId = 0;
        if (props.location === 'users') {
            if (!SFPAuth.isAdmin()) {
                window.location.href = '/profile/edit';
            } else {
                userId = this.getUserId();
            }
        } else if (props.location === 'profile') {
            userId = SFPCookies.get('userId');
        }

        this.state = {
            loaded: false,
            shownUserId: userId,
            fName: '',
            lName: '',
            email: '',
            phoneNumber: '',
            userRole: 0,
            degreeProgramId: 0,
            degreeList: [],
            currUserIsAdmin: SFPAuth.isAdmin(),
            userId: SFPCookies.get('userId'),
            username: '',
            msg: '',
            password: '',
            isActive: false,
            changePwd: false,
            newPwd: '',
            newPwdConfirm: '',
            pwdErrMsg: '',
            location: props.location,
            notFoundErr: false,
            shownUserIsAdmin: false
        };
    }

    /**
     * Gets user id from url.
     * @returns
     */
    getUserId() {
        let path = window.location.pathname.split('/');
        let id = parseInt(path[path.length - 1]);
        if (id !== undefined && id !== null && !isNaN(id)) {
            return id;
        } else {
            window.location.href = '/users';
        }
    }

    /**
     * Grabs user values and programs from API.
     */
    async loadUserValues() {
        try {
            let userResult = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetUser(this.state.shownUserId);
            let programResult = await new ApiClient(process.env.REACT_APP_API_BASE).programs_GetAllPrograms();
            let progArr = new Array<programObj>();

            //Map program result array to object array and push to state.
            programResult.forEach(function (program) {
                let prog: programObj = {
                    name: program.name,
                    id: program.id
                };
                progArr.push(prog);
            });
            //Set state with new info from API.
            this.setState({
                username: userResult.username,
                fName: userResult.firstName,
                lName: userResult.lastName,
                email: userResult.email,
                phoneNumber: userResult.phone,
                loaded: true,
                userRole: userResult.isAdmin ? 1 : 0,
                degreeProgramId: userResult.programId,
                degreeList: progArr,
                password: userResult.password,
                isActive: userResult.isActive,
                userId: userResult.id,
                shownUserIsAdmin: userResult.isAdmin
            });
        } catch (e) {
            console.log(e);
            this.setState({
                loaded: true,
                notFoundErr: true
            });
        }
    }

    /**
     * If page hasn't been loaded yet, calls loadUserValues.
     */
    componentDidMount() {
        if (!this.state.loaded) {
            this.loadUserValues();
        }
    }

    /**
     * Sets Degree
     * @param degree
     */
    handleDegree(degree: any) {
        this.setState({
            msg: '',
            degreeProgramId: degree.target.value
        });
    }

    /**
     * Sets user Role
     * @param role
     */
    handleUserRole(role: any) {
        this.setState({
            msg: '',
            userRole: role.target.value,
            shownUserIsAdmin: !this.state.shownUserIsAdmin
        });
    }

    /**
     * Sets Phone Number
     * @param num
     */
    handlePhoneNumber(num: string) {
        this.setState({
            msg: '',
            phoneNumber: num
        });
    }

    /**
     * Sets Email
     * @param email
     */
    handleEmail(email: string) {
        this.setState({
            msg: '',
            email: email
        });
    }

    /**
     * Sets last name
     * @param name
     */
    handleLastName(name: string) {
        this.setState({
            msg: '',
            lName: name
        });
    }

    /**
     * Sets first name
     * @param name
     */
    handleFirstName(name: string) {
        this.setState({
            msg: '',
            fName: name
        });
    }

    /**
     * Redirects to profile view page.
     * @param e
     */
    handleView() {
        if (this.state.location === 'users') {
            window.location.href = '/users/view/' + this.state.shownUserId;
        } else {
            window.location.href = '/profile';
        }
    }

    /**
     * Opens password change modal if change password button clicked.
     */
    handleChangePwdClick() {
        this.setState({
            changePwd: !this.state.changePwd,
            newPwd: '',
            newPwdConfirm: ''
        });
    }

    /**
     * Handles new password input from modal. Handles validation
     * if a confirm password was already entered.
     * @param pass
     */
    handlePasswordChange(pass: string) {
        if (this.state.newPwdConfirm !== '' && pass !== this.state.newPwdConfirm) {
            this.setState({
                pwdErrMsg: 'Your passwords do not match.'
            });
        } else {
            this.setState({
                pwdErrMsg: ''
            });
        }
        this.setState({
            newPwd: pass
        });
    }

    /**
     * Handles confirm password input from modal. Hanldes validation against
     * new password that was entered.
     * @param pass
     */
    handlePasswordConfirmChange(pass: string) {
        if (pass.trim() !== '' && pass !== this.state.newPwd) {
            this.setState({
                pwdErrMsg: 'Your passwords do not match.'
            });
        } else {
            this.setState({
                pwdErrMsg: ''
            });
        }
        this.setState({
            newPwdConfirm: pass
        });
    }

    /**
     * Sets users active/inactive state.
     * @param ev
     * @param checked
     */
    handleActive(ev: React.MouseEvent<HTMLElement>, checked?: boolean) {
        this.setState({
            isActive: checked,
            msg: ''
        });
    }

    /**
     * Validates inputs and submits update.
     * @param e
     */
    async handleSubmit() {
        if (this.state.fName.trim() === '') {
            this.setState({
                msg: 'Your first name cannot be blank.'
            });
        } else if (this.state.lName.trim() === '') {
            this.setState({
                msg: 'Your last name cannot be blank.'
            });
        } else {
            try {
                let programId = this.state.degreeProgramId;
                if (this.state.userRole.toString() === '1') {
                    programId = 0;
                }
                let userDto = new UserDto();
                userDto.init({
                    programId: programId,
                    firstName: this.state.fName,
                    lastName: this.state.lName,
                    phone: this.state.phoneNumber,
                    email: this.state.email,
                    username: this.state.username,
                    password: this.state.password,
                    isActive: this.state.isActive,
                    isAdmin: this.state.userRole.toString() === '1' ? true : false,
                    id: this.state.userId
                });
                await new ApiClient(process.env.REACT_APP_API_BASE).users_UpdateUser(userDto);

                if (this.state.location === 'users') {
                    window.location.href = '/users/view/' + this.state.shownUserId;
                } else {
                    SFPCookies.set('userName', `${this.state.fName} ${this.state.lName}`);
                    SFPCookies.set('isAdmin', this.state.userRole.toString() === '1' ? true : false);
                    window.location.href = '/profile';
                }
            } catch (e) {
                this.setState({
                    msg: 'Something went wrong with your submission. Please try again later.'
                });
            }
        }
    }

    /**
     * Updates password via api call and closes modal.
     */
    async handlePwdUpdate() {
        if (this.state.newPwd.trim() !== '' && this.state.newPwd.trim() === this.state.newPwdConfirm.trim()) {
            try {
                await new ApiClient(process.env.REACT_APP_API_BASE).users_UpdatePassword(this.state.userId, this.state.newPwd);
                this.setState({
                    msg: 'Password Updated',
                    changePwd: false
                });
            } catch (e) {
                this.setState({
                    pwdErrMsg: 'Something went wrong with your submission. Please try again later.'
                });
            }
        }
    }

    render() {
        if (!this.state.loaded) {
            return <div></div>;
        } else if (this.state.notFoundErr) {
            return <h1 style={{ color: 'red' }}>User Not Found</h1>;
        } else if (SFPAuth.isAdmin() && SFPCookies.get('userId') === this.state.shownUserId && this.state.location === 'users') {
            window.location.href = '/profile/edit';
        } else {
            return (
                <div
                    style={{
                        paddingTop: 40,
                        width: 1000
                    }}>
                    <div style={{ display: 'grid', gridAutoFlow: 'column' }}>
                        <div style={{ width: 300 }}>
                            {this.state.location === 'users' ? <h1>Edit User Profile</h1> : <h1>Edit My Profile</h1>}
                        </div>
                        <div style={{ width: 200, paddingTop: 30, float: 'right' }}>
                            <PrimaryButton
                                styles={{
                                    flexContainer: {
                                        flexDirection: 'row-reverse'
                                    }
                                }}
                                style={{ float: 'right' }}
                                iconProps={zoomIcon}
                                onClick={() => this.handleView()}>
                                VIEW
                            </PrimaryButton>
                        </div>
                    </div>

                    <div className={styles.profileContainer}>
                        <div style={{ width: 750 }}>{HR}</div>
                        <span style={{ color: 'red' }}>{this.state.msg}</span>
                        <form onSubmit={() => this.handleSubmit()}>
                            <div className={styles.profileInner}>
                                <Toggle
                                    label={
                                        <span className={styles.grayText}>
                                            <RedStar></RedStar> Account Status
                                        </span>
                                    }
                                    disabled={!(this.state.currUserIsAdmin && this.state.location === 'users')}
                                    onText="Active"
                                    offText="Inactive"
                                    aria-required
                                    onChange={this.handleActive}
                                    defaultChecked={this.state.isActive}></Toggle>
                            </div>

                            <div className={styles.profileInner}>
                                <InputField
                                    type="text"
                                    redStar={RedStar}
                                    name="First Name"
                                    placeHolder={this.state.fName}
                                    onChange={this.handleFirstName}
                                    required={true}></InputField>
                                <InputField
                                    type="text"
                                    redStar={RedStar}
                                    name="Last Name"
                                    placeHolder={this.state.lName}
                                    onChange={this.handleLastName}
                                    required={true}></InputField>
                            </div>
                            <div className={styles.newRow}></div>
                            <div className={styles.profileInner}>
                                <div style={{ width: 375 }}>
                                    <InputField
                                        type="text"
                                        redStar={RedStar}
                                        name="Email Address"
                                        placeHolder={this.state.email}
                                        onChange={this.handleEmail}
                                        required={false}></InputField>
                                </div>
                                <InputField
                                    type="text"
                                    redStar={RedStar}
                                    name="Phone Number"
                                    placeHolder={this.state.phoneNumber}
                                    onChange={this.handlePhoneNumber}
                                    required={false}></InputField>
                            </div>
                            <div className={styles.newRow}></div>
                            <div className={styles.profileInner}>
                                <div style={{ width: 200 }}>
                                    <GrayLabel fontSize={12} name="User Role" required={true}></GrayLabel>
                                    <select
                                        id="User Role"
                                        disabled={this.state.location === 'profile'}
                                        defaultValue={this.state.userRole}
                                        className={styles.underlinedDropDown}
                                        onChange={this.handleUserRole}
                                        style={{ width: 300, fontSize: 18 }}>
                                        <option key={0} value={0}>
                                            Student
                                        </option>
                                        <option key={1} value={1}>
                                            Admin
                                        </option>
                                    </select>
                                </div>
                                {this.state.shownUserIsAdmin ? (
                                    <div></div>
                                ) : (
                                    <div style={{ paddingLeft: 10 }}>
                                        <GrayLabel fontSize={12} name="Degree Program" required={false}></GrayLabel>
                                        <select
                                            id="Degree Program"
                                            defaultValue={this.state.degreeProgramId}
                                            className={styles.underlinedDropDown}
                                            style={{ width: 290, fontSize: 18 }}
                                            onChange={(e) => this.handleDegree(e)}>
                                            <option key={0} value={0}>
                                                No Program
                                            </option>

                                            {this.state.degreeList.map((degree) => (
                                                <option key={degree.id} value={degree.id}>
                                                    {degree.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                            </div>
                            <div style={{ paddingTop: 30 }}>
                                <div>
                                    <PrimaryButton
                                        styles={{
                                            flexContainer: {
                                                flexDirection: 'row-reverse'
                                            }
                                        }}
                                        onClick={() => this.handleSubmit()}
                                        style={{
                                            float: 'left'
                                        }}
                                        iconProps={sendIcon}
                                        text={'UPDATE'}
                                    />
                                </div>
                                {this.state.location === 'users' ? (
                                    <div></div>
                                ) : (
                                    <div style={{ paddingLeft: 150 }}>
                                        <PrimaryButton
                                            styles={{
                                                flexContainer: {
                                                    flexDirection: 'row-reverse'
                                                }
                                            }}
                                            className={styles.changePasswordButton}
                                            onClick={() => this.handleChangePwdClick()}
                                            iconProps={shield}
                                            text={'CHANGE PASSWORD'}
                                        />
                                    </div>
                                )}
                            </div>
                        </form>
                    </div>
                    <Modal isOpen={this.state.changePwd}>
                        <div style={{ width: 350, height: 275 }}>
                            <div style={{ padding: 10 }}>
                                <h4>Password Change</h4>
                                <span style={{ color: 'red', fontSize: 10 }}>{this.state.pwdErrMsg}</span>
                                <InputField
                                    type="password"
                                    onChange={this.handlePasswordChange}
                                    required={true}
                                    name="New Password"
                                    placeHolder={this.state.newPwd}
                                    redStar={true}></InputField>
                                <InputField
                                    type="password"
                                    onChange={this.handlePasswordConfirmChange}
                                    required={true}
                                    name="Confirm Password"
                                    placeHolder={this.state.newPwdConfirm}
                                    redStar={true}></InputField>
                                <div style={{ display: 'grid', gridAutoFlow: 'column', paddingTop: 20 }}>
                                    <div>
                                        <PrimaryButton
                                            styles={{
                                                flexContainer: {
                                                    flexDirection: 'row-reverse'
                                                }
                                            }}
                                            iconProps={sendIcon}
                                            onClick={() => this.handlePwdUpdate()}>
                                            UPDATE
                                        </PrimaryButton>
                                    </div>
                                    <div>
                                        <PrimaryButton onClick={() => this.setState({ changePwd: false })}>CANCEL</PrimaryButton>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Modal>
                </div>
            );
        }
    }
}
export default UserAccountEdit;
