import sfpAuth from '../../components/SFPAuth';
import { Redirect } from 'react-router-dom';
import { ApiClient, ISubmissionDto, IUserDto } from 'app/generated/backend';
import { Dropdown, IDropdownOption, IDropdownStyles, CheckboxVisibility, DetailsList, DetailsListLayoutMode, hiddenContentStyle, IColumn, Selection, Spinner, SpinnerSize, initializeComponentRef } from '@fluentui/react';
import sfpCookies from '../../components/SFPCookies';
import React, { useEffect, useState, } from 'react';
import { IContextualMenuProps, IIconProps, Stack, IStackStyles } from '@fluentui/react';
import { TextField, ITextFieldStyles } from '@fluentui/react/lib/TextField';
import { MarqueeSelection } from '@fluentui/react/lib/MarqueeSelection';
import { mergeStyles } from '@fluentui/react/lib/Styling';
import { Text } from '@fluentui/react/lib/Text';
import { DefaultButton, PrimaryButton } from '@fluentui/react/lib/Button';
import { getDateString } from 'app/utils/utilities';

interface IUserListDto extends IUserDto {

    program: string | undefined;
    fullname: string | undefined;
    lastLoggedIn: string | undefined;
}

function Users() {


    const addIcon: IIconProps = { iconName: 'Add' };
    const [data, setData] = useState({
        allUsers: [] as IUserListDto[],
        filteredUsers: [] as IUserListDto[],
        isFetching: false
    });
    const initialUserList: IUserListDto[] = [];
    const [filters, setfilterSize] = useState({
        columnName: "ms-Grid-col 12",
        percentage: "25%",
    });
    
    const checkboxVisibility: CheckboxVisibility = 2;
    const dropdownStyles: Partial<IDropdownStyles> = { dropdown: { width: "100%" } };
    const roleDropdownOptions = [
        { key: 0, text: 'Student' },
        { key: 1, text: 'Administrator' },
        { key: 2, text: 'All' },
    ];
    const statusDropdownOptions = [
        { key: 0, text: 'Active' },
        { key: 1, text: 'Inactive' },
        { key: 2, text: 'All' },
    ];
    const [isAdmin, setAdmin] = useState({
        isAdmin: false
    });
    const [emptyUserResult, setUserResult] = useState({
        empty: false
    });

    


    var columns = [
        { key: 'column0', name: 'ID',               fieldName: 'id', minWidth: 20, maxWidth: 20, isResizable: true },
        { key: 'column1', name: 'Name',             fieldName: 'name', minWidth: 40, maxWidth: 120, isResizable: true },
        { key: 'column2', name: 'Email',            fieldName: 'email', minWidth: 40, maxWidth: 150, isResizable: true },
        { key: 'column3', name: 'Phone',            fieldName: 'phone', minWidth: 40, maxWidth: 120, isResizable: true },
        { key: 'column4', name: 'Role',             fieldName: 'isAdmin', minWidth: 40, maxWidth: 120, isResizable: true },
        { key: 'column5', name: 'Last Logged In',   fieldName: 'lastLoggedIn', minWidth: 40, maxWidth: 150, isResizable: true },
        { key: 'column6', name: 'Active',           fieldName: 'isActive', minWidth: 40, maxWidth: 80, isResizable: true },
    ];

  



    const _onFilterByName = (ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, text: string): void => {
        setData({ allUsers: data.allUsers, filteredUsers: text ? data.allUsers.filter(i => i.fullname.toLowerCase().indexOf(text.toLowerCase()) > -1) : data.allUsers, isFetching: false });
    };

    const _onFilterByEmail = (ev: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>, text: string): void => {
        setData({ allUsers: data.allUsers, filteredUsers: text ? data.allUsers.filter(i => i.email.toLowerCase().indexOf(text) > -1) : data.allUsers, isFetching: false });
    };

 

    const _onFilterByRole = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption) => {
        if (item.key < 2) {
            var admin = (item.key == 1);
            setData({ allUsers: data.allUsers, filteredUsers: item ? data.allUsers.filter(i => i.isAdmin == admin) : data.allUsers, isFetching: false });
        } else {
            setData({ allUsers: data.allUsers, filteredUsers: data.allUsers, isFetching: false });
        }
    };
    const _onFilterByStatus = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption) => {
        if (item.key < 2) {
            var active = (item.key == 0);
            setData({ allUsers: data.allUsers, filteredUsers: item ? data.allUsers.filter(i => i.isActive == active) : data.allUsers, isFetching: false });
        } else {
            setData({ allUsers: data.allUsers, filteredUsers: data.allUsers, isFetching: false });
        }
    };

    const _renderItemColumn = (item: IUserDto, index: number, column: IColumn) => {
        var fieldContent = item[column.fieldName as keyof IUserDto] as string;
        const link = "/users/view/" + item.id.toString();

        switch (column.name) {

            case 'Name': {
                fieldContent = item.firstName + " " + item.lastName;
            return <a href={link}>{fieldContent}</a>;
                }
            
            case 'Role': {
                if (item.isAdmin) {
                    fieldContent = "Administrator";
                } else {
                    fieldContent = "Student";
                }
                return <span>{fieldContent}</span>;
            };
            case 'Active': {
                if (item.isActive) {
                    fieldContent = "YES";
                } else {
                    fieldContent = "NO";
                }
                return <span>{fieldContent}</span>;
            };
            default:
                return <span>{fieldContent}</span>;
        }
    }

    const _addClicked = (): void => {
        window.location.href = "users/create"
    }

    //this entire area is for getting the data we need to build out table
    useEffect(() => {
        const fetchData = async (): Promise<IUserDto[]> => {
                try {
                    setData({ allUsers: data.allUsers, filteredUsers: data.filteredUsers, isFetching: true });
                    const result = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetAllUsers();
                    
                    return result;

                } catch (e) {
                    console.log(e);
                    setData({ allUsers: data.allUsers, filteredUsers: data.filteredUsers, isFetching: false });
                }
            
        };

        const fetchLastLogged = async (userId: number): Promise<string> => {
                try {
                    setData({ allUsers: data.allUsers, filteredUsers: data.filteredUsers, isFetching: true });
                    const result = await new ApiClient(process.env.REACT_APP_API_BASE).loginAudit_GetAuditById(userId);
                    var date = result.dateLoggedIn;
                    // return date.toDateString();
                    return getDateString(date.toString());

                } catch (e) {
                    console.log(e);
                    setData({ allUsers: data.allUsers, filteredUsers: data.filteredUsers, isFetching: false });
                }
            


        };
              

        //runs through the async stack and builds out the initialSubmissionList

        fetchData().then(result => {
            if (result.length > 0) {
                result.forEach((user) => {
                    fetchLastLogged(user.id).then(lastLogged => {

                        var newUser: IUserListDto = {
                            id: user.id,
                            firstName: user.firstName,
                            lastName: user.lastName,
                            // when user has no email, it is null, but we need final value to be a string
                            // for the filter to work properly, for instance
                            email: user.email ? user.email : '',
                            phone: user.phone,
                            programId: user.programId,
                            lastLoggedIn: lastLogged,
                            program: "",
                            isActive: user.isActive,
                            isAdmin: user.isAdmin,
                            createdDate: user.createdDate,
                            updatedDate: user.createdDate,
                            fullname: user.firstName + " " + user.lastName
                        }

                        initialUserList.push(newUser);
                        setData({ allUsers: initialUserList, filteredUsers: initialUserList, isFetching: false });

                    })
                });
                setUserResult({ empty: false });
                console.log(emptyUserResult.empty);
            } else {
                setData({ allUsers: data.allUsers, filteredUsers: data.filteredUsers, isFetching: false });
                setUserResult({ empty: true });
            }
        });

        //eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    if (!sfpAuth.isAdmin()) {
        window.location.href = '/';
        return;

    } else {
        return (
            <div>

                <h1>Users</h1>

                <div><PrimaryButton
                    styles={{
                        flexContainer: {
                            flexDirection: 'row-reverse'
                        }
                    }}
                    type="submit"
                    style={{
                        float: 'right'
                    }}
                    iconProps={addIcon}
                    text={'Add User'}
                    onClick={_addClicked}
                /><br /><br /><br /></div>


                <div hidden={emptyUserResult.empty} className="ms-Grid-row" style={{
                    width: '100%'
                }}>
                    <div className={filters.columnName} style={{ width: filters.percentage, }}>
                        <TextField label="Filter by Name:" onChange={_onFilterByName} />
                    </div>
                    <div className={filters.columnName} style={{ width: filters.percentage, }}>
                        <TextField label="Filter by Email" onChange={_onFilterByEmail} />
                    </div>
                    <div className={filters.columnName} style={{
                        width: filters.percentage,
                    }}>
                        <Dropdown
                            label="Filter by Role"
                            onChange={_onFilterByRole}
                            options={roleDropdownOptions}
                            styles={dropdownStyles}
                        />
                    </div>

                    <div className={filters.columnName} style={{
                        width: filters.percentage,
                    }}>
                        <Dropdown
                            label="Filter by Status"
                            onChange={_onFilterByStatus}
                            options={statusDropdownOptions}
                            styles={dropdownStyles}
                        />
                    </div>



                </div>
                <div hidden={!emptyUserResult.empty}><h3>No Submissions Found </h3></div>
                <div hidden={emptyUserResult.empty} className="ms-Grid-row">

                    <DetailsList className="usersList"
                        items={data.filteredUsers.map((user) => {
                            return {
                                ...user,
                                createdDate: user.createdDate.toLocaleString(),
                                updatedDate: user.updatedDate.toLocaleString()
                            };
                        })}
                        checkboxVisibility={checkboxVisibility}
                        columns={columns}
                        onRenderItemColumn={_renderItemColumn}
                        layoutMode={DetailsListLayoutMode.justified}
                    />
                    {data.isFetching && <Spinner size={SpinnerSize.large} />}

                </div>
            </div>
        );
    }
};

export default Users;
