import React from 'react';
import SFPCookies from 'app/components/SFPCookies';
import SFPAuth from 'app/components/SFPAuth';
import { getDateString } from 'app/utils/utilities';
import { ApiClient, UserDto, LoginAuditDto, ProgramDto } from 'app/generated/backend';
import { IIconProps, PrimaryButton } from '@fluentui/react';

interface StyleSheet {
    [key: string]: React.CSSProperties;
}

interface IState {
    profile: {
        firstName: string;
        lastName: string;
        programId: number;
        email: any;
        phone: any;
        isAdmin: boolean;
        isActive: boolean;
    };
    loginAudit: {
        dateLoggedIn: string;
        dateLoggedOut: string;
    }
    loaded: boolean;
    degreeProgram: string;
    dto: UserDto;
    viewId: number;
}
const editIcon: IIconProps = {
    iconName: 'EditContact',
    style: { fontSize: '13px' }
};
const styles: StyleSheet = {
    editButton: {
        float: 'right',
        fontSize: 12,
        font: 'Segoe UI',
        fontWeight: 400,
        backgroundColor: '#ffb44a',
        color: 'white',
        height: 20,
        padding: 15,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        border: 'none',

    },
    accountType: {
        fontStyle: 'italic'
    },
    floatContainer: {

    },
    floatChild: {
        width: '33%',
        float: 'left',
    }
};

class UsersView extends React.Component<{}, IState> {
    constructor(props: any) {
        super(props);
        this.state = {
            degreeProgram: null,
            loaded: false,
            profile: null,
            loginAudit: null,
            dto: null,
            viewId: 0
        };
    }

    handleEdit() {
        window.location.href = '/users/edit/' + this.state.viewId;
    }

    render() {
        if (this.state.loaded) {
            return <div>{this.renderProfile()}</div>
        } else {
            return <div>Loading Profile</div>
        }
    }

    //renders log in and log out dates for rendering profile
    renderLoginDate() {
        //a user without a login audit will display this
        if (this.state.loginAudit.dateLoggedIn == '') {
            return <div style={{ fontSize: '14px', paddingBottom: '30px' }}>Never logged in</div>
        }
        //if user has never logged out, their logout date will be a placeholder that's less than current date
        else if (this.state.loginAudit.dateLoggedOut < this.state.loginAudit.dateLoggedIn) {
            return <div style={{ fontSize: '14px', paddingBottom: '30px' }}>Logged in since <b>{this.state.loginAudit.dateLoggedIn}</b></div>
        }
        else {
            return <div style={{ fontSize: '14px', paddingBottom: '30px' }}>Last logged in <b>{this.state.loginAudit.dateLoggedIn}</b> to <b>{this.state.loginAudit.dateLoggedOut}</b></div>
        }
    }

    renderProfile() {
        return (
            <div>
                <PrimaryButton styles={{
                    flexContainer: {
                        flexDirection: 'row-reverse'
                    }
                }}
                    style={styles.editButton}
                    iconProps={editIcon}
                    onClick={(e) => this.handleEdit()}
                >EDIT</PrimaryButton>

                <h2>User Profile</h2>
                <hr style={{ border: '0', height: '0', borderTop: '1px solid rgba(0, 0, 0, 0.1)', borderBottom: '1px solid rgba(255, 255, 255, 0.3)' }}></hr>
                <br></br>

                <div style={{ fontWeight: 'bold' }}>{this.state.profile.firstName + " " + this.state.profile.lastName}</div>

                {this.state.profile.isAdmin === true ? (
                    <div style={{ fontSize: '12px', fontStyle: 'italic' }}>Administrator</div>) :
                    (<div style={{ fontSize: '12px', fontStyle: 'italic' }}>Student</div>)}
                <br></br>
                <div style={{ fontSize: '14px', paddingBottom: '10px' }}>Account Status:
                    {this.state.profile.isActive === true ? (<b> ACTIVE</b>) : (<b> INACTIVE</b>)}
                </div>
                {this.renderLoginDate()}
                <div style={styles.floatContainer}>
                    <div style={styles.floatChild}>
                        <div style={{ fontSize: '14px', fontWeight: 'bold' }}>Email Address</div>
                        <div style={{ fontSize: '14px' }}>{this.state.profile.email === null ? ('--') :
                            (this.state.profile.email)}</div>
                    </div>

                    <div style={styles.floatChild}>
                        <div style={{ fontSize: '14px', fontWeight: 'bold' }}>Phone</div>
                        <div style={{ fontSize: '14px' }}>{this.state.profile.phone === null ? ('--') :
                            (this.state.profile.phone)}</div>
                    </div>

                    <div style={styles.floatChild}>
                        {this.state.profile.isAdmin === false ? (
                                <>
                                    <div style={{ fontSize: '14px', fontWeight: 'bold' }}>Degree Program</div>
                                    <div style={{ fontSize: '14px' }}>{this.state.degreeProgram === null ? ('--') :
                                        (this.state.degreeProgram)}</div>
                                </>
                            ) : (
                                <></>
                            )
                        }
                    </div>
                </div>
            </div>
        );
    }

    componentDidMount() {
        // first of all, students are not allowed on this page
        if (SFPAuth.isStudent()) {
            window.location.href = '/'
            return ''
        }

        let path = window.location.pathname.split('/');
        let id = parseInt(path[path.length - 1]);

        // if this is the currently logged in admin's ID, redirect to the Profile version of this page
        if (SFPCookies.get('userId') === id) {
            window.location.href = '/profile'
            return ''
        }

        this.setState({
            viewId: id
        });
        if (!this.state.loaded) {
            this.loadProfileDto(id);
        }
    }

    async loadProfileDto(id: number) {
        let result = null;
        let audit = null;
        let program = null;
        try {
            result = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetUser(id);
            try {
                program = await new ApiClient(process.env.REACT_APP_API_BASE).programs_GetProgram(result.programId);
                this.setState({ degreeProgram: program.name });
            } catch {
                //if the getProgram API finds nothing, especially if users programId is 0 set program to null
                this.setState({ degreeProgram: null });
            }
            this.setState({
                profile: {
                    firstName: result.firstName,
                    lastName: result.lastName,
                    programId: result.programId,
                    phone: result.phone,
                    email: result.email,
                    isActive: result.isActive,
                    isAdmin: result.isAdmin
                }
            });
            
            try {
                audit = await new ApiClient(process.env.REACT_APP_API_BASE).loginAudit_GetAuditById(id);
                this.setState({
                    loginAudit: {
                        dateLoggedIn: getDateString(audit.dateLoggedIn.toString()),
                        dateLoggedOut: getDateString(audit.dateLoggedOut.toString())
                    },
                    loaded: true
                });
            } catch {
                //if user has never logged in set the log in dates to empty strings for different outputs
                this.setState({
                    loginAudit: {
                        dateLoggedIn: '',
                        dateLoggedOut: ''
                    },
                    loaded: true
                });
            }
        } catch (e) {
            console.log('api call error');
            window.location.href = '/';
        }
    }
};

export default UsersView;
