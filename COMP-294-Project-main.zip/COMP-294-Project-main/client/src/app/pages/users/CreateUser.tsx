import sfpAuth from '../../components/SFPAuth';
import React, { useEffect, useState } from 'react';
import { IIconProps, Text, TextField, PrimaryButton, Label, Toggle, IDropdownOption, IDropdownStyles } from '@fluentui/react';
import styles from 'app/App.module.scss';
import { ApiClient, SubmissionDto, SubscriptionDto, UserDto } from 'app/generated/backend';



interface textFieldProps {
    onChange: any;
    placeHolder: string;
    required: boolean;
    name: string;
    redStar: any;
    type: string;
}

interface labelProps {
    required: boolean;
    name: string;
    fontSize: number;
}
export const InputField: React.FC<textFieldProps> = (props) => {
    return (
        <div>
            <GrayLabel fontSize={12} required={props.required} name={props.name} />
            <TextField
                type={props.type}
                borderless
                underlined
                style={{ fontSize: 18 }}
                size={15}
                id={props.name}
                value={props.placeHolder}
                onChange={(e, str) => props.onChange(str)}></TextField>
        </div>
    );
};

/** Red star to be used with the req forms */
export const RedStar: React.FC = () => {
    return <span style={{ color: 'red' }}>* </span>;
};

/** Various icons for buttons */
export const sendIcon: IIconProps = { iconName: 'Send' };
export const shield: IIconProps = { iconName: 'Shield' };
export const zoomIcon: IIconProps = { iconName: 'Zoom' };

/**
 * Gray labels used throughout rener.
 * @param props
 * @returns
 */
export const GrayLabel: React.FC<labelProps> = (props) => {
    let label;
    if (props.required) {
        label = (
            <Label htmlFor={props.name} style={{ fontSize: props.fontSize }} className={styles.grayText}>
                <RedStar></RedStar>
                {props.name}
            </Label>
        );
    } else {
        label = (
            <Label htmlFor={props.name} style={{ fontSize: props.fontSize }} className={styles.grayText}>
                {props.name}
            </Label>
        );
    }
    return label;
};



interface programObj {
    name: string;
    id: number;
}
function CreateUser() {

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [role, setRole] = useState(false);
    const [isActive, setActive] = useState(true);
    
    const [programId, setProgramId] = useState(0);
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [signUpErr, setErr] = useState(false);
    const [errMsg, setErrMsg] = useState('');
    const [degreeList, setDegreeList] = useState({
        list: [] as programObj[],
       
    });
    


    
    /**
     * Handles submission to DB. Redirects to sign in if successful. Performs last
     * second validation checks and checks if username is already taken.
     * @param e event
     */
    const handleSubmit = async (e: any) => {
        e.preventDefault();
        
        if (
            username.trim() !== '' &&
            password.trim() !== '' &&
            firstName.trim() !== '' &&
            lastName.trim() !== ''
        ) {
            console.log("button");
            let dto = new UserDto();
            dto.init({
                programId: programId,
                firstName: firstName,
                lastName: lastName,
                phone: phone,
                email: email,
                username: username,
                password: password,
                isActive: isActive,
                isAdmin: role
            });
            try {
                console.log(dto);
                let result = await new ApiClient(process.env.REACT_APP_API_BASE).users_CreateUser(dto);
                
                if (result.id !== 0 || result.id !== undefined) {
                    window.location.href = '/users/view/' + result.id;
                }
            } catch (e) {
                console.log(e);
                setErr(true);
                setErrMsg('It looks like that username is taken. Please try another');
            }
        } else {
            setErr(true);
            setErrMsg('Please fill in all required fields.');
        }
    };

    function handleUsernameChange(e:  string) {
        setUsername(e);
        setErr(false);  
    }
    function handleFirstNameChange(e: string) {
        setFirstName(e);
        setErr(false);
    }
    function handleLastNameChange(e: string) {
        setLastName(e);
        setErr(false);
    }
    function handlePasswordChange(e: string) {
        setPassword(e);
        setErr(false);
    }


    /**
     * Grabs user values and programs from API.
     */
    useEffect(() => {
       
            
        const loadProgramValues = async () => {
            if (sfpAuth.isAdmin()) {
                try {
                    let programResult = await new ApiClient(process.env.REACT_APP_API_BASE).programs_GetAllPrograms();
                    let progArr = new Array<programObj>();

                    //Map program result array to object array and push to state.
                    programResult.forEach(function (program) {
                        let prog: programObj = {
                            name: program.name,
                            id: program.id
                        };
                        progArr.push(prog);

                    });
                    setDegreeList({ list: progArr });



                } catch (e) {
                    console.log(e);

                }
            }
        }
        
        loadProgramValues();
        }, []);
   


    const sendIcon: IIconProps = { iconName: 'Send' };

    const msg = <Text style={{ color: '#FF0000' }}>{errMsg}</Text>;

    if (!sfpAuth.isAdmin()) {
        window.location.href = '/';
        return;

    } else {
        return (


            <div style={{ width: 800 }}>
                <div>
                    <h2>Create user</h2>
                    {signUpErr ? msg : <div></div>}
                </div>

                <form onSubmit={(e) => handleSubmit(e)}>
                    <div className={styles.profileInner}>
                        <Toggle
                            label={
                                <span className={styles.grayText}>
                                    Account Status
                                        </span>
                            }
                            onText="Active"
                            offText="Inactive"
                            aria-required
                            onChange={() => setActive(!isActive)}
                            defaultChecked={isActive}></Toggle>
                    </div>

                    <div className={styles.profileInner}>
                        <InputField
                            type="text"
                            redStar={RedStar}
                            name="First Name"
                            placeHolder={firstName}
                            onChange={(e: string) => handleFirstNameChange(e)}
                            required={true}></InputField>
                        <InputField
                            type="text"
                            redStar={RedStar}
                            name="Last Name"
                            placeHolder={lastName}
                            onChange={(e: string) => handleLastNameChange(e)}
                            required={true}></InputField>
                    </div>
                    <div className={styles.newRow}></div>
                    <div className={styles.profileInner}>
                        
                            <InputField
                                type="text"
                                redStar={RedStar}
                                name="Email Address"
                                placeHolder={email}
                                onChange={(e: string) => setEmail(e)}
                                required={false}></InputField>
                            <InputField
                                type="text"
                                redStar={RedStar}
                                name="Phone Number"
                                placeHolder={phone}
                                onChange={(e: string) => setPhone(e)}
                                required={false}></InputField>
                    </div>
                    <div className={styles.newRow}></div>
                    <div className={styles.profileInner}>
                        <div>
                            <InputField
                                type="text"
                                redStar={RedStar}
                                name="Username"
                                placeHolder={username}
                                onChange={(e: string) => handleUsernameChange(e)}
                                required={true}></InputField>
                        </div>
                        <div>
                            <InputField
                                type="password"
                                redStar={RedStar}
                                name="Password"
                                placeHolder={password}
                                onChange={(e: string) => handlePasswordChange(e)}
                                required={true}></InputField>
                        </div>

                    </div>
                   
                    <div className={styles.profileInner}>
                        <div style={{ width: 300 }}>
                            <GrayLabel fontSize={12} name="User Role" required={true}></GrayLabel>
                            <select
                                id="User Role"
                                defaultValue={role ? 1 : 0}
                                className={styles.underlinedDropDown}
                                onChange={(e: any) => setRole(!role)}
                                style={{ width: 300, fontSize: 18 }}>
                                <option key={0} value={0}>
                                    Student
                                        </option>
                                <option key={1} value={1}>
                                    Admin
                                        </option>
                            </select>
                        </div>



                        <div hidden={role} style={{ paddingLeft: 10 }}>
                            <GrayLabel fontSize={12} name="Degree Program" required={false}></GrayLabel>
                            <select
                                id="Degree Program"
                                defaultValue={programId}

                                className={styles.underlinedDropDown}
                                style={{ width: 290, fontSize: 18 }}
                                onChange={(e: any) => setProgramId(e.target.value)}>
                                <option key={0} value={0}>
                                    No Program
                                            </option>

                                {degreeList.list.map((degree) => (
                                    <option key={degree.id} value={degree.id}>
                                        {degree.name}
                                    </option>
                                ))}
                            </select>
                        </div>

                    </div>
                    <div style={{ paddingTop: 30 }}>
                        <div>
                            <PrimaryButton
                                styles={{
                                    flexContainer: {
                                        flexDirection: 'row-reverse'
                                    }
                                }}
                                onClick={(e) => handleSubmit(e)}
                                style={{
                                    float: 'left'
                                }}
                                iconProps={sendIcon}
                                text={'CREATE'}
                            />
                        </div>

                    </div>
                </form>
            </div>
        );
    }
};

export default CreateUser;