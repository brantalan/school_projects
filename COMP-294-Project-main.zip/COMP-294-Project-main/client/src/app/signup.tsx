import React, { useState } from 'react';
import { IIconProps, Text, TextField, Modal, PrimaryButton, Link } from '@fluentui/react';
import styles from './App.module.scss';
import { ApiClient, UserDto, NotificationType } from './generated/backend';
import SFPNotifications from './components/SFPNotifications';
interface Props {
    signedUp: any;
}

/**
 * Sign up page. Acts as a child to Login
 * Handles sign up validation and API calls.
 * @param props
 * @returns
 */
const SignUp: React.FC<Props> = (props) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPass, setConfirmPass] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [signUpErr, setErr] = useState(false);
    const [errMsg, setErrMsg] = useState('');

    /**
     * Handles submission to DB. Redirects to sign in if successful. Performs last
     * second validation checks and checks if username is already taken.
     * @param e event
     */
    const handleSubmit = async (e: any) => {
        e.preventDefault();
        if (
            username !== '' &&
            password !== '' &&
            doPasswordsMatch() &&
            firstName !== '' &&
            lastName !== '' &&
            password.trim() !== '' &&
            !signUpErr
        ) {
            let dto = new UserDto();
            dto.init({
                programId: 0,
                firstName: firstName,
                lastName: lastName,
                username: username,
                password: password,
                isActive: true
            });
            try {
                let result = await new ApiClient(process.env.REACT_APP_API_BASE).users_CreateUser(dto);
                if (result.id !== 0 || result.id !== undefined) {
                    props.signedUp(true);
                    await SFPNotifications.notify(NotificationType.Registration, result.id, result.id);
                }
            } catch (e) {
                setErr(true);
                setErrMsg('It looks like that username is taken. Please try another');
            }
        }
    };

    /**
     * Helper function to provide validation between other
     * error handling calls.
     */
    function doPasswordsMatch() {
        if (password !== confirmPass) {
            setErrMsg('Your passwords do not match');
            setErr(true);
            return false;
        } else {
            setErr(false);
            return true;
        }
    }

    /**
     * Sets username and Err to false given that the username changed.
     * @param e
     * @param uname
     */
    function handleUsernameChange(e: any, uname: string) {
        setUsername(uname);
        setErr(false);
        doPasswordsMatch();
    }

    /**
     * Handles password changes and errors if there are any.
     * @param e
     * @param pass
     */
    function handlePasswordChange(e: any, pass: string) {
        e.preventDefault();
        setConfirmPass(pass);
        if (pass !== '' && pass !== password) {
            setErr(true);
            setErrMsg('Your passwords do not match');
        } else if (password.trim() === '' && pass.trim() === '') {
            setErrMsg('Your password must contain at least one non-space character.');
            setErr(true);
        } else {
            setErr(false);
        }
    }

    const sendIcon: IIconProps = { iconName: 'Send' };

    const msg = <Text style={{ color: '#FF0000' }}>{errMsg}</Text>;

    return (
        <Modal isOpen={true}>
            <div className={styles.signUpDiv}>
                <div className={styles.headingDiv}>
                    <Text className={styles.headerTitleLogin} title="Student Feedback Portal">
                        SFP
                    </Text>
                    <br></br>
                    <h2 style={{ fontWeight: 400 }}>Register for a new account</h2>
                    {signUpErr ? msg : <div></div>}
                </div>
                <form onSubmit={(e) => handleSubmit(e)} style={{ height: 250, marginBottom: 0 }}>
                    <div className={styles.signUpInnerDiv}>
                        <div>
                            <TextField
                                borderless
                                underlined
                                required
                                placeholder="First Name"
                                onChange={(_e, text) => setFirstName(text.trim())}
                            />
                        </div>
                        <div>
                            <TextField
                                underlined
                                required
                                borderless
                                placeholder="Last Name"
                                onChange={(_e, text) => setLastName(text.trim())}
                            />
                        </div>
                    </div>
                    <div className={styles.newrow}>
                        <div>
                            <TextField
                                underlined
                                required
                                borderless
                                placeholder="Username"
                                onChange={(_e, text) => handleUsernameChange(_e, text.trim())}
                            />
                        </div>
                    </div>
                    <div className={styles.signUpInnerDiv}>
                        <div>
                            <TextField
                                borderless
                                underlined
                                required
                                placeholder="Password"
                                type="password"
                                onChange={(_e, text) => setPassword(text)}
                            />
                        </div>
                        <div>
                            <TextField
                                underlined
                                required
                                borderless
                                placeholder="Confirm Password"
                                type="password"
                                onChange={(_e, text) => handlePasswordChange(_e, text)}
                            />
                        </div>
                    </div>
                    <PrimaryButton
                        styles={{
                            flexContainer: {
                                flexDirection: 'row-reverse'
                            }
                        }}
                        type="submit"
                        style={{
                            float: 'left'
                        }}
                        iconProps={sendIcon}
                        text={'REGISTER'}
                    />
                    <br></br>
                    <br></br>
                    <div style={{ textAlign: 'left', paddingTop: 20 }}>
                        <Link href="/">Sign in</Link>
                        <Text> to your account instead </Text>
                    </div>
                </form>
            </div>
        </Modal>
    );
};

export default SignUp;
