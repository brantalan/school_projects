import { Cookies } from 'react-cookie';

export default class SFPCookies {
    private static cookies: Cookies = new Cookies()

    /**
     * Creates or updates (if it already exists) a cookie
     * @param name cookie name
     * @param value cookie value
     */
    public static set(name: string, value: any) {
        SFPCookies.cookies.set(name, value, { path: '/' })
    }

    /**
     * Retrieves a cookie
     * @param name cookie name
     * @returns cookie value
     */
    public static get(name: string) {
        let cookie = SFPCookies.cookies.get(name) || null

        // some data types are not stored as one might expect in cookies
        // convert relevant data types during retrieval
        if (cookie === 'true' || cookie === 'false') {
            cookie = (cookie === 'true') ? true : false
        } else if (!isNaN(cookie) && cookie !== null) {
            cookie = +cookie
        }

        return cookie
    }

    /**
     * Removes a cookie
     * @param name cookie name
     */
    public static remove(name: string) {
        SFPCookies.cookies.remove(name, { path: '/' })
    }
}