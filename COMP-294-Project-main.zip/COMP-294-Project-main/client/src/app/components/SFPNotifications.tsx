import { ApiClient, NotificationType, NotificationDto } from 'app/generated/backend';

/**
 * Class creates notifications for events when notify() is called
 * with appropriate parameters.
 */
export default class SFPNotifications {
    public static async notify(action: NotificationType, entityId: number, triggerId: number) {
        switch (action) {
            case 0:
                //Registration event
                let admins_registration = await this.getAllAdmins();
                admins_registration.forEach(async (admin) => {
                    let dto = new NotificationDto();
                    dto.init({
                        type: action,
                        triggerId: triggerId,
                        receiverId: admin.id,
                        isRead: false
                    });
                    try {
                        await new ApiClient(process.env.REACT_APP_API_BASE).notification_CreateNotification(dto);
                    } catch (e) {
                        console.log(e);
                    }
                });
                break;
            case 1:
                //Submission Event
                let admins_submission = await this.getAllAdmins();
                admins_submission.forEach(async (admin) => {
                    let dto = new NotificationDto();
                    dto.init({
                        type: action,
                        triggerId: triggerId,
                        receiverId: admin.id,
                        submissionId: entityId,
                        isRead: false
                    });
                    try {
                        await new ApiClient(process.env.REACT_APP_API_BASE).notification_CreateNotification(dto);
                    } catch (e) {}
                });
                break;
            case 2:
                //Reply Event
                let reply = await new ApiClient(process.env.REACT_APP_API_BASE).replies_GetReply(entityId);
                let subId = reply.submissionId;
                let subscribers = await this.getAllSubscribers(subId);
                subscribers.forEach(async (subscriber) => {
                    if (triggerId !== subscriber.userId) {
                        //Avoid notifying person who did action.
                        let dto = new NotificationDto();
                        dto.init({
                            type: action,
                            triggerId: triggerId,
                            receiverId: subscriber.userId,
                            replyId: entityId,
                            submissionId: subId,
                            isRead: false
                        });
                        try {
                            await new ApiClient(process.env.REACT_APP_API_BASE).notification_CreateNotification(dto);
                        } catch (e) {
                            console.log(e);
                        }
                    }
                });
                break;
            default:
        }
    }

    /**
     * Grabs all subscribers given a submission id.
     * @param id
     * @returns
     */
    private static async getAllSubscribers(id: number) {
        return await new ApiClient(process.env.REACT_APP_API_BASE).subscription_GetAllSubscribers(id);
    }

    /**
     * Grabs all admins.
     * @returns
     */
    private static async getAllAdmins() {
        let result = await new ApiClient(process.env.REACT_APP_API_BASE).users_GetAllUsers();
        let admins = result.filter((user) => user.isAdmin);
        return admins;
    }
}
