import sfpCookies from 'app/components/SFPCookies'

export default class SFPAuth {
    /**
     * Checks whether the user is currently logged in
     * @returns true / false
     */
    public static isLoggedIn() {
        return sfpCookies.get("userName") !== null
    }

    /**
     * Checks is logged in user is has Student role
     * @returns true / false
     */
    public static isStudent() {
        // check if user both logged in and has student role
        return this.isLoggedIn() && !sfpCookies.get('isAdmin')
    }

    /**
     * Checks is logged in user is has Administrator role
     * @returns true / false
     */
    public static isAdmin() {
        // check if user both logged in and has admin role
        return this.isLoggedIn() && sfpCookies.get('isAdmin')
    }
}