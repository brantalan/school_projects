/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;
import java.sql.*;
/**
 *
 * @author Brant
 */
public class dbConnect {
    
    
    



	static final String USER = "admin";
	static final String PASS = "Junkies489!";
	static final String PORT = "1433";
	static final String HOST = "cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com";
	static final String DATABASE = "cjdb";

	static final String connectionURL = "jdbc:sqlserver://" + HOST + ":" + PORT + ";databaseName=" + DATABASE + ";user="
			+ USER + ";password=" + PASS + ";";

	public Connection getConnection() throws ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
		System.out.println(connectionURL);
		try {
			Connection conn = DriverManager.getConnection(connectionURL);
			return conn;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
}

