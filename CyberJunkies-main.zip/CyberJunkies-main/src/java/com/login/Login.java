/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 *
 * @author Joe
 */
public class Login extends HttpServlet {

   
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        
            int count=0;
            
            String uname = request.getParameter("uname");           
            String pass = request.getParameter("pass");
            boolean validated = Validate.checkUser(uname, pass);
            boolean upgrade = upgraded.checkUser(uname, pass);
            
            
            if(validated && upgrade){
                         
                         request.getSession(true).setAttribute("username", uname);
                         response.sendRedirect("./commandCenter/commandSearch.jsp");
           
            }else if(validated){
               request.getSession(true).setAttribute("username", uname); 
               response.sendRedirect("./UserAccess/memberSearch.jsp");
            }
           
            else{
                response.setHeader("Refresh", "2; URL=loginerror.jsp");
            }
           
            
            
        
    }

    
     
    
}
