/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Joe
 */
public class adminReg extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset-UTF-8");

   try {
                                
                                //String sql = "SELECT first FROM employees;";
                                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
                                Connection con=DriverManager.getConnection("jdbc:sqlserver://cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com:1433;databaseName=cjdb;user=admin;password=Junkies489!;");
                                
                                
                                
                                String first = request.getParameter("first");
                                String last = request.getParameter("last");
                                String street = request.getParameter("street");
                                String city= request.getParameter("city");
                                String state = request.getParameter("state");
                                String zip = request.getParameter("zip");
                                String pass = request.getParameter("psw");
                                String email = request.getParameter("email");
                                //String role = "26";
                                
                                
                                //pass="SHA("+pass+")";
                               
                                Statement stmt = con.createStatement();
                                String insert = "INSERT INTO customerinfo (first,last,street,city,state,zip,pass,email,role) VALUES ('"+first+"', '"+last+"', '"+street+"', '"+city+"', '"+state+"', '"+zip+"', '"+pass+"', '"+email+"', 26);";
                                
                                stmt.execute(insert);
                                //'"+3+"',
                                PrintWriter writer = response.getWriter();
                                writer.println("You have successfully created an account!");
                                writer.println("You are being redirect back to the page.");
                               
                                
                                
                                
                                response.setHeader("Refresh", "2; URL=/betaDropDown/commandCenter/commandSearch.jsp");
                                
                            }catch(Exception ex){
                                    ex.printStackTrace();
                                    response.sendRedirect("somethingWeird.jsp");
                            }               
                              
    
    }
}
