/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.util.ArrayList;

/**
 *
 * @author Brant & Joe
 */
public class Cart {
    int dummyRound=0;    
    int counter=0;
    
    
        ArrayList<Integer> items = new ArrayList<Integer>(); 
        
        
        
        public void add(int id){
       
        
        
        items.add(id);          
        
        
        }
        
        
        
        public void sub(int id){
        
        
        
        items.remove(id);
        
        }
        
        
        
        
        public ArrayList<Integer> contents(){
            
            return items;
        }
        
        public int count(){
            int count=0;
            
            for(int i=0;i<items.size();i++){
                count++;
            }
            
            return count;
        }
        
        
        
}
