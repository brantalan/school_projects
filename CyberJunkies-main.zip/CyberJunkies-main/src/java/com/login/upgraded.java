/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;

/**
 *
 * @author Joe
 */
public class upgraded {
    public static boolean checkUser(String email,String pass) 
    {
    
    boolean st =false;
        try {
            
             //pass="MD5("+pass+")";
            //loading drivers for mysql
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
                                Connection con=DriverManager.getConnection("jdbc:sqlserver://cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com:1433;databaseName=cjdb;user=admin;password=Junkies489!;");
            
            PreparedStatement ps = con.prepareStatement("select * from customerinfo where email=? and pass=? and role=26");
            ps.setString(1, email);
            ps.setString(2, pass);
            ResultSet rs =ps.executeQuery();
            st = rs.next();
            
            
            //store this name in the current session
            //HttpSession session = request.getSession()
            //session.setAttribute("uName", "ChaitanyaSingh");
            
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        
        
        
        return st;                 
    }
}
