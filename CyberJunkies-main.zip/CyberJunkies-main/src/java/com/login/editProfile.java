/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

/**
 *
 * @author Joe
 */
public class editProfile extends HttpServlet {

  

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    response.setContentType("text/html;charset-UTF-8");
                          int theId=0;
                          HttpSession session = request.getSession(false);
                          String NameOnScreen=(String)(session.getAttribute("username"));
                          try {
                                
                                String sqlID = "SELECT * FROM customerinfo WHERE email='"+NameOnScreen+"'";
                                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
                                Connection conID=DriverManager.getConnection("jdbc:sqlserver://cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com:1433;databaseName=cjdb;user=admin;password=Junkies489!;");
                                
                                Statement stmtID=conID.createStatement();
                                
                                ResultSet rsID = stmtID.executeQuery(sqlID);
                                 while(rsID.next()){ 
                                     theId=rsID.getInt("id");
                                 }
                          }catch(Exception e){
                              
                          }    
    
    
    
    
    
    
    
    try {                   
                                
                                //String sql = "SELECT first FROM employees;";
                                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
                                Connection con=DriverManager.getConnection("jdbc:sqlserver://cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com:1433;databaseName=cjdb;user=admin;password=Junkies489!;");
                                
                                
                                //int id= Integer.parseInt(request.getParameter("theId"));
                                String first = request.getParameter("first");
                                String last = request.getParameter("last");
                                String street = request.getParameter("street");
                                String city= request.getParameter("city");
                                String state = request.getParameter("state");
                                String zip = request.getParameter("zip");
                                String pass = request.getParameter("pass");
                                String email = request.getParameter("uname");
                                
                                PreparedStatement stmt = con.prepareStatement("UPDATE customerinfo SET first = ?, last = ?, street = ?, city = ?, state = ?, zip = ?, pass = ?, email = ? WHERE id = ?");
                                stmt.setString(1,first);
                                stmt.setString(2,last);
                                stmt.setString(3,street);
                                stmt.setString(4,city);
                                stmt.setString(5,state);
                                stmt.setString(6,zip);
                                stmt.setString(7,pass);
                                stmt.setString(8,email);
                                stmt.setInt(9,theId);
                               
                                //stmt = con.createStatement();
                                //String insert = "UPDATE customerinfo SET first='"+first+"', last='"+last+"',street='"+street+"',city='"+city+"',state='"+state+"',zip='"+zip+"',pass='"+pass+"',email='"+email+"' WHERE id=;";
                                //update employee set name='"+name+"',address='"+address+"',contactNo="+contact+",email='"+email+"' where id='"+num+"'"
                                stmt.executeUpdate();
                                //'"+3+"',
                                PrintWriter writer = response.getWriter();
                                writer.println("You have successfully updated your account!");
                                writer.println("You are being redirect back to the browse page.");
                           
                                
                                
                                
                                response.setHeader("Refresh", "1; URL=./UserAccess/memberSearch.jsp");
                                
                            }catch(Exception ex){
                                    ex.printStackTrace();
                                    response.sendRedirect("somethingWeird.jsp");
                                    response.setHeader("Refresh", "1; URL=./UserAccess/memberSearch.jsp");
                            }               
                              //response.setHeader("Refresh", "2; URL=login.jsp");
    }

   
    

}
