/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.PrintWriter;  
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Joe
 */
public class logout extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                
                response.setContentType("text/html");
                HttpSession session = request.getSession();
		session.invalidate();
                //System.out.print("You are successfully logged out!");  
                PrintWriter writer = response.getWriter();
                writer.println("You are successfully logged out!");
                writer.println("You are being redirect to the login page.");
                //order the client to clean their cache to kill the session with out memory
                //response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                
                response.setHeader("Refresh", "2; URL=login.jsp");
                //response.sendRedirect("login.jsp");
    }

}
