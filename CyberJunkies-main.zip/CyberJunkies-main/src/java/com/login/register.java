/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.*;

/**
 *
 * @author Joe
 */
public class register extends HttpServlet {

    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset-UTF-8");
        try {
                                
                                //String sql = "SELECT first FROM employees;";
                                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
                                Connection con=DriverManager.getConnection("jdbc:sqlserver://cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com:1433;databaseName=cjdb;user=admin;password=Junkies489!;");
                                
                                
                                
                                String first = request.getParameter("first");
                                String last = request.getParameter("last");
                                String street = request.getParameter("street");
                                String city= request.getParameter("city");
                                String state = request.getParameter("state");
                                String zip = request.getParameter("zip");
                                String pass = request.getParameter("psw");
                                String email = request.getParameter("email");
                                
                                //pass="SHA("+pass+")";
                                /*
                                File file = new File("write.txt");

                                try (Writer writer = new BufferedWriter(new FileWriter(file))) {
                                                  String contents = "The quick brown fox" + 
                                                System.getProperty("line.separator") + "jumps over the lazy dog.";

                                                      writer.write(contents);
                                                      
                                                     } catch (IOException e) {
                                                  e.printStackTrace();
                                                 } 
                               /////////////////
                                */
                                Statement stmt = con.createStatement();
                                String insert = "INSERT INTO customerinfo (first,last,street,city,state,zip,pass,email) VALUES ('"+first+"', '"+last+"', '"+street+"', '"+city+"', '"+state+"', '"+zip+"', '"+pass+"', '"+email+"' );";
                                
                                stmt.execute(insert);
                                //'"+3+"',
                                PrintWriter writer = response.getWriter();
                                writer.println("You have successfully created an account!");
                                writer.println("You are being redirect to the login page.");
                                //legit reason for multiple visits to site so thus we will reset the session for them
                                
                                ///////////////////////////////////////////////////////
                               
                                                
                                            
                                             
                      
                                /////////////////////////////////////////////
                                
                                
                                
                                
                                
                                HttpSession session = request.getSession();
                                            session.invalidate();
                                response.setHeader("Refresh", "2; URL=login.jsp");
                                
                            }catch(Exception ex){
                                    ex.printStackTrace();
                                    response.sendRedirect("somethingWeird.jsp");
                            }               
                              //response.setHeader("Refresh", "2; URL=login.jsp");
    }

    
    

}
