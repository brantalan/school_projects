/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.*;
import java.util.ArrayList;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author Joe
 */
public class CartFetch extends HttpServlet {

        Cart box = new Cart();
        ArrayList<Integer> contents = new ArrayList<Integer>();
        int counter=0; 
        
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       response.setContentType("text/html;charset-UTF-8");
       
       
        
     
       
       HttpSession session=request.getSession(); 
       PrintWriter writer = response.getWriter();
        
       
       int id = Integer.parseInt((request.getParameter("addToCart")));
       //String[] theCart = request.getParameterValues("addToCart");
       //theCart =request.getParameterValues("addToCart");
       
       box.add(id);
          
       counter=box.count();
       contents=box.contents();
       //session.setAttribute("box", box);
       request.getSession().setAttribute("counter",counter);
       request.getSession().setAttribute("theCurrentCart",contents); 
       
       //int id = Integer.parseInt(request.getParameter("thenumber"));
       writer.println("<tr>ID#</tr>");
       for(int i =0;i<contents.size();i++){
       //PrintWriter writer = response.getWriter();
                
                writer.println("<br>"+contents.get(i));
                
                
                //writer.println("there are "+counter+" items in your cart.");
                response.setHeader("Refresh", "2; URL=UserAccess/memberSearch.jsp");
             
       }

       writer.println("there are "+counter+" items in your cart.");
       //request.getRequestDispatcher("/getCart").forward(request, response);
       //RequestDispatcher rd = request.getRequestDispatcher("getCart");
       //rd.forward(request,response);
       
       
    }

    
    

}
