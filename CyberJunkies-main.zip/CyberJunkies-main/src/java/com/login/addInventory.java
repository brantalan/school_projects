/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author Joe
 */
public class addInventory extends HttpServlet {

   
 
    
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset-UTF-8");
        try {
                                
                                //String sql = "SELECT first FROM employees;";
                                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
                                Connection con=DriverManager.getConnection("jdbc:sqlserver://cyberjunkiesdb.ci0smtmmlqnc.us-east-1.rds.amazonaws.com:1433;databaseName=cjdb;user=admin;password=Junkies489!;");
                                
                                
                                
                                String make = request.getParameter("make");
                                String model = request.getParameter("model");
                                String year = request.getParameter("year");
                                String part= request.getParameter("part");
                                String qty = request.getParameter("qty");
                                String price = request.getParameter("price");
                                String location = request.getParameter("location");
                                
                                
                                
                                
                                Statement stmt = con.createStatement();
                                String insert = "INSERT INTO inventory (make,model,year,part,quantity,price,location) VALUES ('"+make+"', '"+model+"', '"+year+"', '"+part+"', '"+qty+"', '"+price+"', '"+location+"' );";
                                
                                stmt.execute(insert);
                                //'"+3+"',
                                PrintWriter writer = response.getWriter();
                                writer.println("You have successfully added to the inventory!");
                                
                                                   
                                
                                
                                
                                response.setHeader("Refresh", "2; URL=commandCenter/commandSearch.jsp");
                                
                            }catch(Exception ex){
                                    ex.printStackTrace();
                                    response.sendRedirect("somethingWeird.jsp");
                            }               
                             // response.setHeader("Refresh", "2; URL=/commandCenter/addparts.html");
    }

    
    


    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    

}
