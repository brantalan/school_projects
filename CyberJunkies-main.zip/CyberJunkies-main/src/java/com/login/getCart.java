/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Joe
 */
public class getCart extends HttpServlet {

    

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        
        HttpSession session=request.getSession(false); 
        PrintWriter writer = response.getWriter();
        
        String name = (String)(session.getAttribute("username"));
         
        ArrayList<Integer> contents = (ArrayList<Integer>)request.getAttribute("theCurrentCart");
        writer.println(contents.get(0));
       /*
        for(int i=0;i<contents.size();i++)
    {
        writer.print("Id: " + contents.get(i));
        
    }
       */
       
//response.sendRedirect("../theCart");

writer.println("Hello "+name+" getCart servlet successfully called");

    }

    
    

}
