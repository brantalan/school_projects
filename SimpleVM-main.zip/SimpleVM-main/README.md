# SimpleVM
This was the first lab required for my COMP-311 class at Franklin University.

The idea behind the program is to be able to parse something like: x = 5 + 7;
And output into a list VM instructions list such as this:

  push 5
  
  push 7
  
  add
  
  pop x

