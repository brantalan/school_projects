import java.util.Stack;
/**
 * PopOperation pops the first number off the stack
 * and stores its value in the symbol table under the 
 * given name
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class PopOperation implements Operation {
    private String name;
    /**
     * PopOperation constructor
     * @param name the name for the variable to store the number
     */
    public PopOperation(String name) {
        this.name = name;
    }
    /**
     * Executes the PopOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        symbolTable.setValue(name, stack.pop());
        return programCounter + 1;
    }

}
