import java.util.Stack;
/**
 * Subtracts the top two numbers on the stack
 * @author Brant Cummings
 * @version 06/3/2021
 *
 */
public class SubtractOperation implements Operation {
    /**
     * Executes the SubtractOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        int first = stack.pop();
        int total = stack.pop() - first;
        stack.push(total);

        return programCounter + 1;
    }

}
