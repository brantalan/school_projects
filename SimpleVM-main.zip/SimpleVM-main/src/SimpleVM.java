import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Creates a SimpleVM with the program contained
 * in the supplied BufferedReader.
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 *
 */
public class SimpleVM {

    private List<Operation> opList;
    private SymbolTable st;
    private Operation o;
    
    /**
     * SimpleVM constructor
     * @param reader list of operations to pass into the SimpleVM
     * to be parsed
     * @throws IOException
     */
    public SimpleVM(BufferedReader reader) throws IOException {
        final String blank = "";
        st = new SymbolTable();
        ArrayList<String> readerList = new ArrayList<String>();
        String r = reader.readLine();
        int currentLine = 0;
        while (r != null) {
            readerList.add(r);
            r = reader.readLine();
        }
        opList = new ArrayList<Operation>();
        for (String line : readerList) {
            // Convert the text program into a list of Operation objects

            if (line.matches("\\w+: .*")) {
                int labelSize = line.indexOf(":");
                String label = line.substring(0, labelSize);
                if (st.getLabel("label:" + label)) {
                    throw new RuntimeException("Duplicate Label");
                }
                st.setValue("label:" + label, currentLine);
                line = line.substring(labelSize + 1).trim();
            }
            if (line.startsWith("branchT")) {
                String label = line.replace("branchT", "").trim();
                st.checkLabelExists(readerList, label);
                o = new BranchTOperation(label);
                opList.add(o);
                line = blank;
            }
            if (line.startsWith("branchF")) {
                String label = line.replace("branchF", "").trim();
                st.checkLabelExists(readerList, label);
                o = new BranchFOperation(label);
                opList.add(o);
                line = blank;
            }
            if (line.startsWith("branch ")) {
                String label = line.replace("branch", "").trim();
                st.checkLabelExists(readerList, label);
                o = new BranchOperation(label);
                opList.add(o);
                line = blank;
            }
            if (line.startsWith("push")) {
                String variable = line.replace("push", "").trim();
                checkSyntax(variable);
                o = new PushOperation(variable);
                opList.add(o);
                line = blank;
            }
            if (line.startsWith("pop")) {
                String variable = line.replace("pop", "").trim();
                checkSyntax(variable);
                o = new PopOperation(variable);
                opList.add(o);
                line = blank;
            }
            if (line.equals("add")) {
                o = new AddOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("subtract")) {
                o = new SubtractOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("multiply")) {
                o = new MultiplyOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("divide")) {
                o = new DivideOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("compareEQ")) {
                o = new CompareEQOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("compareNEQ")) {
                o = new CompareNEQOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("compareLT")) {
                o = new CompareLTOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("compareLTE")) {
                o = new CompareLTEOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("compareGT")) {
                o = new CompareGTOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("compareGTE")) {
                o = new CompareGTEOperation();
                opList.add(o);
                line = blank;
            }
            if (line.equals("nop")) {
                o = new NoOperation();
                opList.add(o);
                line = blank;
            }
            if (!line.equals(blank)) {
                throw new RuntimeException("Bad Instruction");
            }
            currentLine++;
        }
    }
    /**
     * Runs the loaded program.
     */
    public void run() {
        Stack<Integer> stack = new Stack<Integer>();
        int programCounter = 0;

        while (programCounter != opList.size()) {
            o = opList.get(programCounter);
            programCounter = o.execute(programCounter, stack, st);
        }
    }

    /**
     * Returns the value of the given variable.
     * 
     * @param name the variable name
     * @return the value
     */
    public int getValue(String name) {
        return st.getValue(name);
    }
    /**
     * Returns the size of the list of operations.
     * 
     * @return the size
     */
    public int size() {
        return opList.size();
    }
    /**
     * Checks the syntax of the given line 
     * @param line the line to be evaluated
     * @return true if syntax is correct otherwise
     * throws RuntimeException
     */
    public boolean checkSyntax(String line) {
        if (line.matches("\\w+")) {
            return true;
        }
        throw new RuntimeException("Bad Syntax");
    }
}
