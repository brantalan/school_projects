import java.util.Stack;

/**
 * CompareGTEOperation compares the top two numbers in the stack and returns
 * true if the second number is greater or equal to the first number
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class CompareGTEOperation implements Operation {
    /**
     * executes the CompareGTEOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {

        int first = stack.pop();
        int second = stack.pop();
        if (second >= first) {
            stack.push(1);
        } 
        else {
            stack.push(0);
        }

        return programCounter + 1;
    }

}
