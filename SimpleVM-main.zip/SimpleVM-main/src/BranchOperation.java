import java.util.Stack;

/**
 * Operation for branching to given label
 * 
 * @author Brant Cummings
 * @version 06/2/2021
 */
public class BranchOperation implements Operation {
    private String label;
    
    /**
     * BranchOperation constructor
     * 
     * @param label passes label for branch path
     */
    public BranchOperation(String label) {
        this.label = label;
    }

    /**
     * executes the BranchOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        programCounter = symbolTable.getValue("label:" + label);
        return programCounter;
    }

}
