import java.util.Stack;

/**
 * Operation for adding top two numbers on stack
 * 
 * @author Brant Cummings
 * @version 06/2/2021
 */
public class AddOperation implements Operation {

    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        int first = stack.pop();
        int total = first + stack.pop();
        stack.push(total);

        return programCounter + 1;
    }

}
