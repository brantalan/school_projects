import java.util.Stack;

/**
 * Pops the top two numbers on the stack and divides them
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 *
 */
public class DivideOperation implements Operation {
    /**
     * Executes the DivideOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        int first = stack.pop();
        int total = stack.pop() / first;
        stack.push(total);

        return programCounter + 1;
    }

}
