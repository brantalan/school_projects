import java.util.Stack;

/**
 * Compares the top two numbers on the stack and pushes 1 on the stack if the
 * second number is less than the second otherwise pushes 0 onto the stack
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class CompareLTOperation implements Operation {
    /**
     * Executes the CompareLTOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {

        int first = stack.pop();
        int second = stack.pop();
        if (second < first) {
            stack.push(1);
        } 
        else {
            stack.push(0);
        }

        return programCounter + 1;
    }

}
