import java.io.BufferedReader;
import java.io.StringReader;
import junit.framework.TestCase;

/**
 * The test class for the SimpleVM
 * @author Brant Cummings
 * @version 06/3/2021
 *
 */
public class SimpleVMTest extends TestCase {
    
    /**
     * Tests pushing an a number to the stack and popping
     * it into a variable.
     * @throws Exception
     */
    public void testPushPop() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n" 
                + "pop x\n"));

        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(5, vm.getValue("x"));
    }
    /**
     * Tests the add operation
     * @throws Exception
     */
    public void testAdd() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 7\n"
                + "add\n"
                + "pop x\n"
                + "push x\n"
                + "push 3\n"
                + "add\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(12, vm.getValue("x"));
        assertEquals(15, vm.getValue("y"));
    }
    /**
     * Tests the subtraction operation
     * @throws Exception
     */
    public void testSub() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 20\n"
                + "push 5\n"
                + "subtract\n"
                + "pop x\n"
                + "push x\n"
                + "push 10\n"
                + "subtract\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(15, vm.getValue("x"));
        assertEquals(5, vm.getValue("y"));
    }
    /**
     * Tests the multiplication operation
     * @throws Exception
     */
    public void testMultiply() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 10\n"
                + "multiply\n"
                + "pop x\n"
                + "push x\n"
                + "push 2\n"
                + "multiply\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(50, vm.getValue("x"));
        assertEquals(100, vm.getValue("y"));
    }
    /**
     * Tests the divison operation
     * @throws Exception
     */
    public void testDivide() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 20\n"
                + "push 2\n"
                + "divide\n"
                + "pop x\n"
                + "push x\n"
                + "push 5\n"
                + "divide\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(10, vm.getValue("x"));
        assertEquals(2, vm.getValue("y"));
    }
    /**
     * Tests the compareEQ operation
     * @throws Exception
     */
    public void testCompareEQ() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 5\n"
                + "compareEQ\n"
                + "pop x\n"
                + "push 6\n"
                + "push 5\n"
                + "compareEQ\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(1, vm.getValue("x"));
        assertEquals(0, vm.getValue("y"));
    }
    /**
     * Tests the NEQoperation
     * @throws Exception
     */
    public void testCompareNEQ() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 5\n"
                + "compareNEQ\n"
                + "pop x\n"
                + "push 6\n"
                + "push 5\n"
                + "compareNEQ\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(0, vm.getValue("x"));
        assertEquals(1, vm.getValue("y"));
    }
    /**
     * Tests the LToperation
     * @throws Exception
     */
    public void testCompareLT() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 6\n"
                + "compareLT\n"
                + "pop x\n"
                + "push 6\n"
                + "push 5\n"
                + "compareLT\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(1, vm.getValue("x"));
        assertEquals(0, vm.getValue("y"));
    }
    /**
     * Tests the LTE Operation
     * @throws Exception
     */
    public void testCompareLTE() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 5\n"
                + "compareLTE\n"
                + "pop x\n"
                + "push 6\n"
                + "push 5\n"
                + "compareLTE\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(1, vm.getValue("x"));
        assertEquals(0, vm.getValue("y"));
    }
    /**
     * Tests the GToperation
     * @throws Exception
     */
    public void testCompareGT() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 6\n"
                + "compareGT\n"
                + "pop x\n"
                + "push 6\n"
                + "push 5\n"
                + "compareGT\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(0, vm.getValue("x"));
        assertEquals(1, vm.getValue("y"));
    }
    /**
     * Tests the CompareGTE operation
     * @throws Exception
     */
    public void testCompareGTE() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 5\n"
                + "compareGTE\n"
                + "pop x\n"
                + "push 5\n"
                + "push 6\n"
                + "compareGTE\n"
                + "pop y\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(1, vm.getValue("x"));
        assertEquals(0, vm.getValue("y"));
    }
    /**
     * Tests assigning a label
     * @throws Exception
     */
    public void testLabel() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "loop: push 20\n"
                + "push 2\n"
                + "add\n"
                + "pop x\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(4, vm.size());
    }
    /**
     * Tests for a duplicate label
     * @throws Exception
     */
    public void testDuplicateLabel() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "loop: push 20\n"
                + "loop: push 2\n"
                + "add\n"
                + "pop x\n"
                ));
        try {
            SimpleVM vm = new SimpleVM(reader);
            vm.run();
            fail();
        } 
        catch (RuntimeException ex) {
            assertEquals("Duplicate Label", ex.getMessage());
        }
    }
    /**
     * tests for missing label
     * @throws Exception
     */
    public void testMissingLabel() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 20\n"
                + "push 2\n"
                + "add\n"
                + "pop x\n"
                + "branch loop\n"
                ));
        try {
            SimpleVM vm = new SimpleVM(reader);
            vm.run();
            fail();
        } 
        catch (RuntimeException ex) {
            assertEquals("Missing Label", ex.getMessage());
        }
    }
    /**
     * Tests for bad syntax
     * @throws Exception
     */
    public void testBadSyntax() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 20\n"
                + "push\n"
                + "add\n"
                + "pop x\n"
                ));
        try {
            SimpleVM vm = new SimpleVM(reader);
            vm.run();
            
            fail();
        } 
        catch (RuntimeException ex) {
            assertEquals("Bad Syntax", ex.getMessage());
        }
    }
    /**
     * Tests for more bad syntax
     * @throws Exception
     */
    public void testBadSyntax2() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 20\n"
                + "pop\n"
                + "add\n"
                + "pop x\n"
                ));
        try {
            SimpleVM vm = new SimpleVM(reader);
            vm.run();
            
            fail();
        } 
        catch (RuntimeException ex) {
            assertEquals("Bad Syntax", ex.getMessage());
        }
    }
    /**
     * tests for bad instruction
     * @throws Exception
     */
    public void testBadInstruction() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "20\n"
                + "push 5\n"
                + "add\n"
                + "pop x\n"
                ));
        try {
            SimpleVM vm = new SimpleVM(reader);
            vm.run();
            
            fail();
        } 
        catch (RuntimeException ex) {
            assertEquals("Bad Instruction", ex.getMessage());
        }
    }
    /**
     * Tests branching forward
     * @throws Exception
     */
    public void testBranchForward() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 20\n"
                + "push 2\n"
                + "add\n"
                + "branch end\n"
                + "push 20\n"
                + "add\n"
                + "end: pop x\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(22, vm.getValue("x"));
    }
    /**
     * Tests attempting to branch out of bounds with
     * label and variable having same name
     * @throws Exception
     */
    public void testBranchOutofBounds() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 1\n"
                + "push 1000\n"
                + "pop end\n"
                + "branch end\n"
                + "push 20\n"
                + "add\n"
                + "end: pop x\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(1, vm.getValue("x"));
    }
    /**
     * tests branching with branchT operation
     * @throws Exception
     */
    public void testBranchT() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 5\n"
                + "push 1\n"
                + "branchT end\n"
                + "push 5\n"
                + "push 20\n"
                + "add\n"
                + "end: pop x\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(5, vm.getValue("x"));
    }

    public void testBranchF() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 0\n" +
                "pop x\n" +
                "push 0\n" +
                "pop y\n" +
                "push 0\n" +
                "pop z\n" +
                "while0: nop\n" +
                "push x\n" +
                "push 5\n" +
                "compareLT\n" +
                "branchF endwhile0\n" +
                "while1: nop\n" +
                "push y\n" +
                "push 5\n" +
                "compareLT\n" +
                "branchF endwhile1\n" +
                "push z\n" +
                "push 5\n" +
                "add\n" +
                "pop z\n" +
                "push x\n" +
                "push 1\n" +
                "add\n" +
                "pop x\n" +
                "push y\n" +
                "push 1\n" +
                "add\n" +
                "pop y\n" +
                "branch while1\n" +
                "endwhile1: nop\n" +
                "branch while0\n" +
                "endwhile0: nop\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(5, vm.getValue("y"));
    }
    /**
     * Tests branching backwards and forwards with
     * document based operation
     * @throws Exception
     */
    public void testBranchBackward() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(
                "push 0\n"
                + "pop sum\n"
                + "push 0\n"
                + "pop count\n"
                + "loop: push count\n"
                + "push 10\n"
                + "compareGT\n"
                + "branchT end\n"
                + "push sum\n"
                + "push count\n"
                + "add\n"
                + "pop sum\n"
                + "push count\n"
                + "push 1\n"
                + "add\n"
                + "pop count\n"
                + "branch loop\n"
                + "end: nop\n"
                ));
        
        SimpleVM vm = new SimpleVM(reader);
        vm.run();
        assertEquals(11, vm.getValue("count"));
    }
    /**
     * Tests the SymbolTable assignments
     * @throws Exception
     */
    public void testSymbolTable() throws Exception {
        SymbolTable st = new SymbolTable();
        String x = "x";
        String y = "y";

        st.setValue(x, 5);
        st.setValue(y, 7);
        assertEquals(5, st.getValue(x));
        assertEquals(7, st.getValue(y));
        
        st.setValue(x, 6);
        assertEquals(6, st.getValue(x));
        assertEquals(2, st.size());
        
    }
    /**
     * tests for checking if symbol exists when none do
     * @throws Exception
     */
    public void testExistingSymbol() throws Exception {
        try {
            SymbolTable st = new SymbolTable();
            String x = "x";
            st.getValue(x);
        } 
        catch (RuntimeException ex) {
            assertEquals("Variable Not Defined", ex.getMessage());
        }
    }
}
