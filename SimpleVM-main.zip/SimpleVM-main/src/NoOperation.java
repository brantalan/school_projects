import java.util.Stack;

/**
 * Just an operation that doesn't do anything for branching purposes
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 *
 */
public class NoOperation implements Operation {
    /**
     * Executes the NoOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        // No Operation - do nothing
        return programCounter + 1;
    }

}
