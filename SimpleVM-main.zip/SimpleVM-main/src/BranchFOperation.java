import java.util.Stack;

/**
 * Operation for branching to given label if top of stack is 1
 * 
 * @author Brant Cummings
 * @version 06/2/2021
 */
public class BranchFOperation implements Operation {
    private String label;
    /**
     * BranchTOperation constructor
     * @param label the label for passing the branch path
     */
    public BranchFOperation(String label) {
        this.label = label;
    }
    /**
     * executes the BranchTOperation if top of stack is 0
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {

        if (stack.pop() == 0) {
            programCounter = symbolTable.getValue("label:" + label);
            return programCounter;
        }
        return programCounter + 1;
    }

}
