import java.util.Stack;
/**
 * Pops the top two numbers on the stack and multiplies them
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 *
 */
public class MultiplyOperation implements Operation {
    /**
     * Executes the MultiplyOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        int first = stack.pop();
        int total = first * stack.pop();
        stack.push(total);

        return programCounter + 1;
    }

}
