import java.util.Stack;

/**
 * CompareEQOperation compares the top two numbers and and pushes 1 if they are
 * equal or 0 if they are not
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class CompareEQOperation implements Operation {
    /**
     * executes the CompareEQOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        int first = stack.pop();
        int second = stack.pop();
        if (first == second) {
            stack.push(1);
        } 
        else {
            stack.push(0);
        }
        return programCounter + 1;
    }

}
