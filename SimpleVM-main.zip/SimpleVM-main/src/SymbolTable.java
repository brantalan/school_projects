import java.util.ArrayList;
import java.util.HashMap;

/**
 * Manages the available variables.
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class SymbolTable {
    private HashMap<String, Integer> symbolHashMap;

    /**
     * Creates a SymbolTable.
     */
    public SymbolTable() {
        symbolHashMap = new HashMap<String, Integer>();
    }

    /**
     * Sets the value of the given variable.
     * 
     * @param name  the name
     * @param value the value
     */
    public void setValue(String name, int value) {
        if (symbolHashMap.containsKey(name)) {
            symbolHashMap.replace(name, value);
        } 
        else {
            symbolHashMap.put(name, value);
        }
    }

    /**
     * Returns the value of the given variable.
     * 
     * @param name the name
     * @return the value
     * @throws RuntimeException if the variable is not defined
     */
    public int getValue(String name) {
        if (symbolHashMap.containsKey(name)) {
            return symbolHashMap.get(name);
        }

        throw new RuntimeException("Variable Not Defined");
    }
    /**
     * Checks the SymbolTable for label
     * @param name the name of the given label
     * @return true if SymbolTable contains the label
     */
    public boolean getLabel(String name) {
        return symbolHashMap.containsKey(name);
    }
    /**
     * Checks the operation list for instances of the
     * label existing, IE at the end of the list.
     * @param list the list to check for the label
     * @param label the String to check for instances of
     * @return true if the label exists in the list
     * otherwise throws RuntimeException
     */
    public boolean checkLabelExists(ArrayList<String> list, String label) {
        for (String s : list) {
            if (s.startsWith(label + ": ")) {
                return true;
            }
        }
        throw new RuntimeException("Missing Label");
    }
    /**
     * the size of the SymbolTable
     * @return the size of the table
     */
    public int size() {
        return symbolHashMap.size();
    }
}
