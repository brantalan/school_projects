import java.util.Stack;

/**
 * Pushes number or variable onto the stack
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class PushOperation implements Operation {
    private int value;
    private String name;

    /**
     * PushOperation constructor
     * 
     * @param name the name of the variable to assign the number to be pushed
     *  onto the stack
     */
    public PushOperation(String name) {
        try {
            value = Integer.parseInt(name);
        } 
        catch (Exception e) {
            this.name = name;
        }
    }

    /**
     * Execute the PushOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {
        if (name != null) {
            value = symbolTable.getValue(name);
        }
        stack.push(value);
        return programCounter + 1;
    }

}
