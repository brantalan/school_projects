import java.util.Stack;

/**
 * Compares the top two numbers on the stack and pushes 1 onto the stack if 
 * they are not equal. Otherwise pushes 0 onto the stack.
 * 
 * @author Brant Cummings
 * @version 06/3/2021
 */
public class CompareNEQOperation implements Operation {
    /**
     * Executes the CompareNEQOperation
     */
    @Override
    public int execute(int programCounter, Stack<Integer> stack,
            SymbolTable symbolTable) {

        int first = stack.pop();
        int second = stack.pop();
        if (first == second) {
            stack.push(0);
        } 
        else {
            stack.push(1);
        }

        return programCounter + 1;
    }

}
