import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

/**
 * The Builder class.
 * 
 * @author Brant Cummings
 * @version 1
 */
public class Builder {
    private Map<String, String> fileList;
    private Graph graph;

    /**
     * Creates a Builder.
     * 
     * @param makefile the makefile
     * @throws ParseException
     * @throws UnknownTargetException
     * @throws CycleDetectedException
     */
    public Builder(StringBuffer makefile) throws ParseException,
            UnknownTargetException, CycleDetectedException {
        fileList = new HashMap<String, String>();
        graph = new Graph();

        String[] strArr = makefile.toString().split("\n");
        for (int i = 0; i < strArr.length; ++i) {
            parseFile(strArr[i]);
        }
        for (int i = 0; i < strArr.length; ++i) {
            parseNeighbors(strArr[i]);
        }
    }

    /**
     * Figures out how to make the given target.
     * 
     * @param targetName the target
     * @return the list of required steps
     */
    public ArrayList<String> makeTarget(String targetName)
            throws CycleDetectedException {
        if (hasCycle(graph.getVertex(targetName))) {
            throw new CycleDetectedException();
        }
        resetVisited();
        return topologicalSort(targetName);
    }

    /**
     * Parse the strings from makefile, and add them to the list of files
     * and the graph
     * 
     * @param fileStr the string to parse
     * @throws ParseException exception if there are issues
     */
    public void parseFile(String fileStr) throws ParseException {
        String[] str = fileStr.split(":");
        if (str.length != 3) {
            throw new ParseException("Invalid Formatting");
        }
        String name = str[0];
        String command = str[2];
        if (fileList.get(name) != null) {
            throw new ParseException("Duplicate Target");
        }
        fileList.put(name, command);
        Vertex v = new Vertex(name);
        graph.addVertex(v);
    }

    /**
     * Parse the strings from makefile and add graph edges for neighbors
     * 
     * @param fileStr the string to parse
     * @throws UnknownTargetException
     */
    public void parseNeighbors(String fileStr)
            throws UnknownTargetException {
        String[] str = fileStr.split(":");
        String fileName = str[0];
        Vertex vertex = graph.getVertex(fileName);
        String[] neighbors = str[1].split(" ");

        for (int i = 0; i < neighbors.length; ++i) {
            if (neighbors[i].trim().equals("")) {
                return;
            }
            else if (fileList.containsKey(neighbors[i])) {
                graph.addEdge(vertex, graph.getVertex(neighbors[i]));
            }

            else {
                throw new UnknownTargetException("Unknown Target");
            }
        }
    }

    /**
     * Check if the graph has a cycle in it from the given vertex
     * SOURCE: https://www.baeldung.com/java-graph-has-a-cycle
     * From this source I found a decent method to check a graph for a
     * cycle.
     * It does it by doing the following: Sets initial vertex is Visiting
     * to true,
     * for each adjacent vertex it then checks if they are currently being
     * visited.
     * If not then it checks recursively on the adjacent vertices of all
     * adjacent vertices.
     * Then it marks the vertex visiting as false and visited as true
     * 
     * @param vertex the source vertex to check for a cycle
     * @return true if a cycle exists
     */
    public boolean hasCycle(Vertex vertex) {
        vertex.setVisiting(true);
        for (Vertex neighbor : vertex.getAdjacencyList()) {
            if (neighbor.isVisiting()) {
                return true;
            }
            else if (hasCycle(neighbor)) {
                return true;
            }
        }
        vertex.setVisiting(false);
        vertex.setVisited(true);
        return false;
    }

    /**
     * Reset visited state on vertices
     */
    public void resetVisited() {
        for (String s : fileList.keySet()) {
            graph.getVertex(s).setVisited(false);
            graph.getVertex(s).setVisiting(false);
        }
    }

    /**
     * Sort the graph vertices in topological order to a given vertex.
     * SOURCE for inspiration:
     * https://www.baeldung.com/java-depth-first-search
     * 
     * @param vertex the vertex to build a list off of
     * @return list of sorted vertices and their command
     */
    public ArrayList<String> topologicalSort(String vertex) {
        LinkedList<String> result = new LinkedList<String>();
        Set<String> visited = new LinkedHashSet<String>();
        topologicalSortRecursive(graph.getVertex(vertex), visited, result);
        return new ArrayList<String>(result);
    }

    /**
     * Helper method for topological sort
     * 
     * @param current the current vertex to check
     * @param isVisited a list of visited vertices
     * @param result the sorted list
     */
    private void topologicalSortRecursive(Vertex current,
            Set<String> isVisited, LinkedList<String> result) {
        current.setVisited(true);
        for (Vertex dest : current.getAdjacencyList()) {
            if (!dest.isVisited()) {
                topologicalSortRecursive(dest, isVisited, result);
            }
        }
        result.addLast(fileList.get(current.getName()));
    }
}
