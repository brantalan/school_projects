import java.util.HashMap;
import java.util.Map;
/**
 * Graph class
 * @author brant
 * @version 1.0
 */
public class Graph {
    private Map<String, Vertex> vertices;
    /**
     * Graph constructor
     */
    public Graph() {
        this.vertices = new HashMap<String, Vertex>();
    }
    /**
     * Add vertex to graph
     * @param v vertex to add to graph
     */
    void addVertex(Vertex v) {
        this.vertices.put(v.getName(), v);
    }
    /**
     * Edge to add to graph
     * @param v1 the vertex to be given an adjacent vertex
     * @param v2 the adjacent vertex
     */
    void addEdge(Vertex v1, Vertex v2) {
        v1.addNeighbor(v2);
    }
    /**
     * Get vertex that exists in graph
     * @param name the name of the vertex to find
     * @return the vertex if exists, else return null
     */
    public Vertex getVertex(String name) {
        return vertices.get(name);
    }
}