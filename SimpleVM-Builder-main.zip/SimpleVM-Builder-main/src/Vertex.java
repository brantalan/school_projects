import java.util.ArrayList;
import java.util.List;

/**
 * Vertex class
 * @author brant
 * @version 1.0
 */
public class Vertex {
    private String name;
    private boolean visiting;
    private boolean visited;
    private List<Vertex> adjacencyList;
    
    /**
     * Vertex constructor
     * @param name the name of the vertex
     */
    public Vertex(String name) {
        this.name = name;
        this.adjacencyList = new ArrayList<Vertex>();
    }
    /**
     * Getter for name
     * @return vertex name
     */
    public String getName() {
        return this.name;
    }
    /**
     * getter for is visiting boolean
     * @return true if visiting
     */
    public boolean isVisiting() {
        return this.visiting;
    }
    /**
     * setter for visiting
     * @param v boolean value to set 
     */
    public void setVisiting(boolean v) {
        this.visiting = v;
    }
    /**
     * getter for is visited boolean
     * @return true if has been visited
     */
    public boolean isVisited() {
        return this.visited;
    }
    /**
     * setter for is visited boolean
     * @param v boolean value to set for visited value
     */
    public void setVisited(boolean v) {
        this.visited = v;
    }
    /**
     * Add neighbor vertex to adjacent vertex list
     * @param adj vertex to add to the list
     */
    public void addNeighbor(Vertex adj) {
        this.adjacencyList.add(adj);
    }
    /**
     * getter for adjacency list
     * @return the adjacency list
     */
    List<Vertex> getAdjacencyList() {
        return this.adjacencyList;
    }
}
