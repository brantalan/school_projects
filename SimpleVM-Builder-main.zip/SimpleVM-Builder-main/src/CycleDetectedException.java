/**
 * Thrown when cycles are detected.
 *
 * @author TKington
 * @version Mar 20, 2007
 */
public class CycleDetectedException extends Exception
{
    private static final long serialVersionUID = 1L;

}
