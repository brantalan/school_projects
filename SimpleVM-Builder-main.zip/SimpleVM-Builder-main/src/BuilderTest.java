import java.util.ArrayList;

import junit.framework.TestCase;

/**
 * Test class for Builder class
 * 
 * @author brant
 * @version 1.0
 */
public class BuilderTest extends TestCase {
    /**
     * Test Builder
     * 
     * @throws ParseException
     * @throws UnknownTargetException
     * @throws CycleDetectedException
     */
    public void testBuilder() throws ParseException,
            UnknownTargetException, CycleDetectedException {
        ArrayList<String> targetList = new ArrayList<String>();
        targetList.add("Edit Class1.java");
        targetList.add("javac Class1.java");
        targetList.add("Edit Class2.java");
        targetList.add("javac Class2.java");
        targetList.add("jar cvf *.class");

        StringBuffer bfr = new StringBuffer();
        bfr.append("MyApp.jar:Class1.class Class2.class:jar cvf *.class\n"
                + "Class2.java::Edit Class2.java\n"
                + "Class2.class:Class2.java:javac Class2.java\n"
                + "Class1.java::Edit Class1.java\n"
                + "Class1.class:Class1.java:javac Class1.java\n");
        Builder bldr = new Builder(bfr);
        ArrayList<String> list = bldr.makeTarget("MyApp.jar");
        assertEquals(targetList, list);
    }

    /**
     * test unknown target exception
     * 
     * @throws ParseException
     * @throws UnknownTargetException
     * @throws CycleDetectedException
     */
    public void testUnknownTarget() throws ParseException,
            UnknownTargetException, CycleDetectedException {
        StringBuffer bfr = new StringBuffer();
        bfr.append("MyApp.jar:Class1.class Class2.class:jar cvf *.class\n"
                + "Class2.java::Edit Class2.java\n"
                + "Class2.class:Class3.java:javac Class2.java\n"
                + "Class1.java::Edit Class1.java\n"
                + "Class1.class:Class1.java:javac Class1.java\n");
        try {
            @SuppressWarnings("unused")
            Builder bldr = new Builder(bfr);
            fail();
        }
        catch (UnknownTargetException e) {
            assertEquals("Unknown Target", e.getMessage());
        }
    }

    /**
     * Test for cycle detection exception
     * 
     * @throws ParseException
     * @throws UnknownTargetException
     * @throws CycleDetectedException
     */
    public void testCycleDetection() throws ParseException,
            UnknownTargetException, CycleDetectedException {
        StringBuffer bfr = new StringBuffer();
        bfr.append("Class1.java:MyApp.jar:Edit Class1.java\r\n"
                + "Class1.class:Class1.java:javac Class1.java\r\n"
                + "Class2.java::Edit Class2.java\r\n"
                + "Class2.class:Class2.java:javac Class2.java\r\n"
                + "MyApp.jar:Class1.class Class2.class:jar cvf *.class\r\n");
        Builder bldr = new Builder(bfr);
        try {
            bldr.makeTarget("MyApp.jar");
            fail();
        }
        catch (CycleDetectedException e) {
            assertEquals(null, e.getMessage());
        }
    }

    /**
     * Test for parse exception
     * 
     * @throws ParseException
     * @throws UnknownTargetException
     * @throws CycleDetectedException
     */
    public void testParseException() throws ParseException,
            UnknownTargetException, CycleDetectedException {
        StringBuffer bfr = new StringBuffer();
        bfr.append("MyApp.jar:Class1.class Class2.class:jar cvf *.class\n"
                + "Class2.java::Edit Class2.java:foo\n"
                + "Class2.class:Class3.java:javac Class2.java\n"
                + "Class1.java::Edit Class1.java\n"
                + "Class1.class:Class1.java:javac Class1.java\n");
        try {
            @SuppressWarnings("unused")
            Builder bldr = new Builder(bfr);
            fail();
        }
        catch (ParseException e) {
            assertEquals("Invalid Formatting", e.getMessage());
        }
    }

    /**
     * Test for duplicate targets
     * 
     * @throws ParseException
     * @throws UnknownTargetException
     * @throws CycleDetectedException
     */
    public void testDuplicateTarget() throws ParseException,
            UnknownTargetException, CycleDetectedException {
        StringBuffer bfr = new StringBuffer();
        bfr.append("MyApp.jar:Class1.class Class2.class:jar cvf *.class\n"
                + "Class1.java::Edit Class1.java\n"
                + "Class2.class:Class2.java:javac Class2.java\n"
                + "Class1.java::Edit Class1.java\n"
                + "Class1.class:Class1.java:javac Class1.java\n");
        try {
            @SuppressWarnings("unused")
            Builder bldr = new Builder(bfr);
            fail();
        }
        catch (ParseException e) {
            assertEquals("Duplicate Target", e.getMessage());
        }
    }
}
