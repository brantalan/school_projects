import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import junit.framework.TestCase;

/**
 * CuckooHashMap Test Cases
 * 
 * @author Brant Cummings
 * @version 1.0
 *
 */
public class CuckooHashMapTest extends TestCase {
    /**
     * Test Various Inserts into different CuckooHashMaps
     */
    public void testInsert() {
        CuckooHashMap<Integer, Integer> cons =
                new CuckooHashMap<Integer, Integer>(10);
        assertEquals(0, cons.size());
        assertEquals(true, cons.isEmpty());
        cons.put(1, 2);
        assertEquals(false, cons.isEmpty());

        CuckooHashMap<Integer, Integer> rehash =
                new CuckooHashMap<Integer, Integer>(10);
        rehash.rehash();

        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        assertSame(true, cuckoo.isEmpty());
        assertEquals(2, cuckoo.h1("one"));
        assertEquals(6, cuckoo.h1("two"));
        assertEquals(6, cuckoo.h1("three"));
        assertEquals(null, cuckoo.put("one", 1));
        assertSame(false, cuckoo.isEmpty());
        assertEquals(1, cuckoo.size());
        CuckooHashMap<String, Integer>.MapEntry entry = cuckoo.getEntry(2);
        assertSame(entry, cuckoo.getEntry(2));
        assertEquals(null, cuckoo.put("two", 2));
        assertEquals(2, cuckoo.size());
        entry = cuckoo.getEntry(6);
        assertEquals(entry, cuckoo.getEntry(6));
        assertSame(null, cuckoo.put("three", 3));
        assertEquals(3, cuckoo.size());
        
        // new test
        cuckoo = new CuckooHashMap<String, Integer>(10);
        assertEquals(4, cuckoo.h1("four"));
        assertEquals(0, cuckoo.h1("six"));
        assertEquals(5, cuckoo.h1("seven"));
        
        assertEquals(null, cuckoo.put("one", 1));
        entry = cuckoo.getEntry(2);
        assertSame(entry, cuckoo.getEntry(2));
        assertEquals(null, cuckoo.put("two", 2));
        assertEquals(null, cuckoo.put("four", 4));
        assertEquals(null, cuckoo.put("six", 6));
        assertEquals(null, cuckoo.put("seven", 7));
        entry = cuckoo.getEntry(6);
        assertEquals(entry, cuckoo.getEntry(6));
        assertSame(null, cuckoo.put("three", 3));
        assertEquals(null, cuckoo.put("five", 5));
        assertEquals(7, cuckoo.size());
        assertSame(2, cuckoo.getEntry(16).getValue());
        assertSame(3, cuckoo.getEntry(6).getValue());
        assertSame(5, cuckoo.getEntry(9).getValue());

        int test = entry.setValue(2);
        assertEquals(2, test);

        // insert nulls
        CuckooHashMap<String, String> nullMap =
                new CuckooHashMap<String, String>(10);
        assertEquals(null, nullMap.put(null, null));

    }

    /**
     * test for same key insert
     */
    public void testSamePut() {
        // new test
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        assertEquals(0, cuckoo.size());
        assertSame(null, cuckoo.put("two", 2));
        assertSame(2, cuckoo.put("two", 2));
        assertSame(null, cuckoo.put("three", 3));
        assertSame(2, cuckoo.put("two", 20));
        assertSame(20, cuckoo.put("two", 20));
        assertSame(20, cuckoo.remove("two"));
        //assertSame(null, cuckoo.getEntry(6));
        assertSame(null, cuckoo.put("two", 2));
        assertSame(2, cuckoo.size());
    }

    /**
     * test get methods and contains methods
     */
    public void testGetandContains() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        cuckoo.put("one", 1);
        assertSame(1, cuckoo.get("one"));
        assertEquals(true, cuckoo.containsKey("one"));
        assertEquals(null, cuckoo.get("two"));
        assertEquals(false, cuckoo.containsKey("two"));
        assertEquals(true, cuckoo.containsValue(1));
        assertEquals(false, cuckoo.containsValue(2));
    }

    /**
     * test removing entries from hashmap
     */
    public void testRemove() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        assertEquals(0, cuckoo.size());
        assertEquals(null, cuckoo.remove("nothing"));
        assertEquals(0, cuckoo.size());
        cuckoo.put("one", 1);
        cuckoo.put("two", 2);
        assertSame(1, cuckoo.remove("one"));
        assertNull(cuckoo.getEntry(2));
        assertEquals(false, cuckoo.containsKey("one"));
        assertEquals(1, cuckoo.size());
    }

    /**
     * test clearing hashmap
     */
    public void testClear() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        cuckoo.put("one", 1);
        cuckoo.put("two", 2);
        assertEquals(2, cuckoo.size());
        cuckoo.clear();
        assertEquals(0, cuckoo.size());
        assertEquals(null, cuckoo.getEntry(2));
    }

    /**
     * test keyset
     */
    public void testKeySet() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        cuckoo.put("one", 1);
        cuckoo.put("two", 2);
        cuckoo.put("four", 4);
        assertEquals(3, cuckoo.size());
        Set<String> keys = cuckoo.keySet();
        assertEquals(true, keys.contains("one"));
        assertEquals(true, keys.contains("two"));
        assertEquals(true, keys.contains("four"));
        cuckoo.remove("one");
        assertEquals(false, cuckoo.containsKey("one"));
        assertEquals(false, keys.contains("one"));

        keys.clear();
        assertEquals(true, keys.isEmpty());

        try {
            cuckoo.keySet().add("one");
            fail("Missing exception");
        }
        catch (UnsupportedOperationException e) {
            assertEquals(null, e.getMessage());
        }
        try {
            cuckoo.keySet().remove("one");
            fail("Missing exception");
        }
        catch (UnsupportedOperationException ex) {
            assertEquals("Not Supported", ex.getMessage());
        }
    }

    /**
     * test values collection
     */
    public void testCollectionValues() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        cuckoo.put("one", 1);
        cuckoo.put("two", 2);
        cuckoo.put("four", 4);
        Collection<Integer> values = cuckoo.values();

        assertEquals(3, cuckoo.size());
        assertEquals(3, values.size());
        assertEquals(true, cuckoo.containsValue(1));
        assertEquals(true, cuckoo.containsValue(2));
        assertEquals(true, cuckoo.containsValue(4));
        assertEquals(true, values.contains(1));
        assertEquals(true, values.contains(2));
        assertEquals(true, values.contains(4));
        cuckoo.remove("one");

        assertEquals(false, cuckoo.containsValue(1));
        assertEquals(false, values.contains(1));
        assertEquals(true, values.contains(2));
        cuckoo.values().clear();
        assertEquals(true, values.isEmpty());
        try {
            cuckoo.values().add(1);
            fail("Missing exception");
        }
        catch (UnsupportedOperationException e) {
            assertEquals(null, e.getMessage());
        }
        try {
            cuckoo.values().remove(4);
            fail("Missing exception");
        }
        catch (UnsupportedOperationException ex) {
            assertEquals("Not Supported", ex.getMessage());
        }
    }

    /**
     * test entry set
     */
    public void testEntrySet() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        CuckooHashMap<String, Integer> cucktwo =
                new CuckooHashMap<String, Integer>(10);
        cuckoo.put("one", 1);
        cuckoo.put("two", 2);
        cuckoo.put("four", 4);
        cuckoo.put("six", 6);
        cucktwo.put("three", 3);
        Set<Map.Entry<String, Integer>> es;
        es = cuckoo.entrySet();

        CuckooHashMap<String, Integer>.MapEntry e;
        e = cuckoo.getEntry(2);
        CuckooHashMap<String, Integer>.MapEntry g = cucktwo.getEntry(6);
        assertEquals(e, cuckoo.getEntry(2));
        assertEquals(true, es.contains(e));
        assertEquals(false, es.contains(null));
        assertEquals(false, es.contains(g));
        cuckoo.remove("one");

        cuckoo.put("seven", 7);
        e = cuckoo.getEntry(5);
        assertEquals(true, es.contains(e));
        assertEquals(4, cuckoo.size());
        assertEquals(4, es.size());
        cuckoo.remove("two");
        assertEquals(3, cuckoo.size());
        assertEquals(3, es.size());
        try {
            es.add(e);
            fail("Missing exception");
        }
        catch (UnsupportedOperationException ex) {
            assertEquals(null, ex.getMessage());
        }
        try {
            cuckoo.entrySet().remove(e);
            fail("Missing exception");
        }
        catch (UnsupportedOperationException ex) {
            assertEquals("Not Supported", ex.getMessage());
        }
        es.clear();
        assertEquals(true, es.isEmpty());
    }

    /**
     * test iterators
     */
    public void testIterators() {
        CuckooHashMap<String, Integer> cuckoo =
                new CuckooHashMap<String, Integer>(10);
        cuckoo.put("one", 1);
        cuckoo.put("two", 2);
        cuckoo.put("four", 4);

        assertEquals(3, cuckoo.keySet().size());
        Iterator<String> keyItr = cuckoo.keySet().iterator();

        while (keyItr.hasNext()) {
            keyItr.next();
        }
        Iterator<Integer> valueItr = cuckoo.values().iterator();
        while (valueItr.hasNext()) {
            valueItr.next();
        }
        Iterator<Map.Entry<String, Integer>> entryItr =
                cuckoo.entrySet().iterator();
        while (entryItr.hasNext()) {
            entryItr.next();
        }
        entryItr.hasNext();
        try {
            valueItr.next();
        }
        catch (NoSuchElementException ex) {
            assertEquals(null, ex.getMessage());
        }
        try {
            keyItr.next();
        }
        catch (NoSuchElementException ex) {
            assertEquals(null, ex.getMessage());
        }
        try {
            entryItr.next();
        }
        catch (NoSuchElementException ex) {
            assertEquals(null, ex.getMessage());
        }
        try {
            valueItr.remove();
        }
        catch (UnsupportedOperationException ex) {
            assertEquals("Not Supported", ex.getMessage());
        }
        try {
            keyItr.remove();
        }
        catch (UnsupportedOperationException ex) {
            assertEquals("Not Supported", ex.getMessage());
        }
        try {
            entryItr.remove();
        }
        catch (UnsupportedOperationException ex) {
            assertEquals("Not Supported", ex.getMessage());
        }

    }

    /**
     * test put all
     */
    public void testPutAll() {
        CuckooHashMap<String, Integer> map1 =
                new CuckooHashMap<String, Integer>(10);
        CuckooHashMap<String, Integer> map2 =
                new CuckooHashMap<String, Integer>(10);
        map1.put("one", 1);
        map1.put("two", 2);
        map2.put("four", 4);
        map2.put("six", 6);
        map1.putAll(map2);
        assertEquals(true, map1.containsKey("four"));
        assertEquals(4, map1.size());
    }
}
