import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

/**
 * HashMap implementing cuckoo hashing algorithms
 * 
 * @author Brant Cummings
 * @version 1.0
 *
 * @param <K> key for the map
 * @param <V> value for the map
 */
public class CuckooHashMap<K, V> implements Map<K, V> {
    private ArrayList<MapEntry> buckets;
    private int entries;
    private int size;

    /**
     * Create new CuckooHashMap
     * 
     * @param numBuckets the number of buckets to initialize in the map
     */
    public CuckooHashMap(int numBuckets) {
        this.size = numBuckets;
        buckets = new ArrayList<MapEntry>();
        for (int i = 0; i < numBuckets; ++i) {
            buckets.add(null);
        }
        entries = 0;
    }

    /**
     * Fill an arraylist with only the entries from the CuckooHashMap
     * 
     * @return the arrayList
     */
    public ArrayList<Map.Entry<K, V>> fill() {
        ArrayList<Map.Entry<K, V>> table =
                new ArrayList<Map.Entry<K, V>>();
        for (Map.Entry<K, V> e : buckets) {
            if (e != null) {
                table.add(e);
            }
        }
        return table;
    }

    @Override
    public void clear() {
        for (int i = 0; i < size; ++i) {
            buckets.set(i, null);
        }
        entries = 0;
    }

    @Override
    public boolean isEmpty() {
        return entries == 0;
    }

    /**
     * returns the number of entries in the map
     * 
     * @return the number of entries
     */
    public int size() {
        return entries;
    }

    @Override
    public V get(Object key) {
        for (MapEntry e : buckets) {
            if (e != null && e.key.equals(key)) {
                return e.value;
            }
        }
        return null;
    }

    /**
     * Get the entry stored at the given location
     * 
     * @param index the index to check
     * @return the MapEntry in said bucket
     */
    public MapEntry getEntry(int index) {
        return buckets.get(index);
    }

    @Override
    public boolean containsKey(Object key) {
        for (MapEntry e : buckets) {
            if (e != null && e.key.equals(key)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean containsValue(Object value) {
        for (MapEntry e : buckets) {
            if (e != null && e.value == value) {
                return true;
            }
        }
        return false;
    }

    /**
     * Put the given key and value into the CuckooHashMap
     * return
     * 
     * @param key the key for the map entry
     * @param value the value of the map entry
     * @return the previous entry at location new map
     * entry is placed into or null if it was empty
     */
    public V put(K key, V value) {
        MapEntry entry = new MapEntry(key, value);
        MapEntry temp = new MapEntry(null, null);
        if (key == null) {
            return null;
        }
        int hash1 = h1(key);
        int hash2 = h2(key);
        if (this.containsKey(key)) {
            MapEntry slot1 = buckets.get(hash1);
            MapEntry slot2 = buckets.get(hash2);
            if (slot1.key.equals(entry.key)) {
                buckets.set(hash1, entry);
                return slot1.value;
            }
            else {
                buckets.set(hash2, entry);
                return slot2.value;
            }
        }
        int pos = hash1;
        for (int i = 0; i < buckets.size(); ++i) {
            if (buckets.get(pos) == null) {
                buckets.set(pos, entry);
                ++entries;
                return null;
            }
            temp = buckets.get(pos);
            buckets.set(pos, entry);
            entry = temp;
            if (pos == h1(entry.key)) {
                pos = h2(entry.key);
            }
            else {
                pos = h1(entry.key);
            }
        }
        rehash();
        put(entry.key, entry.value);
        return null;
    }

    /**
     * Increase the number of buckets in the hashmap and replace all
     * entries
     */
    public void rehash() {
        entries = 0;
        ArrayList<MapEntry> oldBuckets = buckets;
        size = size * 2;
        buckets = new ArrayList<MapEntry>();
        for (int i = 0; i < size; ++i) {
            buckets.add(null);
        }
        for (MapEntry entry : oldBuckets) {
            if (entry != null) {
                put(entry.key, entry.value);
            }
        }
    }

    /**
     * Hash formula 1
     * 
     * @param key the key to create a hash value from
     * @return the hash value of the key
     */
    public int h1(K key) {
        return Math.abs(key.hashCode()) % size;
    }

    /**
     * Hash formula 2
     * 
     * @param key the key to create a hash value from
     * @return the hash value of the key
     */
    public int h2(K key) {
        return (h1(key) + 3) % size;
    }

    /**
     * remove a map entry from the map
     * 
     * @param key the key to find an entry for
     * @return the value of key being removed
     */
    public V remove(Object key) {
        for (int i = 0; i < buckets.size(); ++i) {
            MapEntry e = buckets.get(i);
            if (e != null && e.key.equals(key)) {
                buckets.set(i, null);
                --entries;
                return e.value;
            }
        }
        return null;
    }

    /**
     * Puts all entries from the given map into the original map
     * 
     * @param map the map to copy
     */
    public void putAll(Map<? extends K, ? extends V> map) {
        for (Map.Entry<? extends K, ? extends V> e : map.entrySet()) {
            K key = e.getKey();
            V value = e.getValue();
            put(key, value);
        }
    }

    @Override
    public Set<java.util.Map.Entry<K, V>> entrySet() {
        return new EntrySet();
    }

    /**
     * A view of the maps keyset
     * This code is taken directly from the source of AbstractMap keySet()
     * @return the keyset view
     */
    public Set<K> keySet() {
        return new AbstractSet<K>() {
            public Iterator<K> iterator() {
                return new Iterator<K>() {
                    private Iterator<Entry<K, V>> i =
                            entrySet().iterator();

                    public boolean hasNext() {
                        return i.hasNext();
                    }

                    public K next() {
                        return i.next().getKey();
                    }

                    public void remove() {
                        throw new UnsupportedOperationException(
                                "Not Supported");
                    }
                };
            }

            public boolean remove(Object value) {
                throw new UnsupportedOperationException("Not Supported");
            }

            public int size() {
                return CuckooHashMap.this.size();
            }

            public boolean isEmpty() {
                return CuckooHashMap.this.isEmpty();
            }

            public void clear() {
                CuckooHashMap.this.clear();
            }

            public boolean contains(Object k) {
                return CuckooHashMap.this.containsKey(k);
            }
        };
    }

    /**
     * Collection of values in map
     * This code is sourced from Java's AbstractMap values()
     * @return the collection of values
     */
    public Collection<V> values() {
        return new AbstractCollection<V>() {
            public Iterator<V> iterator() {
                return new Iterator<V>() {
                    private Iterator<Entry<K, V>> i =
                            entrySet().iterator();

                    public boolean hasNext() {
                        return i.hasNext();
                    }

                    public V next() {
                        return i.next().getValue();
                    }

                    public void remove() {
                        throw new UnsupportedOperationException(
                                "Not Supported");
                    }
                };
            }

            public boolean remove(Object value) {
                throw new UnsupportedOperationException("Not Supported");
            }

            public int size() {
                return CuckooHashMap.this.size();
            }

            public boolean isEmpty() {
                return CuckooHashMap.this.isEmpty();
            }

            public void clear() {
                CuckooHashMap.this.clear();
            }

            public boolean contains(Object v) {
                return CuckooHashMap.this.containsValue(v);
            }
        };
    }

    /**
     * MapEntry class for storing the key and values in the Cuckoo Hash Map
     * 
     * @author Brant Cummings
     *
     */
    public class MapEntry implements Entry<K, V> {
        private K key;
        private V value;

        /**
         * Creates a MapEntry.
         * 
         * @param akey the key
         * @param avalue the value
         */
        public MapEntry(K akey, V avalue) {
            this.key = akey;
            this.value = avalue;
        }

        /**
         * Returns the key for this entry.
         * 
         * @see java.util.Map$Entry#getKey()
         * @return the key for this entry
         */
        @Override
        public K getKey() {
            return key;
        }

        /**
         * Returns the value for this entry.
         * 
         * @see java.util.Map$Entry#getValue()
         * @return the value for this entry
         */
        @Override
        public V getValue() {
            return value;
        }

        /**
         * Sets the value for this entry.
         * 
         * @see java.util.Map$Entry#setValue(V)
         * @param newValue the value to set
         * @return the previous value for this entry
         */
        public V setValue(V newValue) {
            V oldVal = value;
            value = newValue;
            return oldVal;
        }
    }

    /**
     * Entry Set of CuckooHashMap
     * 
     * @author brant
     *
     */
    public class EntrySet extends AbstractSet<Map.Entry<K, V>> {
        /**
         * Entry Set Size
         * 
         * @return the size of the entry set
         */
        public int size() {
            return CuckooHashMap.this.size();
        }

        /**
         * Clear the map
         */
        public void clear() {
            CuckooHashMap.this.clear();
        }

        /**
         * Iterator for EntrySet
         * 
         * @return the iterator
         */
        public Iterator<Map.Entry<K, V>> iterator() {
            return new EntryIterator();
        }

        /**
         * Check EntrySet for object
         * 
         * @param o the object the search for
         * @return true if contains else false
         */
        public boolean contains(Object o) {
            for (Object e : buckets) {
                if (e != null && e.equals(o)) {
                    return true;
                }
            }
            return false;
        }

        /**
         * Remove object from EntrySet
         * 
         * @param o the object to remove
         * @return throw UnsupportedOperationException
         */
        public boolean remove(Object o) {
            throw new UnsupportedOperationException("Not Supported");
        }
    }

    /**
     * Iterator class for the EntrySet
     * 
     * @author brant
     *
     */
    public class EntryIterator implements Iterator<Map.Entry<K, V>> {
        private int index;

        /**
         * Has Next function
         * 
         * @return true if iterator has more items
         */
        public boolean hasNext() {
            return index < entries;
        }

        /**
         * Next entry to return in entryset
         * 
         * @return next entry
         */
        public Map.Entry<K, V> next() {
            ArrayList<Entry<K, V>> t = fill();
            if (hasNext()) {
                return t.get(index++);
            }
            throw new NoSuchElementException();
        }

        /**
         * remove function
         * throws UnsupportedOperationException
         */
        public void remove() {
            throw new UnsupportedOperationException("Not Supported");
        }
    }
}
