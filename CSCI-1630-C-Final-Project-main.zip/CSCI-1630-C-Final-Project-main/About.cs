﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

        private void About_Load(object sender, EventArgs e)
        {
            AddText();
        }
        private void AddText()
        {
            string name = "Brant Cummings", date = "11/22/2019", version = "1.0", title = "Movie Manager Application", author = ("Author:\t\t"),
                theDate = ("\nDate:\t\t"), theVersion = ("\nVersion\t\t"), 
                body = ("\n\nThis application reads data from a Microsoft SQL Server database. " +
                "Further, it provides the typical CRUD operations: Create, Read, Update, and Delete against the Movies table "+
                "in our database.\n\n");
            aboutText.SelectionFont = new Font ("Tahoma", 16, FontStyle.Bold);
            aboutText.SelectionColor = Color.Red;
            aboutText.AppendText(title);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Regular);
            aboutText.SelectionColor = Color.Black;
            aboutText.AppendText(body);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Regular);
            aboutText.AppendText(author);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Bold);
            aboutText.AppendText(name);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Regular);
            aboutText.AppendText(theDate);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Bold);
            aboutText.AppendText(date);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Regular);
            aboutText.AppendText(theVersion);
            aboutText.SelectionFont = new Font("Times New Roman", 12, FontStyle.Italic);
            aboutText.AppendText(version);
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
