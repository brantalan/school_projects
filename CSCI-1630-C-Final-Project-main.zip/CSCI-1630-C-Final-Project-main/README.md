# CSCI-1630-C-Final-Project
Final Project for CSCI1630 C#- a C# frontend and backend database for movies
