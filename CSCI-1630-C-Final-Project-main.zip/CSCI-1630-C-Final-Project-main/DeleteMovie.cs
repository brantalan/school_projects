﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class DeleteMovie : Form
    {
        int connectionStatus = 0;
        public DeleteMovie()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void Clear()
        {
            titleBox.Text = string.Empty;
            yearBox.Text = string.Empty;
            directorBox.Text = string.Empty;
            genreBox.Text = string.Empty;
            ratingBox.Text = string.Empty;
            salesBox.Text = string.Empty;
        }
        private void findButton_Click(object sender, EventArgs e)
        {
            string findMovie = titleBox.Text;
            var film = Main.FindMovie(findMovie);
            if (String.IsNullOrEmpty(titleBox.Text))
            {
                MessageBox.Show("Please enter an exact title for the movie you wish to find.", "Error");
                return;
            }
            if (film.Title == null)
            {
                MessageBox.Show("Sorry the movie you searched for called '" + findMovie + "' could not be found.", "Not Found");
                Clear();
                return;
            }
            titleBox.Text = film.Title;
            yearBox.Text = Convert.ToString(film.Year);
            directorBox.Text = film.Director;
            genreBox.Text = film.Genre;
            ratingBox.Text = Convert.ToString(film.RottenTomatoesScore);
            salesBox.Text = Convert.ToString(film.TotalEarned);
        }
        private void deleteButton_Click(object sender, EventArgs e)
        {
            string deleteTitle = titleBox.Text;
            var deleteFilm = Main.FindMovie(deleteTitle);

            if (String.IsNullOrEmpty(titleBox.Text))
            {
                MessageBox.Show("Please enter an exact title for the movie you wish to delete.", "Error");
                return;
            }
            else if (deleteFilm.Title == null && connectionStatus == 1)
            {
                MessageBox.Show("Sorry the movie you tried deleting called '" + deleteTitle + "' could not be found." + Environment.NewLine + "Try using the 'Find' button first", "Not Found");
                return;
            }
            else if (deleteFilm.Title != null)
            {
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show("Are you sure you want to delete " + deleteFilm.Title + " from your movies?", "Delete", buttons);
                if (result == DialogResult.Yes)
                {

                    Delete(deleteFilm);
                    if (connectionStatus == 1)
                    {
                        MessageBox.Show("You have successfully deleted " + deleteFilm.Title + " from your movies.", "Success");
                        Clear();
                    }
                }
            }
        }
        public int Delete(Movie deleteFilm)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MovieDB"]?.ConnectionString;
            string sqlCommand = "DELETE FROM dbo.Movies WHERE Id = @Id";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.Add("Id", SqlDbType.Int).Value = deleteFilm.Id;
                        connection.Open();
                        connectionStatus = 1;
                        return command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed. Error {ex.Message}");
                connectionStatus = 2;
                return connectionStatus;
            }
        }
    }
}

