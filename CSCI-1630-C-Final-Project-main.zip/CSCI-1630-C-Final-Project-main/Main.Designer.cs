﻿namespace FinalProject
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.maintenanceMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addMovieMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.updateMovieMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteMovieMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.masterLabel = new System.Windows.Forms.Label();
            this.dgvMovies = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovies)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.maintenanceMenu,
            this.aboutMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1328, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshMenu,
            this.exitMenu});
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(46, 24);
            this.fileMenu.Text = "File";
            // 
            // refreshMenu
            // 
            this.refreshMenu.Name = "refreshMenu";
            this.refreshMenu.Size = new System.Drawing.Size(167, 26);
            this.refreshMenu.Text = "Refresh List";
            this.refreshMenu.Click += new System.EventHandler(this.refreshMenu_Click);
            // 
            // exitMenu
            // 
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(167, 26);
            this.exitMenu.Text = "Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // maintenanceMenu
            // 
            this.maintenanceMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addMovieMenu,
            this.updateMovieMenu,
            this.deleteMovieMenu});
            this.maintenanceMenu.Name = "maintenanceMenu";
            this.maintenanceMenu.Size = new System.Drawing.Size(108, 24);
            this.maintenanceMenu.Text = "Maintenance";
            // 
            // addMovieMenu
            // 
            this.addMovieMenu.Name = "addMovieMenu";
            this.addMovieMenu.Size = new System.Drawing.Size(186, 26);
            this.addMovieMenu.Text = "Add Movie";
            this.addMovieMenu.Click += new System.EventHandler(this.addMovieMenu_Click);
            // 
            // updateMovieMenu
            // 
            this.updateMovieMenu.Name = "updateMovieMenu";
            this.updateMovieMenu.Size = new System.Drawing.Size(186, 26);
            this.updateMovieMenu.Text = "Update Movie";
            this.updateMovieMenu.Click += new System.EventHandler(this.updateMovieMenu_Click);
            // 
            // deleteMovieMenu
            // 
            this.deleteMovieMenu.Name = "deleteMovieMenu";
            this.deleteMovieMenu.Size = new System.Drawing.Size(186, 26);
            this.deleteMovieMenu.Text = "Delete Movie";
            this.deleteMovieMenu.Click += new System.EventHandler(this.deleteMovieMenu_Click);
            // 
            // aboutMenu
            // 
            this.aboutMenu.Name = "aboutMenu";
            this.aboutMenu.Size = new System.Drawing.Size(64, 24);
            this.aboutMenu.Text = "About";
            this.aboutMenu.Click += new System.EventHandler(this.aboutMenu_Click);
            // 
            // masterLabel
            // 
            this.masterLabel.AutoSize = true;
            this.masterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.masterLabel.Location = new System.Drawing.Point(13, 32);
            this.masterLabel.Name = "masterLabel";
            this.masterLabel.Padding = new System.Windows.Forms.Padding(10, 20, 10, 20);
            this.masterLabel.Size = new System.Drawing.Size(213, 65);
            this.masterLabel.TabIndex = 1;
            this.masterLabel.Text = "Movies Master List";
            // 
            // dgvMovies
            // 
            this.dgvMovies.AllowUserToAddRows = false;
            this.dgvMovies.AllowUserToDeleteRows = false;
            this.dgvMovies.AllowUserToOrderColumns = true;
            this.dgvMovies.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvMovies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMovies.EnableHeadersVisualStyles = false;
            this.dgvMovies.Location = new System.Drawing.Point(10, 101);
            this.dgvMovies.Name = "dgvMovies";
            this.dgvMovies.ReadOnly = true;
            this.dgvMovies.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgvMovies.RowHeadersWidth = 51;
            this.dgvMovies.RowTemplate.Height = 24;
            this.dgvMovies.Size = new System.Drawing.Size(1304, 550);
            this.dgvMovies.TabIndex = 2;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 663);
            this.Controls.Add(this.dgvMovies);
            this.Controls.Add(this.masterLabel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Movie Manager Application";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMovies)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem maintenanceMenu;
        private System.Windows.Forms.ToolStripMenuItem aboutMenu;
        private System.Windows.Forms.Label masterLabel;
        private System.Windows.Forms.ToolStripMenuItem refreshMenu;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.ToolStripMenuItem addMovieMenu;
        private System.Windows.Forms.ToolStripMenuItem updateMovieMenu;
        private System.Windows.Forms.ToolStripMenuItem deleteMovieMenu;
        private System.Windows.Forms.DataGridView dgvMovies;
    }
}

