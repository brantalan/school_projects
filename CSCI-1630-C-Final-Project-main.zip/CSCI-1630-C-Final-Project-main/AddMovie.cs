﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class AddMovie : Form
    {
        int connectionStatus = 0;
        public int Year { get; }
        public AddMovie()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void Clear()
        {
            titleBox.Text = string.Empty;
            yearBox.Text = string.Empty;
            directorBox.Text = string.Empty;
            genreBox.Text = string.Empty;
            ratingBox.Text = string.Empty;
            salesBox.Text = string.Empty;
        }
        private void addButton_Click(object sender, EventArgs e)
        {

            var newFilm = new Movie();
            int movieYear, rating = 0;
            decimal totalRevenue = 0;

            if (String.IsNullOrEmpty(titleBox.Text) || String.IsNullOrEmpty(yearBox.Text) ||
                String.IsNullOrEmpty(directorBox.Text) || String.IsNullOrEmpty(genreBox.Text))
            {
                MessageBox.Show("Fields can not be left empty for Title, Year, Director or Genre.", "Error");
                return;
            }
            if (!int.TryParse(yearBox.Text, out movieYear))
            {
                MessageBox.Show("Please enter a valid year", "Error");
                return;
            }
            if (!String.IsNullOrEmpty(ratingBox.Text))
            {
                if (!int.TryParse(ratingBox.Text, out rating) || rating < 0 || rating > 100)
                {
                    MessageBox.Show("Please enter a valid rating between 0 and 100.", "Error");
                    return;
                }
            }
            if (genreBox.SelectedIndex < 0 || genreBox.SelectedIndex > 8)
            {
                MessageBox.Show("Please choose a genre from the list.", "Error");
                return;
            }
            if (!String.IsNullOrEmpty(salesBox.Text))
            {
                if (!decimal.TryParse(salesBox.Text, out totalRevenue) || totalRevenue < 0)
                {
                    MessageBox.Show("Please enter a valid dollar amount for the movie's box office earnings.", "Error");
                    return;
                }
            }
            newFilm.Title = titleBox.Text;
            newFilm.Year = movieYear;
            newFilm.Director = directorBox.Text;
            newFilm.Genre = Convert.ToString(genreBox.SelectedIndex + 1);
            newFilm.RottenTomatoesScore = rating;
            newFilm.TotalEarned = totalRevenue;

            InsertMovie(newFilm);
            if (connectionStatus == 1)
            {
                MessageBox.Show("You successfully added " + newFilm.Title + " to your movies.", "Success");
                Clear();
            }
        }
        public int InsertMovie(Movie newFilm)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MovieDB"]?.ConnectionString;
            string sqlCommand = "INSERT INTO dbo.Movies (Title, Year, Director, Genre, RottenTomatoesScore, TotalEarned) "
                + "VALUES (@Title,@Year,@Director,@Genre,@RottenTomatoesScore,@TotalEarned)";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = newFilm.Title;
                        object dbTitle = newFilm.Title;
                        command.Parameters.Add("Year", SqlDbType.Int).Value = newFilm.Year;
                        object dbYear = newFilm.Year;
                        command.Parameters.Add("Director", SqlDbType.VarChar, 50).Value = newFilm.Director;
                        object dbDirector = newFilm.Director;
                        command.Parameters.Add("Genre", SqlDbType.Int).Value = newFilm.Genre;
                        object dbGenre = newFilm.Genre;
                        command.Parameters.Add("RottenTomatoesScore", SqlDbType.Int).Value = newFilm.RottenTomatoesScore;
                        object dbRating = newFilm.RottenTomatoesScore;
                        if (dbRating == null)
                        {
                            dbRating = DBNull.Value;
                        }
                        command.Parameters.Add("TotalEarned", SqlDbType.Decimal).Value = newFilm.TotalEarned;
                        object dbEarned = newFilm.TotalEarned;
                        if (dbEarned == null)
                        {
                            dbEarned = DBNull.Value;
                        }
                        connection.Open();
                        connectionStatus = 1;
                        return command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed. Error {ex.Message}");
                connectionStatus = 2;
                return connectionStatus;
            }
        }
    }
}
