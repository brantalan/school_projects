﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            PopulateMovies();
        }

        private void aboutMenu_Click(object sender, EventArgs e)
        {
            About showAbout = new About();
            showAbout.ShowDialog();
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addMovieMenu_Click(object sender, EventArgs e)
        {
            AddMovie addMovie = new AddMovie();
            addMovie.ShowDialog();
        }

        private void updateMovieMenu_Click(object sender, EventArgs e)
        {
            UpdateMovie updateMovie = new UpdateMovie();
            updateMovie.ShowDialog();
        }

        private void deleteMovieMenu_Click(object sender, EventArgs e)
        {
            DeleteMovie deleteMovie = new DeleteMovie();
            deleteMovie.ShowDialog();
        }

        private void refreshMenu_Click(object sender, EventArgs e)
        {
            PopulateMovies();
        }
        private void PopulateMovies()
        {
            string[] genres = { null, "Animation", "Action", "Comedy", "Drama", "Horror", "Mystery", "Romance", "Science Fiction", "Western" };
            string connectionString = ConfigurationManager.ConnectionStrings["MovieDB"]?.ConnectionString;
            List<Movie> movies = new List<Movie>();
            string sqlCommand = "SELECT Id, Title, Year, Director, Genre, RottenTomatoesScore, TotalEarned FROM Movies ORDER BY Title";
            
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var film = new Movie();

                                film.Title = reader.GetString(1);
                                film.Year = reader.GetInt32(2);
                                film.Director = reader.GetString(3);
                                int genreNumber = reader.GetInt32(4);
                                film.Genre = genres[genreNumber];
                                if (!reader.IsDBNull(5))
                                {
                                    film.RottenTomatoesScore = reader.GetInt32(5);
                                }
                                if (!reader.IsDBNull(6))
                                {
                                    film.TotalEarned = reader.GetDecimal(6);
                                }
                                movies.Add(film);
                            }
                        }
                        connection.Close();

                        dgvMovies.DataSource = movies;
                        dgvMovies.Columns[6].DefaultCellStyle.Format = "C";
                        this.dgvMovies.Columns[0].Visible = false;
                        DataGridViewColumn titleCol = dgvMovies.Columns[1];
                        titleCol.Width = 225;
                        DataGridViewColumn yearCol = dgvMovies.Columns[2];
                        yearCol.Width = 75;
                        DataGridViewColumn directorCol = dgvMovies.Columns[3];
                        directorCol.Width = 175;
                        DataGridViewColumn genreCol = dgvMovies.Columns[4];
                        genreCol.Width = 175;
                        DataGridViewColumn ratingCol = dgvMovies.Columns[5];
                        ratingCol.HeaderCell.Value = "Rotten Tomatoes Score";
                        ratingCol.Width = 100;
                        DataGridViewColumn salesCol = dgvMovies.Columns[6];
                        salesCol.Width = 175;
                        salesCol.HeaderCell.Value = "Total Box Office";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed. Error {ex.Message}");
            }
        }
        public static Movie FindMovie(string findMovie)
        {
            string[] genres = { null, "Animation", "Action", "Comedy", "Drama", "Horror", "Mystery", "Romance", "Science Fiction", "Western" };
            var film = new Movie();
            string connectionString = ConfigurationManager.ConnectionStrings["MovieDB"]?.ConnectionString;
            string sqlCommand = "SELECT Id, Title, Year, Director, Genre, RottenTomatoesScore, TotalEarned FROM Movies WHERE Title = @Title";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.AddWithValue("@Title", findMovie);
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                film.Id = reader.GetInt32(0);
                                film.Title = reader.GetString(1);
                                film.Year = reader.GetInt32(2);
                                film.Director = reader.GetString(3);
                                int genreNumber = reader.GetInt32(4);
                                film.Genre = genres[genreNumber];
                                if (!reader.IsDBNull(5))
                                {
                                    film.RottenTomatoesScore = reader.GetInt32(5);
                                }
                                if (!reader.IsDBNull(6))
                                {
                                    film.TotalEarned = reader.GetDecimal(6);
                                }
                            }
                            connection.Close();
                        }
                    }
                }
                return film;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed. Error {ex.Message}");
                return film;
            }
        }
    }
}
