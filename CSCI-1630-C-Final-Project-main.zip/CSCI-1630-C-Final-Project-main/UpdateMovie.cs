﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class UpdateMovie : Form
    {
        Movie updateFilm = new Movie();
        int connectionStatus = 0;
        public UpdateMovie()
        {
            InitializeComponent();
            updateLabel.Text = string.Empty;
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void Clear()
        {
            titleBox.Text = string.Empty;
            yearBox.Text = string.Empty;
            directorBox.Text = string.Empty;
            genreBox.Text = string.Empty;
            ratingBox.Text = string.Empty;
            salesBox.Text = string.Empty;
            updateLabel.Text = string.Empty;
            updateFilm = new Movie();
        }
        private void findButton_Click(object sender, EventArgs e)
        {
            string findMovie = titleBox.Text;
            updateFilm = Main.FindMovie(findMovie);
            if (String.IsNullOrEmpty(titleBox.Text))
            {
                MessageBox.Show("Please enter an exact title for the movie you wish to find.", "Error");
                return;
            }
            if (updateFilm.Title == null)
            {
                MessageBox.Show("Sorry the movie you searched for called '" + findMovie + "' could not be found.", "Not Found");
                return;
            }
            updateLabel.Text = ("You are making changes to: " + Environment.NewLine + updateFilm.Title);
            titleBox.Text = updateFilm.Title;
            yearBox.Text = Convert.ToString(updateFilm.Year);
            directorBox.Text = updateFilm.Director;
            genreBox.Text = updateFilm.Genre;
            ratingBox.Text = Convert.ToString(updateFilm.RottenTomatoesScore);
            salesBox.Text = Convert.ToString(updateFilm.TotalEarned);
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void updateButton_Click(object sender, EventArgs e)
        {
            if (updateFilm.Title == null)
            {
                MessageBox.Show("Sorry there is no movie found to be updated." + Environment.NewLine + "Try using the 'Find' button first", "Not Found");
                return;
            }
            int movieYear, rating = 0;
            decimal totalRevenue = 0;

            if (String.IsNullOrEmpty(titleBox.Text) || String.IsNullOrEmpty(yearBox.Text) ||
                String.IsNullOrEmpty(directorBox.Text) || String.IsNullOrEmpty(genreBox.Text))
            {
                MessageBox.Show("Fields can not be left empty for Title, Year, Director or Genre.", "Error");
                return;
            }
            if (!int.TryParse(yearBox.Text, out movieYear))
            {
                MessageBox.Show("Please enter a valid year", "Error");
                return;
            }
            if (!String.IsNullOrEmpty(ratingBox.Text))
            {
                if (!int.TryParse(ratingBox.Text, out rating) || rating < 0 || rating > 100)
                {
                    MessageBox.Show("Please enter a valid rating between 0 and 100.", "Error");
                    return;
                }
            }
            if (genreBox.SelectedIndex < 0 || genreBox.SelectedIndex > 8)
            {
                MessageBox.Show("Please choose a genre from the list.", "Error");
                return;
            }
            if (!String.IsNullOrEmpty(salesBox.Text))
            {
                if (!decimal.TryParse(salesBox.Text, out totalRevenue) || totalRevenue < 0)
                {
                    MessageBox.Show("Please enter a valid dollar amount for the movie's box office earnings.", "Error");
                    return;
                }
            }
            updateFilm.Title = titleBox.Text;
            updateFilm.Year = movieYear;
            updateFilm.Director = directorBox.Text;
            updateFilm.Genre = Convert.ToString(genreBox.SelectedIndex + 1);
            updateFilm.RottenTomatoesScore = rating;
            updateFilm.TotalEarned = totalRevenue;

            Update(updateFilm);
            if (connectionStatus != 2)
            {
                MessageBox.Show("You have succesfully updated information for " + updateFilm.Title + ".", "Success");
            }
            else
            {
                MessageBox.Show("Changes could not be made.", "Error");
            }
        }
        public int Update(Movie updateFilm)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MovieDB"]?.ConnectionString;
            string sqlCommand = "UPDATE dbo.Movies SET Title = @Title, Year = @Year, Director = @Director,"
                + "Genre = @Genre, RottenTomatoesScore = @RottenTomatoesScore, TotalEarned = @TotalEarned WHERE Id = @Id";
            try {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.Add("Id", SqlDbType.Int).Value = updateFilm.Id;
                        command.Parameters.Add("Title", SqlDbType.VarChar, 50).Value = updateFilm.Title;
                        command.Parameters.Add("Year", SqlDbType.Int).Value = updateFilm.Year;
                        command.Parameters.Add("Director", SqlDbType.VarChar, 50).Value = updateFilm.Director;
                        command.Parameters.Add("Genre", SqlDbType.Int).Value = updateFilm.Genre;
                        command.Parameters.Add("RottenTomatoesScore", SqlDbType.Int).Value = updateFilm.RottenTomatoesScore;
                        command.Parameters.Add("TotalEarned", SqlDbType.Decimal).Value = updateFilm.TotalEarned;

                        connection.Open();
                        connectionStatus = 1;
                        return command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed. Error {ex.Message}");
                connectionStatus = 2;
                return connectionStatus;
            }
        }
    }
}
