# HTML-1145-Project
Final project for HTML 1145 at Columbus State
This final project was an outline of what we learned of HTML and CSS
My project was a simple website that included links, images, proper CSS formatting etc.
